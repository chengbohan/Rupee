//
//  BaseWebViewController.m
//

#import "BaseWebViewController.h"
@interface BaseWebViewController ()<WKNavigationDelegate, WKUIDelegate>
@property (nonatomic, strong) CADisplayLink *displayLink;
@property (nonatomic, strong) UIBarButtonItem *backItem;
@property (nonatomic, strong) UIBarButtonItem *closeItem;
@property (nonatomic, strong) UIBarButtonItem *shareItem;
@end

@implementation BaseWebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupWebView];
    self.view.backgroundColor = [UIColor whiteColor];
    self.enableWebBack = YES;
    self.edgesForExtendedLayout = UIRectEdgeNone;
    
    UIImage *image = [[UIImage imageNamed:@"nav_bar_icon_left_back_b"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    self.backItem = [[UIBarButtonItem alloc] initWithImage:image style:UIBarButtonItemStylePlain target:self action:@selector(backItemClicked)];
    self.closeItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStylePlain target:self action:@selector(closeItemClicked)];
    self.navigationItem.leftBarButtonItem = self.backItem;
}

#pragma mark - 返回 / 关闭
- (void)backItemClicked
{
    if (self.enableWebBack && [self.webView canGoBack]) {
        [self.webView goBack];
        self.navigationItem.leftBarButtonItems = @[self.backItem, self.closeItem];
    } else {
        [self closeItemClicked];
    }
}

- (void)closeItemClicked
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)loadWebViewWith:(NSString *)urlString
{
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [self.webView loadRequest:request];
}

- (void)loadWebViewWithLocalFile:(NSString *)filePath
{
    NSURL *url = [NSURL fileURLWithPath:filePath];
//    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [self.webView loadFileURL:url allowingReadAccessToURL:url];
}


- (void)setupWebView
{
    WKWebView *webView = [[WKWebView alloc]init];
    webView.frame = self.webViewFrame.size.width == 0 ? CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_WIDTH - statusBarHeight): self.webViewFrame;
    webView.backgroundColor = BackgroundColor;
    webView.navigationDelegate = self;
    [self.view addSubview:webView];
    self.webView = webView;
    if (_urlString) {
        [self loadWebViewWith:_urlString];
    }
}

- (void)setWebViewFrame:(CGRect)webViewFrame
{
    _webViewFrame = webViewFrame;
    self.webView.frame = webViewFrame;
}

#pragma mark - WKNavigationDelegate
// 页面开始加载时调用
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation
{
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    
    self.displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(progressValueMonitor)];
    [self.displayLink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
}

// 页面加载完成之后调用
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation
{
    self.navigationController.title = webView.title;
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    
    [self.displayLink invalidate];
    [UIView animateWithDuration:0.2 animations:^{
    } completion:^(BOOL finished) {

    }];
}

// 页面加载失败时调用
- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error
{
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    [UIView animateWithDuration:0.2 animations:^{
    } completion:^(BOOL finished) {
    }];
    [self.displayLink invalidate];
    if([error code] == NSURLErrorCancelled) return;
}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error
{
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    [UIView animateWithDuration:0.2 animations:^{
    } completion:^(BOOL finished) {
    }];
    [self.displayLink invalidate];
    if([error code] == NSURLErrorCancelled) return;
}
- (void)dealloc
{
    // 清除缓存
    NSSet *websiteDataTypes = [WKWebsiteDataStore allWebsiteDataTypes];
    NSDate *dateFrom = [NSDate dateWithTimeIntervalSince1970:0];
    [[WKWebsiteDataStore defaultDataStore] removeDataOfTypes:websiteDataTypes modifiedSince:dateFrom completionHandler:^{
        
    }];
}

@end
