
#import "BaseTabBarViewController.h"
#import "BaseNavViewController.h"
#import "HomeViewController.h"
#import "MineViewController.h"
#import "LoginViewController.h"
//#import "LoginViewController.h"
//#import "QYPOPSDK.h"
#import <IQKeyboardManager.h>

@interface BaseTabBarViewController ()<UITabBarControllerDelegate>
@property (nonatomic, strong)UserModel *modle;
@end

@implementation BaseTabBarViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.delegate = self;
    
    // 1. 设置tabbar文字属性
    [[UITabBarItem appearance] setTitleTextAttributes:@{
                                                        NSFontAttributeName: [UIFont systemFontOfSize:0],
                                                        NSForegroundColorAttributeName : RGBColor(169, 170, 184)
                                                        } forState:UIControlStateNormal];
    
    
    [[UITabBarItem appearance] setTitleTextAttributes:@{
                                                        NSForegroundColorAttributeName : RGBColor(45, 86, 204)
                                                        } forState:UIControlStateSelected];
    
    // 去掉tabbar的上部横线
//    [self.tabBar setBackgroundImage:[UIImage imageNamed:@"tabbar_bg"]];
    [self.tabBar setShadowImage:[UIImage new]];
    
    [self configureTabbar];
}

#pragma mark -
- (void)configureTabbar
{
//    UIStoryboard * storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
//    [self addChildControllerWithClass:[storyBoard instantiateViewControllerWithIdentifier:NSStringFromClass(HomeViewController.class)]
//                                title:@"首页"
//                                 icon:@"tabBar_nomal_1"
//                         selectedIcon:@"tabBar_selected_1"];
    
    [self addChildControllerWithClass:[[HomeViewController alloc]init]
                                title:@"Home"
                                 icon:@"tab_icon_home"
                         selectedIcon:@"tab_icon_home_selected"];
    
    

    
    [self addChildControllerWithClass:[[MineViewController alloc]init]
                                title:@"Me"
                                 icon:@"tab_icon_me"
                         selectedIcon:@"tab_icon_me_selected"];

    
    
//    [self addChildControllerWithClass:[storyBoard instantiateViewControllerWithIdentifier:NSStringFromClass(ShoppingCartViewController.class)]
//                                title:@"购物车"
//                                 icon:@"tabBar_nomal_3"
//                         selectedIcon:@"tabBar_selected_3"];
//
//    [self addChildControllerWithClass:[storyBoard instantiateViewControllerWithIdentifier:NSStringFromClass(MyMessageViewController.class)]
//                                title:@"消息"
//                                 icon:@"tabBar_nomal_4"
//                         selectedIcon:@"tabBar_selected_4"];
//    
//    [self addChildControllerWithClass:MineViewController.alloc
//                                title:@"我的"
//                                 icon:@"tabBar_nomal_5"
//                         selectedIcon:@"tabBar_selected_5"];
}

#pragma mark -
- (void)addChildControllerWithClass:(UIViewController *)aClass
                              title:(NSString *)title
                               icon:(NSString *)icon
                       selectedIcon:(NSString *)selectedIcon
{
    BaseNavViewController * nav = [[BaseNavViewController alloc] initWithRootViewController:aClass];
    aClass.tabBarItem.title = title;
    aClass.tabBarItem.image = [[UIImage imageNamed:icon] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    aClass.tabBarItem.selectedImage = [[UIImage imageNamed:selectedIcon] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    [self addChildViewController:nav];
}

#pragma mark- UITabBarControllerDelegate
- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController{
    self.modle = [UserModel sharedInstanced];

//    [[NSNotificationCenter defaultCenter] postNotificationName:kUpdateMsgKey object:nil];

    if (viewController == self.viewControllers[1]  ) {
        if (self.modle.nose.length <= 0){
            LoginViewController * VC = [[LoginViewController alloc]init];
            UINavigationController * nav = [[UINavigationController alloc]initWithRootViewController:VC];
            nav.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
            [self presentViewController:nav animated:YES completion:nil];
            return NO;
        }
    }
    return YES;
}


@end
