
#import <UIKit/UIKit.h>

@interface UIImage (ImageWithColor)

//设置图片的背景颜色
+ (UIImage *)imageWithColor:(UIColor *)color;

@end
