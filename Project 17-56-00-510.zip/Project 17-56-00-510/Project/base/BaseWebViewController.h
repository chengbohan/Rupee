//
//  BaseWebViewController.h
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

@interface BaseWebViewController : UIViewController<WKNavigationDelegate, WKUIDelegate>

- (void)loadWebViewWith:(NSString *)urlString;
- (void)loadWebViewWithLocalFile:(NSString *)filePath;

@property (nonatomic, copy) NSString *urlString;
/**
 *  监听webView是否可返回，做webview的返回操作
 */
@property (nonatomic, assign) BOOL  enableWebBack;

/**
 *  可以调整webView的frame
 */
@property (nonatomic, assign) CGRect webViewFrame;
@property (nonatomic, weak) WKWebView *webView;

// 分享相关内容
@property (nonatomic, copy) NSString *shareUrl;
@property (nonatomic, copy) NSString *shareContent;
@property (nonatomic, copy) NSString *shareImage;
@property (nonatomic, assign) BOOL isHiddenShare;

@end
