//
//  SettingsViewController.m
//  Project
//
//  Created by 回春雷 on 2023/4/16.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "SettingsViewController.h"

@interface SettingsViewController ()

@end

@implementation SettingsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self nav];
    [self ui];
    
}
-(void)ui{
    UIImageView *icon = [UIImageView new];
    icon.image = [UIImage imageNamed:@"rupeelogo_68"];
    [self.view addSubview:icon];
    [icon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.top.equalTo(self.view).offset(statusBarAndNavigationBarHeight+40);
        make.size.mas_equalTo(CGSizeMake(70, 70));
    }];
    UILabel *name = [UILabel new];
    name.text = @"RupeeApp";
    name.font = [UIFont systemFontOfSize:17 weight:UIFontWeightBold];
    name.textColor = RGBColor(35, 36, 40);
    [name sizeToFit];
    [self.view addSubview:name];
    [name mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(icon).offset(85);
        make.centerX.equalTo(self.view);
    }];
    UILabel *name1 = [UILabel new];
    name1.text = @"v1.0.0";
    name1.font = DEF_FontSize_14;
    name1.textColor = RGBColor(169, 170, 184);
    [name1 sizeToFit];
    [self.view addSubview:name1];
    [name1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(name).offset(name.bounds.size.height+15);
        make.centerX.equalTo(self.view);
    }];

    UIButton *zx = [UIButton buttonWithType:UIButtonTypeCustom];
    [zx setTitle:@"Account cancellation" forState:UIControlStateNormal];
    [zx setTitleColor:RGBColor(226, 78, 78) forState:UIControlStateNormal];
    zx.titleLabel.font = DEF_FontSize_16;
    [self.view addSubview:zx];
    [zx mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.bottom.equalTo(self.view).offset(-tabbarSafeBottomMargin -20);
        make.height.mas_equalTo(20);
    }];
    
    UIButton *lout = [UIButton buttonWithType:UIButtonTypeCustom];
    [lout setTitle:@"Logout" forState:UIControlStateNormal];
    [lout setBackgroundImage:[UIImage imageNamed:@"btn_long_bg_grey"] forState:UIControlStateNormal];
    [lout setTintColor:RGBColor(255, 255, 255)];
    lout.titleLabel.font = DEF_FontSize_17;
    [self.view addSubview:lout];
    [lout mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.bottom.equalTo(zx).offset(-30);
        make.size.mas_equalTo(CGSizeMake(302, 48));
    }];

    
    
    
    
    
    
}
-(void)nav{
    self.navigationItem.title = @"Settings";
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor blackColor]}];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[[UIImage imageNamed:@"nav_bar_icon_left_back_b"] imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)] style:UIBarButtonItemStylePlain target:self action:@selector(leftButtonClick)];
}

-(void)leftButtonClick{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
