//
//  OrderCell.m
//  Project
//
//  Created by 回春雷 on 2023/4/6.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "OrderCell.h"

@implementation OrderCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if ([super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.contentView.backgroundColor = [UIColor clearColor];
        UIView *view = [UIView new];
        view.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:view];
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.contentView);
            make.left.equalTo(self.contentView).offset(SCALE(6));
            make.right.equalTo(self.contentView).offset(-SCALE(6));
            make.height.mas_equalTo(SCALE(157));
        }];
        UIImageView *ba = [UIImageView new];
        ba.image = [UIImage imageNamed:@"order_list_bg"];
        [view addSubview:ba];
        [ba mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(view);
            make.right.equalTo(view);
            make.top.equalTo(view);
            make.bottom.equalTo(view);
        }];
        
        UIImageView *icon = [UIImageView new];
        [view addSubview:icon];
        [icon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(view).offset(SCALE(16));
            make.left.equalTo(view).offset(SCALE(26));
            make.size.mas_equalTo(CGSizeMake(24, 24));
        }];
        UILabel *l = [UILabel new];
        l.text = @"Kotak Payments";
        l.font = DEF_FontSize_16;
        l.textColor = RGBColor(35, 36, 40);
        [view addSubview:l];
        [l mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(icon);
            make.left.equalTo(icon).offset(32);
        }];
        UIView *s = [UIView new];
        s.backgroundColor = RGBColor(246, 240, 238);
        [view addSubview:s];
        [s mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(icon);
            make.right.equalTo(view).offset(-SCALE(26));
        }];
        UILabel *sl = [UILabel new];
        sl.text = @"Applying";
        sl.font = DEF_FontSize_12;
        sl.textColor = RGBColor(226, 78, 78);
        [s addSubview:sl];
        [sl mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.center.equalTo(sl);
            make.top.equalTo(s).offset(4);
            make.bottom.equalTo(s).offset(-4);
            make.left.equalTo(s).offset(8);
            make.right.equalTo(s).offset(-8);
        }];
        s.layer.cornerRadius = 10.5;
        UIView *line = [UIView new];
        line.backgroundColor = RGBColor(169, 170, 184);
        line.alpha = .25;
        [view addSubview:line];
        [line mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView).offset(SCALE(26));
            make.right.equalTo(self.contentView).offset(-SCALE(26));
            make.top.equalTo(icon).offset(24+SCALE(8));
            make.height.mas_equalTo(1);
        }];
        UILabel *l1 = [UILabel new];
        l1.text = @"Loan amount";
        l1.font = DEF_FontSize_14;
        l1.textColor = RGBColor(169, 170, 184);
        [l1 sizeToFit];
        [view addSubview:l1];
        [l1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(line).offset(1+SCALE(8));
            make.left.equalTo(view).offset(SCALE(26));
        }];
        UILabel *r1 = [UILabel new];
        r1.text = @"₹10.000";
        r1.font = [UIFont systemFontOfSize:14 weight:UIFontWeightBold];
        r1.textColor = RGBColor(45, 86, 204);
        [r1 sizeToFit];
        [view addSubview:r1];
        [r1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(l1);
            make.right.equalTo(view).offset(-SCALE(26));
        }];

        UILabel *l2 = [UILabel new];
        l2.text = @"Loan date";
        l2.font = DEF_FontSize_14;
        l2.textColor = RGBColor(169, 170, 184);
        [l2 sizeToFit];
        [view addSubview:l2];
        [l2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(l1).offset(SCALE(8)+l1.bounds.size.height);
            make.left.equalTo(view).offset(SCALE(26));
        }];
        UILabel *r2 = [UILabel new];
        r2.text = @"23-June-2022";
        r2.font = DEF_FontSize_14;
        r2.textColor = RGBColor(35, 36, 40);
        [r2 sizeToFit];
        [view addSubview:r2];
        [r2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(l2);
            make.right.equalTo(view).offset(-SCALE(26));
        }];

        
        UILabel *l3 = [UILabel new];
        l3.text = @"Repayment date";
        l3.font = DEF_FontSize_14;
        l3.textColor = RGBColor(169, 170, 184);
        [l3 sizeToFit];
        [view addSubview:l3];
        [l3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(l2).offset(SCALE(8)+l2.bounds.size.height);
            make.left.equalTo(view).offset(SCALE(26));
        }];
        UILabel *r3 = [UILabel new];
        r3.text = @"23-June-2022";
        r3.font = DEF_FontSize_14;
        r3.textColor = RGBColor(35, 36, 40);
        [r3 sizeToFit];
        [view addSubview:r3];
        [r3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(l3);
            make.right.equalTo(view).offset(-SCALE(26));
        }];

        
    }
    return self;
}
@end
