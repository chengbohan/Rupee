//
//  OrderViewController.h
//  Project
//
//  Created by 回春雷 on 2023/3/30.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface OrderViewController : UIViewController
//WebViewControl里引用了这个类,设置TYPE的时候预留一个省缺默认值  阅后即焚！！！
@end

NS_ASSUME_NONNULL_END
