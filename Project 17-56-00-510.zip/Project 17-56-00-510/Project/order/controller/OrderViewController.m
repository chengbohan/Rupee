//
//  OrderViewController.m
//  Project
//
//  Created by 回春雷 on 2023/3/30.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "OrderViewController.h"
#import "OrderCell.h"
#import <ReactiveObjC/ReactiveObjC.h>

@interface OrderViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong)UITableView *tableView;
@property (nonatomic,strong)NSMutableArray *dataArray;
@property (nonatomic, strong)UIButton *btn;

@end

@implementation OrderViewController
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [BusinessNetwork post:@"ruap/opportunity" paramers:@{@"half":@"4",@"goes":@"1",@"done":@"10"} HUDInView:self.view PostsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
        NSLog(@"%@",JSON);
    }];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = RGBColor(240, 241, 245);
    [self nav];
    [self ui];
}
-(void)ui{
    UIView *view = [UIView new];
    [self.view addSubview:view];
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view);
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.height.mas_equalTo(SCALE(200));
    }];
    UIImageView *bac = [UIImageView new];
    bac.image = [UIImage imageNamed:@"order_bg_top"];
    [view addSubview:bac];
    [bac mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(view);
        make.left.equalTo(view);
        make.right.equalTo(view);
        make.bottom.equalTo(view);
    }];
    UIButton *one = [UIButton buttonWithType:UIButtonTypeCustom];
    [one setTitle:@"All" forState:UIControlStateNormal];
    [one setTitleColor:RGBColor(45, 86, 204) forState:UIControlStateNormal];
    one.backgroundColor =RGBColor(255, 255, 255);
    one.titleLabel.font = DEF_FontSize_14;
    one.layer.masksToBounds = YES;
    one.layer.cornerRadius = 15;
    [view addSubview:one];
    [one mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(view).offset(SCALE(16)+statusBarAndNavigationBarHeight);
        make.left.equalTo(view).offset(SCALE(16));
        make.size.mas_equalTo(CGSizeMake(64, 34));
    }];

    
    UIButton *two = [UIButton buttonWithType:UIButtonTypeCustom];
    [two setTitle:@"Applying" forState:UIControlStateNormal];
    [two setTitleColor:RGBColor(240, 241, 245) forState:UIControlStateNormal];
    two.backgroundColor =RGBColor(115, 147, 250);
    two.titleLabel.font = DEF_FontSize_14;
    two.layer.masksToBounds = YES;
    two.layer.cornerRadius = 15;
    [view addSubview:two];
    [two mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(view).offset(SCALE(16)+statusBarAndNavigationBarHeight);
        make.left.equalTo(one).offset(SCALE(16)+64);
        make.size.mas_equalTo(CGSizeMake(88, 34));
    }];

    UIButton *three = [UIButton buttonWithType:UIButtonTypeCustom];
    [three setTitle:@"Repay" forState:UIControlStateNormal];
    [three setTitleColor:RGBColor(240, 241, 245) forState:UIControlStateNormal];
    three.backgroundColor =RGBColor(115, 147, 250);
    three.titleLabel.font = DEF_FontSize_14;
    three.layer.masksToBounds = YES;
    three.layer.cornerRadius = 15;
    [view addSubview:three];
    [three mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(view).offset(SCALE(16)+statusBarAndNavigationBarHeight);
        make.left.equalTo(two).offset(SCALE(16)+88);
        make.size.mas_equalTo(CGSizeMake(73, 34));
    }];

    UIButton *four = [UIButton buttonWithType:UIButtonTypeCustom];
    [four setTitle:@"Finish" forState:UIControlStateNormal];
    [four setTitleColor:RGBColor(240, 241, 245) forState:UIControlStateNormal];
    four.backgroundColor =RGBColor(115, 147, 250);
    four.titleLabel.font = DEF_FontSize_14;
    four.layer.masksToBounds = YES;
    four.layer.cornerRadius = 15;
    [view addSubview:four];
    [four mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(view).offset(SCALE(16)+statusBarAndNavigationBarHeight);
        make.left.equalTo(three).offset(SCALE(16)+73);
        make.size.mas_equalTo(CGSizeMake(70, 34));
    }];
    [self tableView];
    [self.view addSubview:_tableView];
    [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.bottom.equalTo(self.view).offset(-tabbarSafeBottomMargin);
        make.top.equalTo(one).offset(SCALE(50));
    }];
    UIImageView *no = [UIImageView new];
    no.image = [UIImage imageNamed:@"order_pic_none"];
    [self.view addSubview:no];
    [no mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self.view);
        make.size.mas_equalTo(CGSizeMake(107, 108));
    }];
    UILabel *nol = [UILabel new];
    nol.text = @"No records.";
    nol.textColor = RGBColor(169, 170, 184);
    nol.font = DEF_FontSize_14;
    [self.view addSubview:nol];
    [nol mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.top.equalTo(no).offset(123);
    }];
    
    
    [[one rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
        
    }];
    [[one rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
        
    }];
    [[one rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
        
    }];
    [[one rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
        
    }];
}
-(void)nav{
    self.navigationItem.title = @"Order records";
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[[UIImage imageNamed:@"nav_bar_icon_left_back_w"] imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)] style:UIBarButtonItemStylePlain target:self action:@selector(leftButtonClick)];
}
-(void)leftButtonClick{
    [self.navigationController popViewControllerAnimated:YES];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 5;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    OrderCell *orderCell = [tableView dequeueReusableCellWithIdentifier:@"OrderCell"];
    if (orderCell==nil)
    {
        orderCell=[[OrderCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"OrderCell"];
    }
//    [orderCell setSouce:_dataArray[indexPath.row]];
    orderCell.selectionStyle = UITableViewCellSelectionStyleNone;
    orderCell.backgroundColor = [UIColor clearColor];
    orderCell.backgroundView = nil;
    return orderCell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return SCALE(157);
}
-(UITableView *)tableView {
    if(!_tableView){
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.backgroundView = nil;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _tableView;
}


@end
