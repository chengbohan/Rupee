//
//  BRAddressModel.m
//  BRPickerViewDemo
//
//  Created by renbo on 2017/8/11.
//  Copyright © 2017 irenb. All rights reserved.
//
//  最新代码下载地址：https://github.com/91renb/BRPickerView

#import "BRAddressModel.h"

@implementation BRProvinceModel

@end


@implementation BRCityModel

@end


@implementation BRAreaModel

@end
