//
//  WMZDialog+NaviMenu.h
//  WMZDialog
//
//  Created by wmz on 2019/9/12.
//  Copyright © 2019 wmz. All rights reserved.
//

#import "WMZDialog.h"

NS_ASSUME_NONNULL_BEGIN

@interface WMZDialog (NaviMenu)

@end

NS_ASSUME_NONNULL_END
