//
//  WMZDialog+MenusSelect.h
//  WMZDialog
//
//  Created by wmz on 2019/6/28.
//  Copyright © 2019年 wmz. All rights reserved.
//

#import "WMZDialog.h"

NS_ASSUME_NONNULL_BEGIN

@interface WMZDialog (MenusSelect)

@end


NS_ASSUME_NONNULL_END
