//
//  WMZDialog+CardPresent.h
//  WMZDialog
//
//  Created by wmz on 2019/11/5.
//  Copyright © 2019 wmz. All rights reserved.
//

#import "WMZDialog.h"

NS_ASSUME_NONNULL_BEGIN

@interface WMZDialog (CardPresent)

@end

NS_ASSUME_NONNULL_END
