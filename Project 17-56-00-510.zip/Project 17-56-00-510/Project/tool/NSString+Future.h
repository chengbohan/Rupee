//
//  NSString+Future.h
//  PredictTheFuture
//
//  Created by 回春雷 on 2020/9/3.
//  Copyright © 2020 回春雷. All rights reserved.
//
#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
@interface NSString (Future)
//手机号
+ (BOOL)validateContactNumber:(NSString *)mobileNum;
//验证码
+(BOOL)testCodeNumber:(NSString *)text;
@end
NS_ASSUME_NONNULL_END
