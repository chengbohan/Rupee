//
//  AppDelegate.h
//  Project
//
//  Created by 回春雷 on 2023/3/17.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseTabBarViewController.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic)BaseTabBarViewController *tabBarController;
+(BOOL)isIPhoneX;
+ (NSString *)getdeviceModelName;
+ (NSString *)getidfa;
+ (NSString *)getidfv;
+ (void)tostWithMessage:(NSString *)message;
@end

