//  BusinessNetwork.h
//  HttpProtoType
//  Created by 回春雷 on 2019/12/10.
//  Copyright © 2019 回春雷. All rights reserved.
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "NSString+Json.h"
NS_ASSUME_NONNULL_BEGIN
@interface BusinessNetwork : NSObject
#pragma mark -- Get
+ (NSURLSessionDataTask *)get:(NSString *)url paramers:(id)paramers andShowHUDInView:(UIView *)view resultGetsWithBlock:(void (^)(id JSON, NSError *error))block;
#pragma mark -- Post
+ (NSURLSessionDataTask *)post:(NSString *)url paramers:(id)paramers HUDInView:(UIView *)view PostsWithBlock:(void (^)(id JSON, NSError *error))block;
@end
NS_ASSUME_NONNULL_END
