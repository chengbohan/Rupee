//  NSString+Json.m
//  EveryDay
//  Created by shenxu on 15/7/22.
//  Copyright (c) 2015年 江涛. All rights reserved.
#import "NSString+Json.h"
#import<CommonCrypto/CommonCryptor.h>
@implementation NSString (Json)
+(NSString *)jsonStringWithObject:(id)theData
{
    NSError *error = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:theData													 options:NSJSONWritingPrettyPrinted	 error:&error];
    if ([jsonData length] > 0 && error == nil)
    {
        return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    else
    {
        return nil;
    }
}
+ (NSString*)jsonStringWithDictionary:(NSDictionary *)dic
{
    NSError *parseError = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}
+(NSString *) jsonStringWithArray:(NSArray *)array{
    NSMutableString *reString = [NSMutableString string];
    [reString appendString:@"["];
    NSMutableArray *values = [NSMutableArray array];
    for (id valueObj in array) {
        NSString *value = [NSString jsonStringWithObject:valueObj];
        if (value) {
            [values addObject:[NSString stringWithFormat:@"%@",value]];
        }
    }
    [reString appendFormat:@"%@",[values componentsJoinedByString:@","]];
    [reString appendString:@"]"];
    return reString;
}
- (NSString *)prettyDateWithReference:(long long int)oldOpt andSystemNowTime:(long long int)nowOpt{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    NSDate *oldDate = [NSDate dateWithTimeIntervalSince1970:oldOpt/1000];
    NSDate *nowDate = [NSDate dateWithTimeIntervalSince1970:nowOpt/1000];
    NSString *suffix = @"以前";
    float different = [nowDate timeIntervalSinceDate:oldDate];
    if (different < 0) {
        different = -different;
        suffix = @"现在";
    }
    float dayDifferent = floor(different / 86400);
    int days   = (int)dayDifferent;
    int weeks  = (int)ceil(dayDifferent / 7);
    int months = (int)ceil(dayDifferent / 30);
    int years  = (int)ceil(dayDifferent / 365);
    if (dayDifferent <= 0) {
        if (different < 60) {
            return @"刚刚";
        }
        if (different < 120) {
            return [NSString stringWithFormat:@"1 分钟%@", suffix];
        }
        if (different < 60 * 60) {
            return [NSString stringWithFormat:@"%d 分钟%@", (int)floor(different / 60), suffix];
        }
        if (different < 7200) {
            return [NSString stringWithFormat:@"1 小时%@", suffix];
        }
        if (different < 86400) {
            return [NSString stringWithFormat:@"%d 小时%@", (int)floor(different / 3600), suffix];
        }
    }
    else if (days < 7) {
        return [NSString stringWithFormat:@"%d 天%@", days, suffix];
    }
    else if (weeks < 4) {
        return [NSString stringWithFormat:@"%d 周%@", weeks, suffix];
    }
    else if (months < 12) {
        return [NSString stringWithFormat:@"%d 月%@", months, suffix];
    }
    else {
        return [NSString stringWithFormat:@"%d 年%@", years, suffix];
    }
    return self.description;
}
//NSDate转换
-(NSString *)NSDateToNString:(NSDate *)date{
    NSDateFormatter *formatter = [self setFormatter:[NSTimeZone systemTimeZone]];
    NSString *nowtimeStr = [formatter stringFromDate:date];
    return nowtimeStr;
}
//Date
-(long long int)NSDateToNSTime:(NSDate *)date{
    //默认东八区转换
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    //NSDateFormatter *formatter = [self setFormatter:timeZone];
    NSInteger seconds=[timeZone secondsFromGMTForDate:date];
    NSDate *newDate=[date dateByAddingTimeInterval:seconds];
    return (long long int)[newDate timeIntervalSince1970];
    //时间转时间戳的方法:
//    NSString *timeSp = [NSString stringWithFormat:@"%ld", (long)[newDate timeIntervalSince1970]];
//    return     [timeSp longLongValue];
}
-(NSDateFormatter *)setFormatter:(NSTimeZone *)timeZone
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.timeZone = [NSTimeZone timeZoneWithName:@"beijing"];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    [formatter setTimeZone:timeZone];//设定时区为当前系统时区
    return formatter;
}
+ (NSString *)timeWithTimeIntervalString:(NSString *)timeString
{
    NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
    formatter.timeZone = [NSTimeZone timeZoneWithName:@"beijing"];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    NSDate* date = [NSDate dateWithTimeIntervalSince1970:[timeString doubleValue]];
    NSString* dateString = [formatter stringFromDate:date];
    return dateString;
}

+ (NSString *)getNowTimeInterval
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init] ;
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Beijing"];
    [formatter setTimeZone:timeZone];
    NSDate *datenow = [NSDate date];
    NSString *timeSp = [NSString stringWithFormat:@"%ld", (long)[datenow timeIntervalSince1970]];
    return timeSp;
}
#pragma mark - 价格
- (NSString *)priceString
{
//    static NSNumberFormatter *formatter;
//    static dispatch_once_t onceToken;dispatch_once(&onceToken, ^{
//        formatter = [[NSNumberFormatter alloc] init];
//        formatter.maximumFractionDigits = 2;
//        formatter.minimumIntegerDigits = 1;
//    });
//    return [formatter stringFromNumber:[formatter numberFromString:self]];
    NSString *price = [NSString stringWithFormat:@"￥%.2f", [self doubleValue]];
    return price;
}
#pragma mark 清空字符串中的空白字符
- (NSString *)deleteAllWhitespaceString
{
    // 去除两边的空格
    NSString * leftOrRight = [self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    // 去除中间的空格
    return [leftOrRight stringByReplacingOccurrencesOfString:@" " withString:@""];
}
#pragma mark 是否空字符串
- (BOOL)isEmptyString
{
    return [self deleteAllWhitespaceString].length == 0 ? YES : NO;
}
@end
