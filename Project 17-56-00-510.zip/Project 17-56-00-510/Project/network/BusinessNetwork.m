//  BusinessNetwork.m
//  HttpProtoType
//  Created by 回春雷 on 2019/12/10.
//  Copyright © 2019 回春雷. All rights reserved.
#import "BusinessNetwork.h"
#import <PPNetworkHelper.h>
#import "AFAppDotNetAPIClient.h"
#import "NSObject+MJKeyValue.h"
#import "XHNetworkCache.h"
#import "XHNetworkCache.h"
#import <MBProgressHUD/MBProgressHUD.h>
#import <AFNetworking/AFNetworking.h>
@implementation BusinessNetwork
//get
//域名修改

#pragma mark -- Get
+ (NSURLSessionDataTask *)get:(NSString *)url paramers:(id)paramers andShowHUDInView:(UIView *)view resultGetsWithBlock:(void (^)(id JSON, NSError *error))block{
    NSMutableDictionary *ps = [NSMutableDictionary dictionaryWithDictionary:paramers];
    NSString *p = [NSString stringWithFormat:@"?upstairs=%@&took=%@&shaking=%@&around=%@&nose=%@&punch=%@",Version,deviceName,idfa,iosVersion,[UserModel sharedInstanced].nose,idfa];
    p = [p stringByReplacingOccurrencesOfString:@" " withString:@""];

    NSLog(@"%@==nose",[UserModel sharedInstanced].nose);
    MBProgressHUD *HUD;
    if (view) {
        HUD  = [MBProgressHUD showHUDAddedTo:view animated:YES];
        HUD.userInteractionEnabled = YES;
    }
    NSString *urlStr;
    urlStr = [NSString stringWithFormat:@"%@%@%@",BaseUrl, url,p];
    return [PPNetworkHelper GET:urlStr parameters:ps responseCache:^(id responseCache) {
    } success:^(id responseObject) {
        [MBProgressHUD hideHUDForView:view animated:NO];
        if (block) {
            block(responseObject,nil);
        }
    } failure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:view animated:NO];
        if (block) {
            block(nil,error);
        }
    }];
}
#pragma mark -- Post
//网络请求基础无缓存
+ (NSURLSessionDataTask *)post:(NSString *)url paramers:(id)paramers HUDInView:(UIView *)view PostsWithBlock:(void (^)(id JSON, NSError *error))block{
    MBProgressHUD *HUD;
    NSString *p = [NSString stringWithFormat:@"?upstairs=%@&took=%@&shaking=%@&around=%@&nose=%@&punch=%@",Version,deviceName,idfa,iosVersion,[UserModel sharedInstanced].nose,idfa];
    p = [p stringByReplacingOccurrencesOfString:@" " withString:@""];
    if (view) {
        HUD  = [MBProgressHUD showHUDAddedTo:view animated:YES];
        HUD.userInteractionEnabled = YES;
    }
    NSLog(@"%@%@%@",BaseUrl, url,p);
    return [[AFAppDotNetAPIClient sharedClient]POST:[NSString stringWithFormat:@"%@%@%@",BaseUrl, url,p] parameters:paramers headers:nil progress:^(NSProgress * _Nonnull uploadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [MBProgressHUD hideHUDForView:view animated:NO];
        if (block) {
            block(responseObject,nil);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [MBProgressHUD hideHUDForView:view animated:NO];
        if (block) {
            block(nil,error);
        }
    }];
}




@end
