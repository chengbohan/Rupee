// AFAppDotNetAPIClient.h

#import "AFAppDotNetAPIClient.h"

NSString * const AFAppDotNetAPIBaseURLString = BaseUrl;
@implementation AFAppDotNetAPIClient
+ (instancetype)sharedClient {
    static AFAppDotNetAPIClient *_sharedClient = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedClient = [[AFAppDotNetAPIClient alloc] initWithBaseURL:[NSURL URLWithString:AFAppDotNetAPIBaseURLString]];
        _sharedClient.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript", @"text/plain",@"text/html",@"image/*",nil];
        _sharedClient.requestSerializer.timeoutInterval = 30;
    });
    return _sharedClient;
}
@end
