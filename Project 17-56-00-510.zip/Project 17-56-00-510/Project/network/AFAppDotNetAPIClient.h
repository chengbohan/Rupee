// AFAppDotNetAPIClient.h


#import <Foundation/Foundation.h>
#import "AFHTTPSessionManager.h"
extern NSString * const AFAppDotNetAPIBaseURLString;
@interface AFAppDotNetAPIClient : AFHTTPSessionManager
+ (instancetype)sharedClient;

@end
