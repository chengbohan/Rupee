//
//  ViewController.m
//  Project
//
//  Created by 回春雷 on 2023/3/17.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "ViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIView *view = [[UIView alloc]init];
    [self.view addSubview:view];
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(20+navigationBarHeight);
        make.left.equalTo(self.view).offset(20);
        make.size.mas_equalTo(CGSizeMake(50, 20));
    }];
    view.backgroundColor = UIColor.blueColor;
}


@end
