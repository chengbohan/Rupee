//
//  MineCell.m
//  Project
//
//  Created by 回春雷 on 2023/4/5.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "MineCell.h"
#import <SDWebImage/SDWebImage.h>
@interface MineCell()
@property (nonatomic,strong)UIImageView *ai;
@property (nonatomic,strong)UILabel *al;
@property (nonatomic,strong)UIView *l1;


@end
@implementation MineCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if ([super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        UIView *a = [UIView new];
        [self.contentView addSubview:a];
        [a mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.contentView);
            make.left.equalTo(self.contentView);
            make.right.equalTo(self.contentView);
            make.height.mas_equalTo(SCALE(64));
        }];
        UIImageView *ai = [[UIImageView alloc]init];
        UIImage *aii = [UIImage imageNamed:@"me_list_icon_about"];
        ai.image = aii;
        [a addSubview:ai];
        [ai mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(a);
            make.left.equalTo(a).offset(SCALE(16));
        }];
        _ai = ai;
        UILabel *al = [[UILabel alloc]init];
        al.text = @"About us";
        al.textColor = RGBColor(35, 36, 40);
        al.font = DEF_FontSize_16;
        [a addSubview:al];
        [al mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(ai).offset(aii.size.width+SCALE(8));
            make.centerY.equalTo(ai);
        }];
        _al = al;
        UIImageView *jt = [[UIImageView alloc]init];
        jt.image = [UIImage imageNamed:@"details_list_icon_goto"];
        [a addSubview:jt];
        [jt mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(a).offset(-SCALE(16));
            make.centerY.equalTo(ai);
        }];
        
        UIView *l1 = [UIView new];
        l1.backgroundColor = RGBColor(169, 170, 184);
        [a addSubview:l1];
        [l1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(a).offset(SCALE(16));
            make.right.equalTo(a).offset(-SCALE(16));
            make.bottom.equalTo(a);
            make.height.mas_equalTo(1);
        }];
        _l1 = l1;

    }
    return self;
}
-(void)setSouce:(NSDictionary*)dict{
    [_ai sd_setImageWithURL:[NSURL URLWithString:dict[@"smiled"]] placeholderImage:[UIImage imageNamed:@"me_list_icon_about"]];
    _al.text = dict[@"sunday"];
    if ([dict[@"sunday"] isEqualToString:@"Settings"]) {
        _l1.hidden = true;
    }
}
@end
