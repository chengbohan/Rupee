//
//  MineViewController.m
//  Project
//
//  Created by 回春雷 on 2023/3/30.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "MineViewController.h"
#import <ReactiveObjC/ReactiveObjC.h>
#import "MineCell.h"
#import "WMZDialog.h"
#import "OrderViewController.h"
#import "SettingsViewController.h"
#import "WebViewControl.h"
@interface MineViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    WMZDialog *myAlert;
}

@property (nonatomic, strong)UITableView *tableView;
@property (nonatomic,strong)NSMutableArray *dataArray;
@property (nonatomic,strong)UIView *bom;
@end

@implementation MineViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:true];
    [BusinessNetwork get:@"/ruap/payment" paramers:@{} andShowHUDInView:self.view resultGetsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
        NSLog(@"%@",JSON);
        NSString *s = [NSString stringWithFormat:@"%@",JSON[@"glass"]];
        if ([s isEqualToString:@"0"]) {
            self->_dataArray = [NSMutableArray arrayWithArray:JSON[@"used"][@"entered"]];
            [self->_tableView reloadData];
            [self->_tableView mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(self->_bom).offset(SCALE(110));
                make.left.equalTo(self.view).offset(SCALE(16));
                make.right.equalTo(self.view).offset(-SCALE(16));
                make.height.mas_equalTo(SCALE(64)*self->_dataArray.count);
            }];
        }
    }];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = RGBColor(240, 241, 245);
    [self ui];
}

-(void)ui{
    UIImageView *banner = [[UIImageView alloc]init];
    [self.view addSubview:banner];
    banner.image = [UIImage imageNamed:@"me_bg_top"];
    [banner mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view);
        make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH, SCALE(228)));
    }];
    
    UIImageView *icon = [[UIImageView alloc]init];
    [self.view addSubview:icon];
    UIImage *image = [UIImage imageNamed:@"me_icon_avatar"];
    icon.image = image;
    [icon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(SCALE(64));
        make.centerX.equalTo(self.view);
    }];

    UILabel *name = [[UILabel alloc]init];
    name.text = @"856****42";
    name.textColor = RGBColor(255, 255, 255);
    name.font = [UIFont systemFontOfSize:18 weight:UIFontWeightBold];
    [name sizeToFit];
    [self.view addSubview:name];
    [name mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(icon).offset(image.size.height+SCALE(10));
        make.centerX.equalTo(self.view);
    }];

    
    UIView *mid = [[UIView alloc]init];
    [self.view addSubview:mid];
    [mid sizeToFit];
    [mid mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(SCALE(180));
        make.left.equalTo(self.view).offset(SCALE(6));
        make.right.equalTo(self.view).offset(-SCALE(6));
        make.height.mas_equalTo(SCALE(110));
    }];
    _bom = mid;
    UIImageView *p = [[UIImageView alloc]init];
    p.image = [UIImage imageNamed:@"me_orders_bg"];
    [mid addSubview:p];
    [p mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(mid);
        make.left.equalTo(mid);
        make.right.equalTo(mid);
        make.bottom.equalTo(mid);
    }];

    UIView *one = [UIView new];
    [mid addSubview:one];
    [one mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(mid);
        make.top.equalTo(mid);
        make.bottom.equalTo(mid);
        make.width.mas_equalTo(SCREEN_WIDTH/3);
    }];
    
    UIButton *oneb = [UIButton buttonWithType:UIButtonTypeCustom];
    UIImage *onei = [UIImage imageNamed:@"me_icon_selesai"];
    [oneb setBackgroundImage:onei forState:UIControlStateNormal];
    [mid addSubview:oneb];
    [oneb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(one);
        make.top.equalTo(one).offset(SCALE(16));
    }];
    
    UILabel *onel = [[UILabel alloc]init];
    onel.text = @"Applying";
    onel.font = DEF_FontSize_12;
    onel.textColor = RGBColor(35, 36, 40);
    [one addSubview:onel];
    [onel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(oneb).offset(onei.size.height+7);
        make.centerX.equalTo(one);
    }];
    
    UIView *two = [UIView new];
    [mid addSubview:two];
    [two mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(mid).offset(SCREEN_WIDTH/3);
        make.top.equalTo(mid);
        make.bottom.equalTo(mid);
        make.width.mas_equalTo(SCREEN_WIDTH/3);
    }];
    
    UIButton *twob = [UIButton buttonWithType:UIButtonTypeCustom];
    [twob setBackgroundImage:[UIImage imageNamed:@"me_icon_cair"] forState:UIControlStateNormal];
    [mid addSubview:twob];
    [twob mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(two);
        make.top.equalTo(two).offset(SCALE(16));
    }];
    
    UILabel *twol = [[UILabel alloc]init];
    twol.text = @"Repay";
    twol.font = DEF_FontSize_12;
    twol.textColor = RGBColor(35, 36, 40);
    [two addSubview:twol];
    [twol mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(onel);
        make.centerX.equalTo(two);
    }];

    
    UIView *three = [UIView new];
    [mid addSubview:three];
    [three mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(mid);
        make.top.equalTo(mid);
        make.bottom.equalTo(mid);
        make.width.mas_equalTo(SCREEN_WIDTH/3);
    }];
    
    UIButton *threeb = [UIButton buttonWithType:UIButtonTypeCustom];
    [threeb setBackgroundImage:[UIImage imageNamed:@"me_icon_lunas"] forState:UIControlStateNormal];
    [mid addSubview:threeb];
    [threeb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(three);
        make.top.equalTo(three).offset(SCALE(16));
    }];

    UILabel *threel = [[UILabel alloc]init];
    threel.text = @"Finish";
    threel.font = DEF_FontSize_12;
    threel.textColor = RGBColor(35, 36, 40);
    [three addSubview:threel];
    [threel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(onel);
        make.centerX.equalTo(three);
    }];
    [self tableView];
    [self.view addSubview:_tableView];
    _tableView.layer.cornerRadius = 5;
    [[oneb rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
        OrderViewController *vc = [OrderViewController new];
        [self.navigationController pushViewController:vc animated:YES];
    }];
    [[twob rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
        OrderViewController *vc = [OrderViewController new];
        [self.navigationController pushViewController:vc animated:YES];
    }];
    [[threeb rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
        OrderViewController *vc = [OrderViewController new];
        [self.navigationController pushViewController:vc animated:YES];
    }];


}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    NSDictionary *dic = _dataArray[indexPath.row];
    if ([dic[@"sunday"] isEqualToString:@"Settings"]) {
        [self dailog1];
        SettingsViewController * vc = [[SettingsViewController alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
    } else {
        WebViewControl *web = [WebViewControl new];
        web.URLString = dic[@"see"];
        [self.navigationController pushViewController:web animated:NO];
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return SCALE(64);
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    MineCell *mineCell = [tableView dequeueReusableCellWithIdentifier:@"mineCell"];
    if (mineCell==nil)
    {
        mineCell=[[MineCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"mineCell"];
    }
    [mineCell setSouce:_dataArray[indexPath.row]];
    mineCell.selectionStyle = UITableViewCellSelectionStyleNone;
    return mineCell;
}
-(UITableView *)tableView {
    if(!_tableView){
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _tableView;
}


-(void)dailog{
    myAlert =
    Dialog()
    .wCustomMainViewSet(^(UIView *mainView) {
    })
    .wHeightSet(SCALE(422))
    .wTypeSet(DialogTypeMyView)
    .wWidthSet(Device_Dialog_Width*0.8)
    .wShowAnimationSet(AninatonZoomInCombin)
    .wHideAnimationSet(AninatonZoomOut)
    .wMyDiaLogViewSet(^UIView *(UIView *mainView) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setImage:[UIImage imageNamed:@"details_list_icon_del"] forState:UIControlStateNormal];
        [mainView addSubview:btn];
        [btn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(mainView).offset(-SCALE(16));
            make.top.equalTo(mainView).offset(SCALE(16));
            make.size.mas_equalTo(CGSizeMake(SCALE(12), SCALE(12)));
        }];
        UIImageView* t = [UIImageView new];
        t.image = [UIImage imageNamed:@"pop_idcorrect"];
        [mainView addSubview:t];
        [t mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(mainView).offset(SCALE(42));
            make.left.equalTo(mainView).offset(SCALE(22));
            make.right.equalTo(mainView).offset(-SCALE(22));
            make.height.mas_equalTo(SCALE(176));
        }];
        UIImageView* b = [UIImageView new];
        b.image = [UIImage imageNamed:@"pop_idwrong"];
        [mainView addSubview:b];
        [b mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(t).offset(SCALE(192));
            make.left.equalTo(mainView).offset(SCALE(22));
            make.right.equalTo(mainView).offset(-SCALE(22));
            make.height.mas_equalTo(SCALE(105));
        }];
        UIButton *send = [UIButton buttonWithType:UIButtonTypeCustom];
        [send setBackgroundImage:[UIImage imageNamed:@"btn_pop_blue"] forState:UIControlStateNormal];
        [send setTitle:@"Confirm" forState:UIControlStateNormal];
        [send setTitleColor:RGBColor(255, 255, 255) forState:UIControlStateNormal];
        send.titleLabel.font = DEF_FontSize_14;
        [mainView addSubview:send];
        [send mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(mainView).offset(-SCALE(24));
            make.centerX.equalTo(mainView);
            make.size.mas_equalTo(CGSizeMake(SCALE(226), SCALE(36)));
        }];
        mainView.layer.masksToBounds = YES;
        mainView.layer.cornerRadius = 10;
        [[btn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
        }];
        [[send rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
        }];
        return nil;
    })
    .wStart();
}


-(void)dailog1{
    myAlert =
    Dialog()
    .wCustomMainViewSet(^(UIView *mainView) {
    })
    .wHeightSet(SCALE(466))
    .wTypeSet(DialogTypeMyView)
    .wWidthSet(Device_Dialog_Width*0.8)
    .wShowAnimationSet(AninatonZoomInCombin)
    .wHideAnimationSet(AninatonZoomOut)
    .wMyDiaLogViewSet(^UIView *(UIView *mainView) {
        UIView *v = [UIView new];
        [mainView addSubview:v];
        v.layer.masksToBounds = YES;
        v.layer.cornerRadius = 10;
        v.backgroundColor = RGBColor(255, 255, 255);
        [v mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(mainView).offset(SCALE(24));
            make.right.equalTo(mainView);
            make.left.equalTo(mainView);
            make.bottom.equalTo(mainView);
        }];
        UIImageView* btn = [UIImageView new];
        btn.image = [UIImage imageNamed:@"pop_bg_top"];
        [mainView addSubview:btn];
        [btn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(mainView);
            make.left.equalTo(mainView);
            make.top.equalTo(mainView).offset(SCALE(24));
            make.height.mas_equalTo(SCALE(92));
        }];
        UIImageView* t = [UIImageView new];
        t.image = [UIImage imageNamed:@"pop_pic_logout"];
        [mainView addSubview:t];
        [t mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(mainView);
            make.centerX.equalTo(mainView);
            make.height.mas_equalTo(SCALE(108));
        }];
        
        UILabel *l = [UILabel new];
        l.text = @"Important Tips";
        l.textColor = RGBColor(35, 36, 40);
        l.font = DEF_FontSize_16;
        [l sizeToFit];
        [mainView addSubview:l];
        [l mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(mainView);
            make.top.equalTo(t).offset(SCALE(135));
        }];
        
        UILabel *text = [UILabel new];
        text.text = @"The account cannot be restored after cancellation. To ensure the security of your account please confirm that the services related to the account have been properly handled before application and pay attention to the following provisions:";
        text.textColor = RGBColor(35, 36, 40);
        text.numberOfLines = 0;
        text.font = DEF_FontSize_14;
        [text sizeToFit];
        NSMutableAttributedString *attributedString =
        [[NSMutableAttributedString alloc] initWithString:text.text];
        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
        [paragraphStyle setLineSpacing:15];
        [attributedString addAttribute:NSParagraphStyleAttributeName
                                 value:paragraphStyle
                                 range:NSMakeRange(0, [text.text length])];
        [mainView addSubview:text];
        [text mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(l).offset(l.bounds.size.height+SCALE(12));
            make.left.equalTo(mainView).offset(SCALE(24));
            make.right.equalTo(mainView).offset(-SCALE(24));
        }];
        
        UILabel *ll = [UILabel new];
        ll.text = @"All borrowings have been completed";
        ll.textColor = RGBColor(226, 78, 78);
        ll.font = DEF_FontSize_14;
        [ll sizeToFit];
        [mainView addSubview:ll];
        [ll mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(mainView);
            make.top.equalTo(t).offset(SCALE(300));
        }];

        UIButton *s = [UIButton buttonWithType:UIButtonTypeCustom];
        [s setImage:[UIImage imageNamed:@"signin_icon_select"] forState:UIControlStateNormal];
        [s setImage:[UIImage imageNamed:@"signin_icon_selected"] forState:UIControlStateNormal];
        [mainView addSubview:s];
        [s mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(mainView).offset(SCALE(23));
            make.top.equalTo(ll).offset(ll.bounds.size.height+SCALE(15));
            make.size.mas_equalTo(CGSizeMake(SCALE(16), SCALE(16)));
        }];
        UILabel *lls = [UILabel new];
        lls.text = @"I have read and agreed to the above.";
        lls.textColor = RGBColor(169, 170, 184);
        lls.font = [UIFont systemFontOfSize:14 weight:UIFontWeightThin];
        [lls sizeToFit];
        [mainView addSubview:lls];
        [lls mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(s);
            make.left.equalTo(s).offset(SCALE(16)+3);
        }];
        UIButton *send = [UIButton buttonWithType:UIButtonTypeCustom];
        [send setBackgroundImage:[UIImage imageNamed:@"btn_pop_blue"] forState:UIControlStateNormal];
        [send setTitle:@"Confirm" forState:UIControlStateNormal];
        [send setTitleColor:RGBColor(255, 255, 255) forState:UIControlStateNormal];
        send.titleLabel.font = DEF_FontSize_14;
        [mainView addSubview:send];
        [send mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(mainView).offset(-SCALE(20));
            make.centerX.equalTo(mainView);
            make.size.mas_equalTo(CGSizeMake(SCALE(226), SCALE(36)));
        }];
        UIButton *send1 = [UIButton buttonWithType:UIButtonTypeCustom];
        [send1 setBackgroundImage:[UIImage imageNamed:@"btn_pop_blue"] forState:UIControlStateNormal];
        [send1 setTitle:@"Confirm" forState:UIControlStateNormal];
        [send1 setTitleColor:RGBColor(255, 255, 255) forState:UIControlStateNormal];
        send1.titleLabel.font = DEF_FontSize_14;
        [mainView addSubview:send1];
        [send1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(send).offset(-SCALE(48));
            make.centerX.equalTo(mainView);
            make.size.mas_equalTo(CGSizeMake(SCALE(226), SCALE(36)));
        }];

        mainView.layer.masksToBounds = YES;
        mainView.layer.cornerRadius = 10;
        mainView.backgroundColor = [UIColor clearColor];
        [[send rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
        }];
        [[send1 rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
        }];
        return nil;
    })
    .wStart();
}

-(void)dailog2{
    myAlert =
    Dialog()
    .wCustomMainViewSet(^(UIView *mainView) {
    })
    .wHeightSet(SCALE(274))
    .wTypeSet(DialogTypeMyView)
    .wWidthSet(Device_Dialog_Width*0.8)
    .wShowAnimationSet(AninatonZoomInCombin)
    .wHideAnimationSet(AninatonZoomOut)
    .wMyDiaLogViewSet(^UIView *(UIView *mainView) {
        UIView *v = [UIView new];
        [mainView addSubview:v];
        v.layer.masksToBounds = YES;
        v.layer.cornerRadius = 10;
        v.backgroundColor = RGBColor(255, 255, 255);
        [v mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(mainView).offset(SCALE(24));
            make.right.equalTo(mainView);
            make.left.equalTo(mainView);
            make.bottom.equalTo(mainView);
        }];
        UIImageView* btn = [UIImageView new];
        btn.image = [UIImage imageNamed:@"pop_bg_top"];
        [mainView addSubview:btn];
        [btn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(mainView);
            make.left.equalTo(mainView);
            make.top.equalTo(mainView).offset(SCALE(24));
            make.height.mas_equalTo(SCALE(92));
        }];
        UIImageView* t = [UIImageView new];
        t.image = [UIImage imageNamed:@"pop_pic_logout"];
        [mainView addSubview:t];
        [t mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(mainView);
            make.centerX.equalTo(mainView);
            make.height.mas_equalTo(SCALE(108));
        }];
        
        UILabel *l = [UILabel new];
        l.text = @"Are you sure to log out?";
        l.textColor = RGBColor(35, 36, 40);
        l.font = DEF_FontSize_14;
        [mainView addSubview:l];
        [l mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(mainView);
            make.top.equalTo(t).offset(SCALE(140));
        }];
        UIButton *send = [UIButton buttonWithType:UIButtonTypeCustom];
        [send setBackgroundImage:[UIImage imageNamed:@"btn_pop_blue"] forState:UIControlStateNormal];
        [send setTitle:@"Confirm" forState:UIControlStateNormal];
        [send setTitleColor:RGBColor(255, 255, 255) forState:UIControlStateNormal];
        send.titleLabel.font = DEF_FontSize_14;
        [mainView addSubview:send];
        [send mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(mainView).offset(-SCALE(28));
            make.centerX.equalTo(mainView);
            make.size.mas_equalTo(CGSizeMake(SCALE(226), SCALE(36)));
        }];
        UIButton *send1 = [UIButton buttonWithType:UIButtonTypeCustom];
        [send1 setBackgroundImage:[UIImage imageNamed:@"btn_pop_blue"] forState:UIControlStateNormal];
        [send1 setTitle:@"Confirm" forState:UIControlStateNormal];
        [send1 setTitleColor:RGBColor(255, 255, 255) forState:UIControlStateNormal];
        send1.titleLabel.font = DEF_FontSize_14;
        [mainView addSubview:send1];
        [send1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(send).offset(-SCALE(48));
            make.centerX.equalTo(mainView);
            make.size.mas_equalTo(CGSizeMake(SCALE(226), SCALE(36)));
        }];
        
        mainView.layer.masksToBounds = YES;
        mainView.layer.cornerRadius = 10;
        mainView.backgroundColor = [UIColor clearColor];
        [[send rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
        }];
        [[send1 rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
        }];
        return nil;
    })
    .wStart();
}


@end
