
#import <Foundation/Foundation.h>


/**
 本地用户数据存储
 */
@interface UserModel : NSObject


+ (UserModel*)sharedInstanced;


/**
 历史搜索记录数据
 */
@property (nonatomic, strong, readonly) NSMutableArray *historyArray;
@property (nonatomic, strong, readonly) NSString * ever;
@property (nonatomic, strong, readonly) NSString * laughed;
@property (nonatomic, strong, readonly) NSString * nose;
@property (nonatomic, strong, readonly) NSString * regular;
@property (nonatomic, strong, readonly) NSString * uid;

- (void)setHistoryArray:(NSMutableArray *)historyArray;
- (void)setEver:(NSString *)ever;
- (void)setLaughed:(NSString *)laughed;
- (void)setNose:(NSString *)nose;
- (void)setRegular:(NSString *)regular;
- (void)setUid:(NSString *)uid;
- (void)removeAllInfo;

@end
