
#import "UserModel.h"
#import <Security/Security.h>

static NSString * const KEY_HISTORY = @"com.project.his";
static NSString * const KEY_EVER = @"com.project.ever";
static NSString * const KEY_LAUGHED = @"com.project.laughed";
static NSString * const KEY_NOSE = @"com.project.nose";
static NSString * const KEY_REGULAR = @"com.project.regular";
static NSString * const KEY_UID = @"com.project.uid";

@interface UserModel();
@end
@implementation UserModel

+(UserModel*)sharedInstanced{
    static UserModel *_userLogon = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _userLogon = [[UserModel alloc] init];
    });
    return _userLogon;
}      

- (id)init{
    self = [super init];
    if (!self) {
        return nil;
    }
    return self;
}

- (void)setHistoryArray:(NSMutableArray *)historyArray {
    if (!historyArray) {
        [[NSUserDefaults standardUserDefaults] setObject:[NSMutableArray arrayWithArray:@[]] forKey:KEY_HISTORY];
        [[NSUserDefaults standardUserDefaults] synchronize];
        return;
    }
    
    NSMutableArray *localCookie= [[NSUserDefaults standardUserDefaults] objectForKey:KEY_HISTORY];
    if (localCookie == historyArray) {
        return;
    }
    
    [[NSUserDefaults standardUserDefaults] setObject:historyArray forKey:KEY_HISTORY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSMutableArray *)historyArray {
    [[NSUserDefaults standardUserDefaults] registerDefaults:@{KEY_HISTORY:[NSMutableArray arrayWithArray:@[]]}];
    return [[NSUserDefaults standardUserDefaults] objectForKey:KEY_HISTORY];
}
- (void)setEver:(NSString *)ever{
    if (!ever) {
        [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:KEY_EVER];
        [[NSUserDefaults standardUserDefaults] synchronize];
        return;
    }
    [[NSUserDefaults standardUserDefaults] setObject:ever forKey:KEY_EVER];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
- (NSString *)ever{
    [[NSUserDefaults standardUserDefaults] registerDefaults:@{KEY_EVER:@""}];
    return [[NSUserDefaults standardUserDefaults] objectForKey:KEY_EVER];
}
- (NSString *)laughed{
    [[NSUserDefaults standardUserDefaults] registerDefaults:@{KEY_LAUGHED:@""}];
    return [[NSUserDefaults standardUserDefaults] objectForKey:KEY_LAUGHED];
}
- (NSString *)nose{
    [[NSUserDefaults standardUserDefaults] registerDefaults:@{KEY_NOSE:@""}];
    return [[NSUserDefaults standardUserDefaults] objectForKey:KEY_NOSE];
}
- (NSString *)regular{
    [[NSUserDefaults standardUserDefaults] registerDefaults:@{KEY_REGULAR:@""}];
    return [[NSUserDefaults standardUserDefaults] objectForKey:KEY_REGULAR];
}
- (NSString *)uid{
    [[NSUserDefaults standardUserDefaults] registerDefaults:@{KEY_UID:@""}];
    return [[NSUserDefaults standardUserDefaults] objectForKey:KEY_UID];
}
- (void)setLaughed:(NSString *)laughed{
    if (!laughed) {
        [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:KEY_LAUGHED];
        [[NSUserDefaults standardUserDefaults] synchronize];
        return;
    }
    [[NSUserDefaults standardUserDefaults] setObject:laughed forKey:KEY_LAUGHED];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
- (void)setNose:(NSString *)nose{
    if (!nose) {
        [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:KEY_NOSE];
        [[NSUserDefaults standardUserDefaults] synchronize];
        return;
    }
    [[NSUserDefaults standardUserDefaults] setObject:nose forKey:KEY_NOSE];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
- (void)setRegular:(NSString *)regular{
    if (!regular) {
        [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:KEY_REGULAR];
        [[NSUserDefaults standardUserDefaults] synchronize];
        return;
    }
    [[NSUserDefaults standardUserDefaults] setObject:regular forKey:KEY_REGULAR];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
- (void)setUid:(NSString *)uid{
    if (!uid) {
        [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:KEY_UID];
        [[NSUserDefaults standardUserDefaults] synchronize];
        return;
    }
    [[NSUserDefaults standardUserDefaults] setObject:uid forKey:KEY_UID];
    [[NSUserDefaults standardUserDefaults] synchronize];

}


#pragma mark -
- (void)removeAllInfo{
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:KEY_HISTORY];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:KEY_EVER];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:KEY_LAUGHED];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:KEY_NOSE];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:KEY_REGULAR];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:KEY_UID];
    [[NSUserDefaults standardUserDefaults] synchronize];
}


@end
