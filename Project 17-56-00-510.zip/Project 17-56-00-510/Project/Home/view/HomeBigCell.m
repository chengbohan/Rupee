//
//  HomeBigCell.m
//  Project
//
//  Created by 回春雷 on 2023/4/4.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "HomeBigCell.h"
#import <SDWebImage/SDWebImage.h>
#import <ReactiveObjC/ReactiveObjC.h>

@interface HomeBigCell()
@property (nonatomic,strong)UIImageView *icon;
@property (nonatomic,strong)UILabel *lab;
@property (nonatomic,strong)UILabel *ll;
@property (nonatomic,strong)UILabel *lll;
@property (nonatomic,strong)UILabel *lab1;
@property (nonatomic,strong)UILabel *lab2;
@property (nonatomic,strong)UILabel *lab3;
@property (nonatomic,strong)UILabel *rlab1;
@property (nonatomic,strong)UILabel *rlab2;
@property (nonatomic,strong)UILabel *rlab3;


@end
@implementation HomeBigCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if ([super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        UIView* view=  [UIView new];
        [self.contentView addSubview:view];
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.contentView);
            make.left.equalTo(self.contentView).offset(SCALE(6));
            make.right.equalTo(self.contentView).offset(SCALE(-6));
            make.height.mas_equalTo(SCALE_HEIGHT(273));
        }];
        UIImageView *p = [[UIImageView alloc]init];
        p.image = [UIImage imageNamed:@"homepage_bigcard_bg"];
        [view addSubview:p];
        [p mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(view);
            make.left.equalTo(view);
            make.right.equalTo(view);
            make.bottom.equalTo(view);
        }];
        UIImageView *icon = [UIImageView new];
        UIImage *img = [UIImage imageNamed:@"homepage_logo_rupeeapp"];
        icon.image = img;
        [view addSubview:icon];
        [icon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(view).offset(SCALE_HEIGHT(15));
            make.left.equalTo(view).offset(SCALE(25));
            make.size.mas_equalTo(CGSizeMake(42, 42));
        }];
        _icon = icon;
        UILabel *lab = [UILabel new];
        lab.text = @"RupeeApp";
        lab.font = DEF_FontSize_17;
        lab.textColor = RGBColor(35, 36, 40);
        [view addSubview:lab];
        [lab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(icon);
            make.left.equalTo(icon).offset(img.size.width + SCALE(7));
        }];
        _lab = lab;
        UILabel *lab1 = [UILabel new];
        lab1.text = @"Loan amount";
        lab1.font = DEF_FontSize_14;
        lab1.textColor = RGBColor(169, 170, 184);
        [lab1 sizeToFit];
        [view addSubview:lab1];
        [lab1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(icon).offset(img.size.height + SCALE_HEIGHT(10));
            make.centerX.equalTo(view);
        }];
        
        _ll = lab1;
        UILabel *lab2 = [UILabel new];
        lab2.text = @"₹88.000";
        lab2.font = [UIFont systemFontOfSize:32 weight:UIFontWeightBold];
        lab2.textColor = RGBColor(45, 86, 204);
        [lab2 sizeToFit];
        [view addSubview:lab2];
        [lab2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(lab1).offset(lab1.bounds.size.height + SCALE_HEIGHT(4));
            make.centerX.equalTo(view);
        }];
        _lll = lab2;
        UIView *line = [UIView new];
        [view addSubview:line];
        line.backgroundColor = RGBColor(169, 170, 184);
        [line mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(lab2).offset(lab2.bounds.size.height + SCALE_HEIGHT(41));
            make.centerX.equalTo(view);
            make.size.mas_offset(CGSizeMake(1, SCALE_HEIGHT(27)));
        }];
        
        UIView *l = [UIView new];
        [view addSubview:l];
        [l mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(lab2).offset(lab2.bounds.size.height+SCALE_HEIGHT(22));
            make.left.equalTo(view).offset(SCALE(10));
            make.right.equalTo(line);
            make.bottom.equalTo(line);
        }];
        
        UILabel *llab1 = [UILabel new];
        llab1.text = @"Interest rate";
        llab1.font = DEF_FontSize_14;
        llab1.textColor = RGBColor(169, 170, 184);
        [llab1 sizeToFit];
        [l addSubview:llab1];
        [llab1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(l);
            make.centerX.equalTo(l);
        }];
        _lab1 = llab1;
        UIView *ll = [UIView new];
        [l addSubview:ll];
        [ll mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(llab1);
            make.centerY.equalTo(line);
            make.top.equalTo(llab1).offset(lab1.bounds.size.height + SCALE_HEIGHT(6));
            make.bottom.equalTo(line);
        }];
        
        UILabel *llab2 = [UILabel new];
        llab2.text = @"0.05%";
        llab2.font = [UIFont systemFontOfSize:24 weight:UIFontWeightBold];
        llab2.textColor = RGBColor(45, 86, 204);
        [llab2 sizeToFit];
        [ll addSubview:llab2];
        [llab2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(ll);
            make.left.equalTo(ll);
        }];
        _lab2 = llab2;
        UILabel *llab3 = [UILabel new];
        llab3.text = @"/days";
        llab3.font = DEF_FontSize_14;
        llab3.textColor = RGBColor(35, 36, 40);
        [llab3 sizeToFit];
        [ll addSubview:llab3];
        [llab3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(llab2).offset(-SCALE_HEIGHT(3));
            make.left.equalTo(llab2).offset(llab2.bounds.size.width);
            make.right.equalTo(ll);
        }];
        _lab3 = llab3;
        
        UIView *r = [UIView new];
        [view addSubview:r];
        [r mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(lab2).offset(lab2.bounds.size.height+SCALE_HEIGHT(22));
            make.right.equalTo(view).offset(-SCALE(10));
            make.left.equalTo(line);
            make.bottom.equalTo(line);
        }];
        
        UILabel *rlab1 = [UILabel new];
        rlab1.text = @"Loan term";
        rlab1.font = DEF_FontSize_14;
        rlab1.textColor = RGBColor(169, 170, 184);
        [rlab1 sizeToFit];
        [r addSubview:rlab1];
        [rlab1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(r);
            make.centerX.equalTo(r);
        }];
        _rlab1 =rlab1;
        UIView *rl = [UIView new];
        [r addSubview:rl];
        [rl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(rlab1);
            make.centerY.equalTo(line);
            make.top.equalTo(rlab1).offset(rlab1.bounds.size.height + SCALE_HEIGHT(6));
            make.bottom.equalTo(line);
        }];
        
        UILabel *rlab2 = [UILabel new];
        rlab2.text = @"91";
        rlab2.font = [UIFont systemFontOfSize:24 weight:UIFontWeightBold];
        rlab2.textColor = RGBColor(45, 86, 204);
        [rlab2 sizeToFit];
        [rl addSubview:rlab2];
        [rlab2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(rl);
            make.left.equalTo(rl);
        }];
        _rlab2 = rlab2;
        UILabel *rlab3 = [UILabel new];
        rlab3.text = @"days";
        rlab3.font = DEF_FontSize_14;
        rlab3.textColor = RGBColor(35, 36, 40);
        [rlab3 sizeToFit];
        [rl addSubview:rlab3];
        [rlab3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(rlab2).offset(-SCALE_HEIGHT(3));
            make.left.equalTo(rlab2).offset(rlab2.bounds.size.width);
            make.right.equalTo(rl);
        }];
        _rlab3 = rlab3;
        UIButton *send = [UIButton buttonWithType:UIButtonTypeCustom];
        [send setBackgroundImage:[UIImage imageNamed:@"btn_card_long_bg_blue"] forState:UIControlStateNormal];
        [send setTitle:@"Get loan now" forState:UIControlStateNormal];
        send.titleLabel.font = DEF_FontSize_14;
        send.titleLabel.textColor = RGBColor(255, 255, 255);
        [view addSubview:send];
        [send mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(view);
            make.top.equalTo(line).offset(SCALE_HEIGHT(25)+SCALE_HEIGHT(27));
            make.size.mas_offset(CGSizeMake(SCALE(276), SCALE_HEIGHT(36)));
        }];
        
        UIImageView *b = [UIImageView new];
        b.image = [UIImage imageNamed:@"homepage_bigcard_step"];
        [self.contentView addSubview:b];
        [b mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(view).offset(SCALE_HEIGHT(274));
            make.left.equalTo(view);
            make.right.equalTo(view);
            make.height.mas_equalTo(SCALE(107));
        }];

        _send = send;
        
        
    }
    return  self;
}

-(void)setSouce:(NSDictionary*)dict{
    [_icon sd_setImageWithURL:[NSURL URLWithString:dict[@"volunteer"]] placeholderImage:[UIImage imageNamed:@"homepage_logo_rupeeapp"]];
    NSArray *day = [dict[@"bring"] componentsSeparatedByString:@" "];
    NSArray *time = [dict[@"them"] componentsSeparatedByString:@" "];
    self.lab.text = [NSString stringWithFormat:@"%@",dict[@"payment"]];
//    self.d.text = [NSString stringWithFormat:@"%@",dict[@"bring"]];
    _ll.text = [NSString stringWithFormat:@"%@",dict[@"main"]];
    _lll.text = [NSString stringWithFormat:@"%@",dict[@"part"]];
    self.rlab1.text = [NSString stringWithFormat:@"%@",dict[@"end"]];
    self.rlab2.text = [NSString stringWithFormat:@"%@",day[0]];
    self.rlab3.text = [NSString stringWithFormat:@"%@",day[1]];
    self.lab1.text = [NSString stringWithFormat:@"%@",dict[@"tags"]];
    self.lab2.text = [NSString stringWithFormat:@"%@",time[0]];
    self.lab3.text = [NSString stringWithFormat:@"%@",time[1]];
}
@end
