//
//  HomeCell.m
//  Project
//
//  Created by 回春雷 on 2023/4/4.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "HomeCell.h"
#import <SDWebImage/SDWebImage.h>
@interface HomeCell()
@property (nonatomic,strong)UIImageView *icon;
@property (nonatomic,strong)UILabel *lab;
@property (nonatomic,strong)UILabel *d;
@property (nonatomic,strong)UILabel *lab1;
@property (nonatomic,strong)UILabel *lab2;
@property (nonatomic,strong)UILabel *rlab1;
@property (nonatomic,strong)UILabel *rlab2;

@end

@implementation HomeCell
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if ([super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        UIView *bigcart = [UIView new];
        [self.contentView addSubview:bigcart];
        [bigcart mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.contentView);
            make.left.equalTo(self.contentView).offset(SCALE(6));
            make.right.equalTo(self.contentView).offset(SCALE(-6));
            make.height.mas_equalTo(SCALE_HEIGHT(138));
        }];
        UIImageView *i1 = [UIImageView new];
        i1.image = [UIImage imageNamed:@"homepage_listcard_bg"];
        [bigcart addSubview:i1];
        [i1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(bigcart);
            make.right.equalTo(bigcart);
            make.left.equalTo(bigcart);
            make.bottom.equalTo(bigcart);
        }];
        UIImageView *icon = [UIImageView new];
        UIImage *img = [UIImage imageNamed:@"homepage_logo_rupeeapp"];
        icon.image = img;
        [bigcart addSubview:icon];
        [icon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(bigcart).offset(SCALE_HEIGHT(16));
            make.left.equalTo(bigcart).offset(SCALE(26));
            make.size.mas_equalTo(CGSizeMake(42, 42));
        }];
        _icon = icon;
        UILabel *lab = [UILabel new];
        lab.text = @"Groww Fund";
        lab.font = DEF_FontSize_17;
        lab.textColor = RGBColor(35, 36, 40);
        [lab sizeToFit];
        [bigcart addSubview:lab];
        [lab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(icon);
            make.left.equalTo(icon).offset(img.size.width + SCALE(7));
        }];
        _lab = lab;
        UILabel *d = [UILabel new];
        d.textAlignment = NSTextAlignmentCenter;
        d.text = @"91days";
        d.font = DEF_FontSize_12;
        d.textColor = RGBColor(45, 86, 204);
        d.backgroundColor = RGBColor(240, 241, 245);
        d.layer.masksToBounds = YES;
        d.layer.cornerRadius = 10.5;
        [bigcart addSubview:d];
        [d mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(icon);
            make.left.equalTo(lab).offset(lab.bounds.size.width + SCALE(7));
            make.size.mas_equalTo(CGSizeMake(58, 18));
        }];
        _d = d;
        UILabel *lab1 = [UILabel new];
        lab1.text = @"Loan amount";
        lab1.font = DEF_FontSize_12;
        lab1.textColor = RGBColor(169, 170, 184);
        [lab1 sizeToFit];
        [bigcart addSubview:lab1];
        [lab1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(icon).offset(42 + SCALE_HEIGHT(13));
            make.left.equalTo(icon);
        }];
        
        _lab1 = lab1;
        UILabel *lab2 = [UILabel new];
        lab2.text = @"₹88.000";
        lab2.font = [UIFont systemFontOfSize:16 weight:UIFontWeightBold];
        lab2.textColor = RGBColor(45, 86, 204);
        [lab2 sizeToFit];
        [bigcart addSubview:lab2];
        [lab2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(lab1).offset(lab1.bounds.size.height);
            make.left.equalTo(icon);
        }];
        _lab2 = lab2;
        
        UILabel *rlab1 = [UILabel new];
        rlab1.text = @"Interest rate";
        rlab1.font = DEF_FontSize_12;
        rlab1.textColor = RGBColor(169, 170, 184);
        [rlab1 sizeToFit];
        [bigcart addSubview:rlab1];
        [rlab1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(lab1);
            make.left.equalTo(lab1).offset(lab1.bounds.size.width + SCALE(21));
        }];
        _rlab1 = rlab1;
        
        UILabel *rlab2 = [UILabel new];
        rlab2.text = @"0.05%";
        rlab2.font = [UIFont systemFontOfSize:16 weight:UIFontWeightBold];
        rlab2.textColor = RGBColor(45, 86, 204);
        [rlab2 sizeToFit];
        [bigcart addSubview:rlab2];
        [rlab2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(rlab1).offset(rlab1.bounds.size.height);
            make.left.equalTo(rlab1);
        }];
        _rlab2 = rlab2;
        UIButton *send = [UIButton buttonWithType:UIButtonTypeCustom];
        [send setBackgroundImage:[UIImage imageNamed:@"btn_card_short_bg_yellow"] forState:UIControlStateNormal];
        [send setTitle:@"Loan" forState:UIControlStateNormal];
        send.titleLabel.font = DEF_FontSize_14;
        send.titleLabel.textColor = RGBColor(255, 255, 255);
        [bigcart addSubview:send];
        [send mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(bigcart).offset(-SCALE(26));
            make.bottom.equalTo(rlab2);
            make.size.mas_offset(CGSizeMake(SCALE(98), SCALE_HEIGHT(28)));
        }];
        _send = send;
        
    }
    return  self;
}
-(void)setSouce:(NSDictionary*)dict{
    [_icon sd_setImageWithURL:[NSURL URLWithString:dict[@"volunteer"]] placeholderImage:[UIImage imageNamed:@"homepage_logo_rupeeapp"]];
    self.lab.text = [NSString stringWithFormat:@"%@",dict[@"payment"]];
    self.d.text = [NSString stringWithFormat:@"%@",dict[@"bring"]];
    self.rlab1.text = [NSString stringWithFormat:@"%@",dict[@"lady"]];
    self.rlab2.text = [NSString stringWithFormat:@"%@",dict[@"rang"]];
    self.lab1.text = [NSString stringWithFormat:@"%@",dict[@"main"]];
    self.lab2.text = [NSString stringWithFormat:@"%@",dict[@"monday"]];
    NSString *s = dict[@"room"];
    if ([s isEqualToString:@"yellow"]) {
        _send.userInteractionEnabled = YES;
        [_send setBackgroundImage:[UIImage imageNamed:@"btn_card_short_bg_yellow"] forState:UIControlStateNormal];
    }else{
        _send.userInteractionEnabled = NO;
        [_send setBackgroundImage:[UIImage imageNamed:@"btn_card_short_bg_grey"] forState:UIControlStateNormal];
    }

}

@end
