//
//  HomeSmallCell.m
//  Project
//
//  Created by 回春雷 on 2023/4/4.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "HomeSmallCell.h"
#import <SDWebImage/SDWebImage.h>
@interface HomeSmallCell()
@property (nonatomic,strong)UIImageView *icon;
@property (nonatomic,strong)UILabel *lab;
@property (nonatomic,strong)UILabel *d;
@property (nonatomic,strong)UILabel *lab1;
@property (nonatomic,strong)UILabel *lab2;
@property (nonatomic,strong)UILabel *rlab1;
@property (nonatomic,strong)UILabel *rlab2;
@end
@implementation HomeSmallCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if ([super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        UIView* view=  [UIView new];
        [self.contentView addSubview:view];
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.contentView);
            make.left.equalTo(self.contentView).offset(SCALE(6));
            make.right.equalTo(self.contentView).offset(SCALE(-6));
            make.height.mas_equalTo(SCALE_HEIGHT(211));
        }];
        UIImageView *p = [[UIImageView alloc]init];
        p.image = [UIImage imageNamed:@"homepage_smallcard_bg"];
        [view addSubview:p];
        [p mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(view);
            make.left.equalTo(view);
            make.right.equalTo(view);
            make.bottom.equalTo(view);
        }];
        UIImageView *icon = [UIImageView new];
        UIImage *img = [UIImage imageNamed:@"homepage_logo_rupeeapp"];
        icon.image = img;
        [view addSubview:icon];
        [icon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(view).offset(SCALE_HEIGHT(15));
            make.left.equalTo(view).offset(SCALE(25));
            make.size.mas_equalTo(CGSizeMake(42, 42));
        }];
        _icon = icon;
        UILabel *lab = [UILabel new];
        lab.text = @"Groww Fund";
        lab.font = DEF_FontSize_17;
        lab.textColor = RGBColor(35, 36, 40);
        [lab sizeToFit];
        [view addSubview:lab];
        [lab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(icon);
            make.left.equalTo(icon).offset(img.size.width + SCALE(7));
        }];
        _lab = lab;
        UILabel *d = [UILabel new];
        d.textAlignment = NSTextAlignmentCenter;
        d.text = @"91days";
        d.font = DEF_FontSize_12;
        d.textColor = RGBColor(45, 86, 204);
        d.backgroundColor = RGBColor(240, 241, 245);
        d.layer.masksToBounds = YES;
        d.layer.cornerRadius = 10.5;
        [view addSubview:d];
        [d mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(icon);
            make.left.equalTo(lab).offset(lab.bounds.size.width + SCALE(7));
            make.size.mas_equalTo(CGSizeMake(58, 18));
        }];
        _d = d;
        UILabel *lab1 = [UILabel new];
        lab1.text = @"Loan amount";
        lab1.font = DEF_FontSize_14;
        lab1.textColor = RGBColor(169, 170, 184);
        [lab1 sizeToFit];
        [view addSubview:lab1];
        [lab1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(icon).offset(42 + SCALE_HEIGHT(14));
            make.left.equalTo(icon);
        }];
        
        _lab1 = lab1;
        UILabel *lab2 = [UILabel new];
        lab2.text = @"₹88.000";
        lab2.font = [UIFont systemFontOfSize:21 weight:UIFontWeightBold];
        lab2.textColor = RGBColor(45, 86, 204);
        [lab2 sizeToFit];
        [view addSubview:lab2];
        [lab2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(lab1).offset(lab1.bounds.size.height);
            make.left.equalTo(icon);
        }];
        _lab2 = lab2;
        
        UILabel *rlab1 = [UILabel new];
        rlab1.text = @"Interest rate";
        rlab1.font = DEF_FontSize_14;
        rlab1.textColor = RGBColor(169, 170, 184);
        [rlab1 sizeToFit];
        [view addSubview:rlab1];
        [rlab1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(lab1);
            make.left.equalTo(lab1).offset(lab1.bounds.size.width + SCALE(110));
        }];
        
        _rlab1 = rlab1;
        UILabel *rlab2 = [UILabel new];
        rlab2.text = @"0.05%";
        rlab2.font = [UIFont systemFontOfSize:21 weight:UIFontWeightBold];
        rlab2.textColor = RGBColor(45, 86, 204);
        [rlab2 sizeToFit];
        [view addSubview:rlab2];
        [rlab2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(rlab1).offset(rlab1.bounds.size.height);
            make.left.equalTo(rlab1);
        }];
        _rlab2 = rlab2;
        UIButton *send = [UIButton buttonWithType:UIButtonTypeCustom];
        [send setBackgroundImage:[UIImage imageNamed:@"btn_card_long_bg_blue"] forState:UIControlStateNormal];
        [send setTitle:@"Apply now" forState:UIControlStateNormal];
        send.titleLabel.font = DEF_FontSize_14;
        send.titleLabel.textColor = RGBColor(255, 255, 255);
        [view addSubview:send];
        [send mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(view);
            make.top.equalTo(lab2).offset(SCALE_HEIGHT(24)+lab2.bounds.size.height);
            make.size.mas_offset(CGSizeMake(SCALE(276), SCALE_HEIGHT(36)));
        }];
        
        _send = send;
    }
    return  self;
}
-(void)setSouce:(NSDictionary*)dict{
    [_icon sd_setImageWithURL:[NSURL URLWithString:dict[@"volunteer"]] placeholderImage:[UIImage imageNamed:@"homepage_logo_rupeeapp"]];
    self.lab.text = [NSString stringWithFormat:@"%@",dict[@"payment"]];
    self.d.text = [NSString stringWithFormat:@"%@",dict[@"bring"]];
    self.rlab1.text = [NSString stringWithFormat:@"%@",dict[@"tags"]];
    self.rlab2.text = [NSString stringWithFormat:@"%@",dict[@"them"]];
    self.lab1.text = [NSString stringWithFormat:@"%@",dict[@"main"]];
    self.lab2.text = [NSString stringWithFormat:@"%@",dict[@"part"]];

}
@end
