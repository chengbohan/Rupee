//
//  HomeBannerCell.h
//  Project
//
//  Created by 回春雷 on 2023/4/4.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeBannerCell : UITableViewCell

@end

NS_ASSUME_NONNULL_END
