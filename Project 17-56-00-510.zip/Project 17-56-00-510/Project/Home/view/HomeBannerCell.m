//
//  HomeBannerCell.m
//  Project
//
//  Created by 回春雷 on 2023/4/4.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "HomeBannerCell.h"
#import <SDCycleScrollView/SDCycleScrollView.h>

@implementation HomeBannerCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if ([super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        SDCycleScrollView *cycleScrollView = [[SDCycleScrollView alloc]init];
        cycleScrollView.autoScroll = false;
        cycleScrollView.showPageControl = false;
        [self.contentView addSubview:cycleScrollView];
        [cycleScrollView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.contentView);
            make.left.equalTo(self.contentView).offset(SCALE(16));
            make.right.equalTo(self.contentView).offset(SCALE(-16));
            make.height.mas_equalTo(SCALE_HEIGHT(120));
        }];
        NSArray *imgs = @[@"home_bnr_blue",
                          @"home_bnr_blue",
                          @"home_bnr_blue"];
        cycleScrollView.imageURLStringsGroup = imgs;
    }
    return  self;
}

@end
