//
//  WebViewControl.m
//  Project
//
//  Created by apple on 2023/4/20.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "WebViewControl.h"
#import <WebKit/WebKit.h>
#import <StoreKit/StoreKit.h>
#import "DetailsViewController.h"
#import "BaseTabBarViewController.h"
#import "OrderViewController.h"
@interface WebViewControl ()<WKUIDelegate, WKNavigationDelegate, WKScriptMessageHandler, UIScrollViewDelegate>
@property(nonatomic, strong)WKWebView *myWeb;
@end

@implementation WebViewControl

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    if(!self.URLString){
        //for test
        self.URLString = @"http://www.baidu.com";
    }
    
    
    self.view.backgroundColor = RGBColor(240, 241, 245);
    UIView *v = [UIView new];
    [self.view addSubview:v];
    v.backgroundColor = [UIColor whiteColor];
    [v mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view);
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.height.mas_equalTo(statusBarAndNavigationBarHeight);
    }];
    [self nav];
    [self setUI];
}

-(void)nav{
    self.navigationItem.title = @"Rupee";
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor blackColor]}];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[[UIImage imageNamed:@"nav_bar_icon_left_back_b"] imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)] style:UIBarButtonItemStylePlain target:self action:@selector(leftButtonClick)];
}

-(void)leftButtonClick{
    
    
    WSelf(self);
    
    if(self.myWeb.canGoBack){
        [self.myWeb goBack];
    } else {
        NSMutableArray *navAM = [NSMutableArray arrayWithArray:weakself.navigationController.viewControllers];
        if(navAM.count > 2){
            if([navAM[navAM.count - 2] isKindOfClass:[DetailsViewController class]]){
                [navAM removeObjectAtIndex:navAM.count - 2];
            }
            weakself.navigationController.viewControllers = navAM;
            NSLog(@"%@",navAM);
            [weakself.navigationController popViewControllerAnimated:NO];
            
        } else {
            [self.navigationController popViewControllerAnimated:YES];
        }
        
    }
    
    

}


- (void)setUI {
    //创建网页配置对象
    WKWebViewConfiguration *webConn = [WKWebViewConfiguration new];
    WKUserContentController *userC = [[WKUserContentController alloc] init];
    [userC addScriptMessageHandler:self name:@"rpuua"];//jump
    [userC addScriptMessageHandler:self name:@"rpuub"];//close
    [userC addScriptMessageHandler:self name:@"rpuud"];//home
    [userC addScriptMessageHandler:self name:@"rpuue"];//mine
    [userC addScriptMessageHandler:self name:@"rpuuf"];//login
    [userC addScriptMessageHandler:self name:@"rpuuk"];//tel
    [userC addScriptMessageHandler:self name:@"rpuus"];//appstore
    [userC addScriptMessageHandler:self name:@"rpuum"];//mai dian
   
    
    
    webConn.userContentController = userC;
    
    self.myWeb = [[WKWebView alloc] initWithFrame:CGRectMake(0, statusBarAndNavigationBarHeight, SCREEN_WIDTH, SCREEN_HEIGHT - statusBarAndNavigationBarHeight) configuration:webConn];
    
   // 导航代理
    if (@available(iOS 11.0, *)) {
        self.myWeb.scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    
    
    self.myWeb.scrollView.delegate = self;
    self.myWeb.navigationDelegate = self;
    self.myWeb.UIDelegate = self;
    self.myWeb.backgroundColor = [UIColor whiteColor];
    self.myWeb.allowsBackForwardNavigationGestures = YES;
    [self.view addSubview:self.myWeb];
    
  
    self.URLString = [NSString stringWithFormat:@"%@?upstairs=%@&took=%@&shaking=%@&around=%@&nose=%@&punch=%@",self.URLString,Version,deviceName,idfa,iosVersion,[UserModel sharedInstanced].nose,idfa];
    self.URLString = [self.URLString stringByReplacingOccurrencesOfString:@" " withString:@""];
   [self.myWeb loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.URLString]]];
}


- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation {
    
    self.navigationItem.title = BTString(webView.title);
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    

    if([message.name isEqualToString:@"rpuud"]){
        //home
        WSelf(self);
        AppDelegate *delegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
        BaseTabBarViewController *tabbar = delegate.tabBarController;
        tabbar.view.backgroundColor = [UIColor whiteColor];
        [tabbar setSelectedIndex:0];
        [self.navigationController popToRootViewControllerAnimated:NO];
        return;
    }

    if([message.name isEqualToString:@"rpuue"]){
        //mine
        AppDelegate *delegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
        BaseTabBarViewController *tabbar = delegate.tabBarController;
        tabbar.view.backgroundColor = [UIColor whiteColor];
        [tabbar setSelectedIndex:1];
        [self.navigationController popToRootViewControllerAnimated:NO];
        return;
    }
    if([message.name isEqualToString:@"rpuub"]){
        [self.navigationController popViewControllerAnimated:NO];
        return;
    }
    if([message.name isEqualToString:@"rpuua"]){
        NSLog(@"%@",message.body);
        NSString *msg = message.body;
        if([msg containsString:@"rapp://rp.rupee.app/would"]){

            NSArray *arr = [msg componentsSeparatedByString:@"particular="];
            if(arr.count != 2){
                return;
            }
            NSString *ducId = arr[1];
            ducId = [ducId substringToIndex:1];
            DetailsViewController *vc = [[DetailsViewController alloc]init];
            vc.particular = ducId;
            [self.navigationController pushViewController:vc animated:NO];

        }
        if([msg containsString:@"rapp://rp.rupee.app/haircut"]){
            OrderViewController *vc = [OrderViewController new];
            [self.navigationController pushViewController:vc animated:NO];
            return;

        }
        else if([msg containsString:@"http"]){

            WebViewControl *web = [WebViewControl new];
            web.URLString = msg;
            [self.navigationController pushViewController:web animated:NO];
        }
        
        
        
    }
    if([message.name isEqualToString:@"rpuuk"]){
        [self showBottomAlt:[NSString stringWithFormat:@"%@",message.body]];
    }
    
    if([message.name isEqualToString:@"rpuus"]){
        [SKStoreReviewController requestReview];
        return;
        
    }
    if([message.name isEqualToString:@"rpuuf"]){
        //login
        
        
//        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"phone"];
//        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"session"];
//        [[NSUserDefaults standardUserDefaults] synchronize];
//
//        AppDelegate *delegate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
//        UITabBarController *tabbar = delegate.myTabbar;
//        tabbar.view.backgroundColor = [UIColor whiteColor];
//        [tabbar setSelectedIndex:0];
//        CashKingJumpInfoViewControl *vc =[CashKingJumpInfoViewControl new];
//        [tabbar addChildViewController:vc];
//        [tabbar.view addSubview:vc.view];
//        [self.navigationController popToViewController:tabbar animated:NO];
//
        
        return;
    }
    
    if([message.name isEqualToString:@"rpuum"]){
        //mai dian
        return;
    }
    
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{
    return nil;
}

- (void)showBottomAlt:(NSString *)num {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",num]] options:@{} completionHandler:^(BOOL success) {

    }];
}


- (void)showAlert:(NSString *)num {
    NSString *str = [NSString stringWithFormat:@"Call %@?",num];
    UIAlertController *_ac = [UIAlertController alertControllerWithTitle:@"alert" message:str preferredStyle:UIAlertControllerStyleAlert];
    NSArray* arr = @[@"YES",@"NO"];
    NSInteger count = [arr count];
    for(int i=0; i<count; i++){
        UIAlertAction* action = [UIAlertAction actionWithTitle:arr[i] style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            NSLog(@"%@",arr[i]);
            if (i == 0) {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",num]] options:@{} completionHandler:^(BOOL success) {
        
                }];
            }
        }];
        [_ac addAction:action];
    }
    [self presentViewController:_ac animated:YES completion:nil];
}


@end
