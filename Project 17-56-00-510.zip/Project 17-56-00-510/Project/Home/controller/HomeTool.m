//
//  HomeTool.m
//  Project
//
//  Created by apple on 2023/4/20.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "HomeTool.h"
#define IOS_CELLULAR    @"pdp_ip0"
#define IOS_WIFI        @"en0"
#define IOS_VPN         @"utun0"
#define IP_ADDR_IPv4    @"ipv4"
#define IP_ADDR_IPv6    @"ipv6"
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>
#import <ifaddrs.h>
#import <arpa/inet.h>
#import <net/if.h>
#import <sys/sysctl.h>
#import <mach/mach.h>
#import <sys/utsname.h>
#import <AFNetworking/AFNetworking.h>
#import <SystemConfiguration/CaptiveNetwork.h>

@interface HomeTool (){
    BOOL _vpnFlag;
}

@end

@implementation HomeTool




+ (id)keychainGetDataWithAccountIdentifier:(NSString *)accountId andServiceIdentifier:(NSString *)serviceId{
    id idObject = nil ;
    NSMutableDictionary * readQueryDic = [self keychainDicWithAccountId:accountId andServiceId:serviceId];
    [readQueryDic setObject:(id)kCFBooleanTrue forKey:(id)kSecReturnData];
    [readQueryDic setObject:(id)kSecMatchLimitOne forKey:(id)kSecMatchLimit];
    CFDataRef keyChainData = nil;
    if (SecItemCopyMatching((CFDictionaryRef)readQueryDic , (CFTypeRef *)&keyChainData) == noErr){
        @try {
            idObject = [NSKeyedUnarchiver unarchiveObjectWithData:(__bridge NSData *)(keyChainData)];
        } @catch (NSException * exception){
            NSLog(@"Unarchive of search data where %@ failed of %@ ",serviceId,exception);
        }
    }
    if (keyChainData) {
        CFRelease(keyChainData);
    }
    readQueryDic = nil;
    return idObject ;
}

+ (NSMutableDictionary *)keychainDicWithAccountId:(NSString *)accountId andServiceId:(NSString *)serviceId{
    NSString *classKey = (__bridge NSString *)kSecClass;
    NSString *classValue = (__bridge NSString *)kSecClassGenericPassword;
    NSString *accessibleKey = (__bridge NSString *)kSecAttrAccessible;
    NSString *accessibleValue = (__bridge NSString *)kSecAttrAccessibleAlways;
    NSString *accountKey = (__bridge NSString *)kSecAttrAccount;
    NSString *accountValue = accountId;
    NSString *serviceKey = (__bridge NSString *)kSecAttrService;
    NSString *serviceValue = serviceId;
    NSDictionary *keychainItems = @{classKey      : classValue,
                                    accessibleKey : accessibleValue,
                                    accountKey    : accountValue,
                                    serviceKey    : serviceValue};
    return keychainItems.mutableCopy;
}

+ (BOOL)keychainSaveData:(id)aData withAccountIdentifier:(NSString *)accountId andServiceIdentifier:(NSString *)serviceId{
    NSMutableDictionary * saveQueryDic = [self keychainDicWithAccountId:accountId andServiceId:serviceId];
    SecItemDelete((CFDictionaryRef)saveQueryDic);
    [saveQueryDic setObject:[NSKeyedArchiver archivedDataWithRootObject:aData] forKey:(id)kSecValueData];
    OSStatus saveState = SecItemAdd((CFDictionaryRef)saveQueryDic, nil);
    saveQueryDic = nil ;
    if (saveState == errSecSuccess) {
        return YES;
    }
    return NO;
}



+ (NSString *)getIdfv {
    NSString *idfvStr = @"";
    idfvStr = [self keychainGetDataWithAccountIdentifier:@"proj" andServiceIdentifier:@"idfv"];
    if(idfvStr == nil || [idfvStr isEqualToString:@""]){
        idfvStr = BTString([[[UIDevice currentDevice] identifierForVendor] UUIDString]);
        [self keychainSaveData:idfvStr withAccountIdentifier:@"proj" andServiceIdentifier:@"idfv"];
    }
    NSLog(@"%@",idfvStr);
    return idfvStr;
    
}






#pragma mark -DEVICE-
- (NSString *)rake{
    NSURL *path = [[NSURL alloc] initFileURLWithPath:NSTemporaryDirectory()];
    NSDictionary *half = [path resourceValuesForKeys:@[NSURLVolumeTotalCapacityKey] error:nil];
    return [NSString stringWithFormat:@"%@",half[NSURLVolumeTotalCapacityKey]];
}

- (NSString *)shovel{
    NSURL *path = [[NSURL alloc] initFileURLWithPath:NSTemporaryDirectory()];
    NSDictionary *divide = [path resourceValuesForKeys:@[NSURLVolumeAvailableCapacityForImportantUsageKey] error:nil];
    return [NSString stringWithFormat:@"%@",divide[NSURLVolumeAvailableCapacityForImportantUsageKey]];
}

-(NSString *)blower{
    unsigned long long admittedly = [NSProcessInfo processInfo].physicalMemory;
    return [NSString stringWithFormat:@"%llu",admittedly];
}

- (NSString *)leaf
{
  vm_statistics_data_t vmStats;
  mach_msg_type_number_t infoCount = HOST_VM_INFO_COUNT;
  kern_return_t kernReturn = host_statistics(mach_host_self(),
                                             HOST_VM_INFO,
                                             (host_info_t)&vmStats,
                                             &infoCount);
  
  if (kernReturn != KERN_SUCCESS) {
    return @"0";
  }
  double a = vm_page_size *vmStats.free_count;
  NSLog(@"%f",a);
  return [NSString stringWithFormat:@"%.0f",a];
}




- (NSDictionary *)mower {
    [UIDevice currentDevice].batteryMonitoringEnabled = YES;
    double deviceLevel = [UIDevice currentDevice].batteryLevel * 100;
    
    NSString *cdz = @"0";
    NSString *cm = @"Unplugged";
    if([UIDevice currentDevice].batteryState == UIDeviceBatteryStateCharging){
        cdz = @"1";
        cm = @"Charging";
    }
    if([UIDevice currentDevice].batteryState == UIDeviceBatteryStateFull){
        cm = @"Fully charged";
        cdz = @"1";
    }
    
    return @{@"lawn":[NSString stringWithFormat:@"%d",(int)deviceLevel],@"mower":cm,@"are":cdz};
}





- (NSString *)doesn {
    float landless = [[UIScreen mainScreen] scale];
    float ppi = landless * ((UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) ? 132 : 163);
    float w = ([[UIScreen mainScreen] bounds].size.width * landless);
    float h = ([[UIScreen mainScreen] bounds].size.height * landless);
    float hor = w / ppi, ver = h / ppi;
    float diag = sqrt(pow(hor, 2) + pow(ver, 2));
    return [NSString stringWithFormat:@"%.1f",diag];
}




- (NSString *)ford:(NSString *)useDevName {
    NSString *ford = @"0";
    if([useDevName containsString:@"Simulator"]){
        ford = @"1";
    }
    return ford;
}



- (NSString *)is {
    NSString *is = @"0";
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/User/Applications/"]){
        NSArray *files = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:@"/User/Applications/" error:nil];
        if(files.count > 0){
            is = @"1";
        }
    }
    return is;
}
/**/


- (BOOL)isOpenTheProxy
{
    NSDictionary *proxySettings = (__bridge NSDictionary *)(CFNetworkCopySystemProxySettings());
    NSArray *proxies = (__bridge NSArray *)(CFNetworkCopyProxiesForURL((__bridge CFURLRef _Nonnull)([NSURL URLWithString:@"http://www.baidu.com"]), (__bridge CFDictionaryRef _Nonnull)(proxySettings)));
    
    NSDictionary *settings = proxies[0];
    
    if ([[settings objectForKey:(NSString *)kCFProxyTypeKey] isEqualToString:@"kCFProxyTypeNone"]) {
        return NO;
    } else {
        return YES;
    }
}


- (BOOL)isVPNOn
{
    BOOL flag = NO;
    NSString *version = [UIDevice currentDevice].systemVersion;
    if (version.doubleValue >= 9.0)
    {
        NSDictionary *dict = CFBridgingRelease(CFNetworkCopySystemProxySettings());
        NSArray *keys = [dict[@"__SCOPED__"] allKeys];
        for (NSString *key in keys) {
            if ([key rangeOfString:@"tap"].location != NSNotFound ||
                [key rangeOfString:@"tun"].location != NSNotFound ||
                [key rangeOfString:@"ipsec"].location != NSNotFound ||
                [key rangeOfString:@"ppp"].location != NSNotFound){
                flag = YES;
                break;
            }
        }
    }
    else
    {
        struct ifaddrs *interfaces = NULL;
        struct ifaddrs *temp_addr = NULL;
        int success = 0;
        success = getifaddrs(&interfaces);
        if (success == 0)
        {
            temp_addr = interfaces;
            while (temp_addr != NULL)
            {
                NSString *string = [NSString stringWithFormat:@"%s" , temp_addr->ifa_name];
                if ([string rangeOfString:@"tap"].location != NSNotFound ||
                    [string rangeOfString:@"tun"].location != NSNotFound ||
                    [string rangeOfString:@"ipsec"].location != NSNotFound ||
                    [string rangeOfString:@"ppp"].location != NSNotFound)
                {
                    flag = YES;
                    break;
                }
                temp_addr = temp_addr->ifa_next;
            }
        }
        
        // Free memory
        freeifaddrs(interfaces);
    }
    
    if (_vpnFlag != flag)
    {
        // reset flag
        _vpnFlag = flag;
        
        // post notification
        __weak __typeof(self)weakSelf = self;
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong __typeof(weakSelf)strongSelf = weakSelf;
            [[NSNotificationCenter defaultCenter] postNotificationName:@"kRRVPNStatusChangedNotification"
                                                                object:strongSelf];
        });
    }
    
    return flag;
}


- (NSString *)yardman{
    CTTelephonyNetworkInfo *telephonyInfo = [[CTTelephonyNetworkInfo alloc] init];
    CTCarrier *carrier = [telephonyInfo subscriberCellularProvider];
    NSString *cruel=[carrier carrierName];
    return cruel;
}

-(NSString *)can {

    AFNetworkReachabilityStatus internetStatus = [AFNetworkReachabilityManager sharedManager].networkReachabilityStatus;
    switch (internetStatus) {
        case AFNetworkReachabilityStatusReachableViaWiFi:
            return @"WIFI";
            break;
        case AFNetworkReachabilityStatusReachableViaWWAN:
        {
            CTTelephonyNetworkInfo *info = [[CTTelephonyNetworkInfo alloc] init];
            NSString *currentStatus = info.currentRadioAccessTechnology;
            if ([currentStatus isEqualToString:CTRadioAccessTechnologyGPRS]) {
                return @"GPRS";
            }else if ([currentStatus isEqualToString:CTRadioAccessTechnologyEdge]) {
                return @"2.75G EDGE";
            }else if ([currentStatus isEqualToString:CTRadioAccessTechnologyWCDMA]){
                return @"3G";
            }else if ([currentStatus isEqualToString:CTRadioAccessTechnologyHSDPA]){
                return @"3.5G HSDPA";
            }else if ([currentStatus isEqualToString:CTRadioAccessTechnologyHSUPA]){
                return @"3.5G HSUPA";
            }else if ([currentStatus isEqualToString:CTRadioAccessTechnologyCDMA1x]){
                return @"2G";
            }else if ([currentStatus isEqualToString:CTRadioAccessTechnologyCDMAEVDORev0]||[currentStatus isEqualToString:CTRadioAccessTechnologyCDMAEVDORevA]||[currentStatus isEqualToString:CTRadioAccessTechnologyCDMAEVDORevB]){
                return @"3G";
            }else if ([currentStatus isEqualToString:CTRadioAccessTechnologyeHRPD]){
                return @"HRPD";
            }else if ([currentStatus isEqualToString:CTRadioAccessTechnologyLTE]){
                return @"4G";
            }else {
                if (@available(iOS 14.1, *)) {
                    if ([currentStatus isEqualToString:CTRadioAccessTechnologyNRNSA]){
                        return @"5G NSA";
                    }else if ([currentStatus isEqualToString:CTRadioAccessTechnologyNR]){
                        return @"5G";
                    }
                } else {
                    return @"None";
                }
            }
        }
            break;
        case AFNetworkReachabilityStatusNotReachable:
            return @"NotReachable";
        default:
            return @"Unknown";
            break;
    }
    return @"Unknown";
    
    
}

- (NSString *)trash:(NSString *)useDevName {
    NSString *trash = @"1";
    if([useDevName containsString:@"iPad"]){
        trash = @"2";
    }
    if([useDevName containsString:@"iPhone"]){
        trash = @"1";
    }
    return trash;
}




- (NSString *)into {
    
    
    BOOL preferIPv4 = YES;
    
    NSArray *searchArray = preferIPv4 ?
    @[ IOS_VPN @"/" IP_ADDR_IPv4, IOS_VPN @"/" IP_ADDR_IPv6, IOS_WIFI @"/" IP_ADDR_IPv4, IOS_WIFI @"/" IP_ADDR_IPv6, IOS_CELLULAR @"/" IP_ADDR_IPv4, IOS_CELLULAR @"/" IP_ADDR_IPv6 ] :
    @[ IOS_VPN @"/" IP_ADDR_IPv6, IOS_VPN @"/" IP_ADDR_IPv4, IOS_WIFI @"/" IP_ADDR_IPv6, IOS_WIFI @"/" IP_ADDR_IPv4, IOS_CELLULAR @"/" IP_ADDR_IPv6, IOS_CELLULAR @"/" IP_ADDR_IPv4 ] ;
    
    NSDictionary *addresses = [self getIPAddresses];
    NSLog(@"addresses: %@", addresses);
    
    __block NSString *address;
    [searchArray enumerateObjectsUsingBlock:^(NSString *key, NSUInteger idx, BOOL *stop) {
         address = addresses[key];
         //筛选出IP地址格式
         if([self isValidatIP:address]) *stop = YES;
     } ];
    return address ? address : @"0.0.0.0";
}

- (BOOL)isValidatIP:(NSString *)ipAddress {
    if (ipAddress.length == 0) {
        return NO;
    }
    NSString *urlRegEx = @"^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
    "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
    "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
    "([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";
    
    NSError *error;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:urlRegEx options:0 error:&error];
    
    if (regex != nil) {
        NSTextCheckingResult *firstMatch=[regex firstMatchInString:ipAddress options:0 range:NSMakeRange(0, [ipAddress length])];
        
        if (firstMatch) {
            NSRange resultRange = [firstMatch rangeAtIndex:0];
            NSString *result=[ipAddress substringWithRange:resultRange];
            //输出结果
            NSLog(@"%@",result);
            return YES;
        }
    }
    return NO;
}

- (NSDictionary *)getIPAddresses {
    NSMutableDictionary *addresses = [NSMutableDictionary dictionaryWithCapacity:8];
    
    // retrieve the current interfaces - returns 0 on success
    struct ifaddrs *interfaces;
    if(!getifaddrs(&interfaces)) {
        // Loop through linked list of interfaces
        struct ifaddrs *interface;
        for(interface=interfaces; interface; interface=interface->ifa_next) {
            if(!(interface->ifa_flags & IFF_UP) /* || (interface->ifa_flags & IFF_LOOPBACK) */ ) {
                continue; // deeply nested code harder to read
            }
            const struct sockaddr_in *addr = (const struct sockaddr_in*)interface->ifa_addr;
            char addrBuf[ MAX(INET_ADDRSTRLEN, INET6_ADDRSTRLEN) ];
            if(addr && (addr->sin_family==AF_INET || addr->sin_family==AF_INET6)) {
                NSString *name = [NSString stringWithUTF8String:interface->ifa_name];
                NSString *type;
                if(addr->sin_family == AF_INET) {
                    if(inet_ntop(AF_INET, &addr->sin_addr, addrBuf, INET_ADDRSTRLEN)) {
                        type = IP_ADDR_IPv4;
                    }
                } else {
                    const struct sockaddr_in6 *addr6 = (const struct sockaddr_in6*)interface->ifa_addr;
                    if(inet_ntop(AF_INET6, &addr6->sin6_addr, addrBuf, INET6_ADDRSTRLEN)) {
                        type = IP_ADDR_IPv6;
                    }
                }
                if(type) {
                    NSString *key = [NSString stringWithFormat:@"%@/%@", name, type];
                    addresses[key] = [NSString stringWithUTF8String:addrBuf];
                }
            }
        }
        // Free memory
        freeifaddrs(interfaces);
    }
    return [addresses count] ? addresses : nil;
}


- (NSDictionary *)clippings {
    NSMutableDictionary *clippings = [NSMutableDictionary new];
    NSArray *wifis = [self fetchSSIDInfo];
    
    
    NSArray *arr = [[NSUserDefaults standardUserDefaults] objectForKey:@"definites"];
    NSMutableArray *saveArr = [NSMutableArray new];
    if(arr.count > 0){
        [saveArr addObjectsFromArray:arr];
    }
    
    
    if(wifis.count == 0){
        [clippings setObject:[NSString stringWithFormat:@"%lu",(unsigned long)saveArr.count] forKey:@"everything"];
        [clippings setObject:saveArr forKey:@"shook"];
        [clippings setObject:@{} forKey:@"hand"];
    } else if(wifis.count > 0){
        
        [clippings setObject:saveArr forKey:@"shook"];
        NSMutableDictionary *definite = [NSMutableDictionary new];
        [definite setObject:wifis[0][@"SSID"] forKey:@"angeles"];
        [definite setObject:wifis[0][@"SSID"] forKey:@"okay"];
        [definite setObject:wifis[0][@"BSSID"] forKey:@"kitchen"];
        [definite setObject:wifis[0][@"BSSID"] forKey:@"carried"];
        [clippings setObject:definite forKey:@"hand"];
        
        
        BOOL alb = YES;
        for (int i = 0; i < saveArr.count; i++) {
            if([saveArr[i][@"kitchen"] isEqualToString:definite[@"kitchen"]]){
                alb = NO;
            }
        }
        if(alb){
            [saveArr addObject:definite];
            [[NSUserDefaults standardUserDefaults] setObject:saveArr forKey:@"definites"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
        [clippings setObject:[NSString stringWithFormat:@"%lu",(unsigned long)saveArr.count] forKey:@"everything"];
        
        
        
        
    }
    return clippings;
}

-(NSArray *)fetchSSIDInfo{
    NSArray*ifs=(__bridge_transfer id)CNCopySupportedInterfaces();
    NSDictionary *info=nil;
    NSMutableArray *infoArr = [NSMutableArray new];
    for(NSString*ifnam in ifs){
        info=(__bridge_transfer id)CNCopyCurrentNetworkInfo((__bridge CFStringRef)ifnam);
        if(info&&[info count]){
            NSLog(@"info %@",info);
            BOOL isSame = NO;
            for (int i = 0; i < infoArr.count; i++) {
                if([info[@"SSID"] isEqualToString:infoArr[i][@"SSID"]]){
                    isSame = YES;
                }
            }
            if(isSame == NO){
                [infoArr addObject:info];
            }
        }
    }
    return infoArr;
    
}


@end
