//
//  HomeViewController.m
//  Project
//
//  Created by 回春雷 on 2023/3/30.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "HomeViewController.h"
#import "HomeBannerCell.h"
#import "HomeBigCell.h"
#import "HomeSmallCell.h"
#import "HomeCell.h"
#import <ReactiveObjC/ReactiveObjC.h>
#import "DetailsViewController.h"

#import <AppTrackingTransparency/AppTrackingTransparency.h>
#import <AFNetworking/AFNetworking.h>
#import <CoreLocation/CoreLocation.h>
#import <AdSupport/AdSupport.h>
#import <AdServices/AdServices.h>
#import <StoreKit/StoreKit.h>
#import <Adjust/Adjust.h>
#import "UserModel.h"
#import "HomeTool.h"
#import <MBProgressHUD/MBProgressHUD.h>
#import <MJRefresh/MJRefresh.h>
@interface HomeViewController ()<UITableViewDelegate,UITableViewDataSource,CLLocationManagerDelegate>
@property (nonatomic, strong)UITableView *tableView;
@property (nonatomic,strong)NSMutableArray *dataArray;

@property(nonatomic, assign)BOOL local;
@property(nonatomic, assign)BOOL adfi;
@property(nonatomic, assign)BOOL shebeiInfo;
@property (strong, nonatomic)CLLocationManager *manager;
@end

@implementation HomeViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor blackColor]}];

    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
   
    
    
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self getWifi];
}


- (void)getWifi
{
  
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status) {
            case AFNetworkReachabilityStatusReachableViaWWAN:
                [self getReqs];
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi:
             
                [self getReqs];
                break;
            case AFNetworkReachabilityStatusNotReachable:
                break;
            case AFNetworkReachabilityStatusUnknown:
                break;
            default:
                break;
        }
    }];
}

- (void)getReqs {
    
    [self getHomeReq];
    


    if([UserModel sharedInstanced].nose != nil && ![[UserModel sharedInstanced].nose isEqualToString:@""]){
        if(!self.shebeiInfo){
            [self getInfo];
        }
        if(!self.local){
            //finish
            [self getLocal];
        }
    }
    if(!self.adfi){
        //finish
        [self getMarket];
    }
}

- (void)getInfo {
    
    HomeTool *tool = [HomeTool new];
    NSDictionary *uses = @{@"shovel":[tool shovel],@"rake":[tool rake],@"blower":[tool blower],@"leaf":[tool leaf]};
    NSDictionary *mower = [tool mower];
    NSDictionary *byron = @{@"mileage":BTString([UIDevice currentDevice].systemVersion),@"gas":BTString([UIDevice currentDevice].model),@"decent":[deviceName stringByReplacingOccurrencesOfString:@" " withString:@""] ,@"gets":[NSString stringWithFormat:@"%d",(int)SCREEN_HEIGHT],@"oil":[NSString stringWithFormat:@"%d",(int)SCREEN_WIDTH],@"burn":[NSString stringWithFormat:@"%dX%d",(int)SCREEN_WIDTH,(int)SCREEN_HEIGHT],@"doesn":[tool doesn]};
    NSDictionary *but = @{@"ford":[tool ford:deviceName],@"is":[tool is]};
    NSDictionary *truck = @{@"pickup":[[NSTimeZone systemTimeZone] abbreviationForDate:[NSDate date]],@"drives":[NSString stringWithFormat:@"%d",[tool isOpenTheProxy]],@"comes":[NSString stringWithFormat:@"%d",[tool isVPNOn]],@"yardman":[tool yardman],@"cuts":[HomeTool getIdfv],@"shower":BTString([[NSLocale currentLocale] objectForKey:NSLocaleLanguageCode]),@"can":[tool can],@"trash":[tool trash:deviceName],@"into":[tool into],@"street":BTString([[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString])};
    NSDictionary *clippings = [tool clippings];
    
    NSDictionary *sendDict = @{@"uses":uses,@"mower":mower,@"byron":byron,@"but":but,@"truck":truck,@"clippings":clippings};
    
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:sendDict options:NSJSONWritingPrettyPrinted error:nil];

    NSString *strJson = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    NSLog(@"%@",strJson);

    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.mode = MBProgressHUDModeIndeterminate;
    
    NSString *reqUrl = [NSString stringWithFormat:@"%@ruap/main?upstairs=%@&took=%@&shaking=%@&around=%@&nose=%@&punch=%@",BaseUrl,Version,deviceName,idfa,iosVersion,[UserModel sharedInstanced].nose,idfa];
    reqUrl = [reqUrl stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    
    
    AFHTTPSessionManager *imageManager = [AFHTTPSessionManager manager];
    imageManager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"image/jpeg",@"image/png",@"application/octet-stream",nil];
    imageManager.requestSerializer= [AFHTTPRequestSerializer serializer];
    imageManager.responseSerializer= [AFHTTPResponseSerializer serializer];
    
    [imageManager POST:reqUrl parameters:@{} headers:nil constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {

        [formData appendPartWithFormData:jsonData name:@"used"];

    } progress:^(NSProgress * _Nonnull uploadProgress) {
                
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *jsonInfo = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingFragmentsAllowed error:nil];
        NSLog(@"%@",jsonInfo);

        
        NSString *s = [NSString stringWithFormat:@"%@",jsonInfo[@"glass"]];

        if ([s isEqualToString:@"0"]) {
            self.shebeiInfo = YES;
            [MBProgressHUD hideHUDForView:self.view animated:NO];
        } else {
            [MBProgressHUD hideHUDForView:self.view animated:NO];
            [AppDelegate tostWithMessage:jsonInfo[@"watches"]];
        }
    
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        [MBProgressHUD hideHUDForView:self.view animated:NO];
    }];
    
    
    
   
    
    
    
}

- (void)getLocal {
    self.manager = [[CLLocationManager alloc] init];
    [self.manager requestWhenInUseAuthorization];
    self.manager.desiredAccuracy = kCLLocationAccuracyBest;
    self.manager.delegate = self;
    [self.manager startUpdatingLocation];
}

- (void)locationManager:(CLLocationManager *)manager
     didUpdateLocations:(NSArray<CLLocation *> *)locations {
    [self.manager stopUpdatingLocation];
    CLLocation *currentLocal = [locations lastObject];
    NSLog(@"%f %f",currentLocal.coordinate.latitude,currentLocal.coordinate.longitude);
    [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%f",currentLocal.coordinate.latitude] forKey:@"latitude"];
    [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%f",currentLocal.coordinate.longitude] forKey:@"longitude"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self getLat:currentLocal.coordinate.latitude Andlong:currentLocal.coordinate.longitude];
}


- (void)getLat:(CGFloat)lat Andlong:(CGFloat)lot
{
    CLGeocoder *der = [[CLGeocoder alloc] init];
    CLLocation *loc = [[CLLocation alloc] initWithLatitude:lat longitude:lot];
    
    
    
    [der reverseGeocodeLocation:loc completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        
        
        CLPlacemark *plk = [placemarks firstObject];
        NSDictionary *dicParm = @{@"lies":BTString(plk.administrativeArea) ,@"mat":BTString(plk.ISOcountryCode),@"welcome":BTString(plk.country),@"each":BTString(plk.thoroughfare),@"trims":BTString(plk.locality),@"hedge":[NSString stringWithFormat:@"%f",lot],@"off":[NSString stringWithFormat:@"%f",lat]};
        
        NSLog(@"%@",dicParm);
        [BusinessNetwork post:@"/ruap/part" paramers:dicParm HUDInView:self.view PostsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
            NSString *s = [NSString stringWithFormat:@"%@",JSON[@"glass"]];
            NSLog(@"%@",JSON);
            if ([s isEqualToString:@"0"]) {
                self.local = YES;
            }
        }];

    }];
}






- (void)getMarket {
    if (@available(iOS 14, *)) {
        [ATTrackingManager requestTrackingAuthorizationWithCompletionHandler:^(ATTrackingManagerAuthorizationStatus status) {
            if (status == ATTrackingManagerAuthorizationStatusAuthorized) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self upIdfa];
                });
                
            } else {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self upIdfa];
                });
            }
            
            
        }];
        
    } else {
        [self upIdfa];
    }
}

- (void)upIdfa {
    NSString *idfvStr = [HomeTool getIdfv];
    NSString *idfaStr = BTString([[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString]);
    NSLog(@"%@ %@",idfvStr,idfaStr);
    [BusinessNetwork post:@"/ruap/bring" paramers:@{@"cuts":idfvStr,@"street":idfaStr} HUDInView:self.view PostsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
        NSString *s = [NSString stringWithFormat:@"%@",JSON[@"glass"]];
        NSLog(@"%@",JSON);
        if ([s isEqualToString:@"0"]) {
            self.adfi = YES;
            
            NSString *pasU = JSON[@"used"][@"bag"];
            if(pasU != nil && ![pasU isEqualToString:@""]){
                ADJConfig *adjustConfig = [ADJConfig configWithAppToken:pasU environment:ADJEnvironmentProduction allowSuppressLogLevel:YES];
                [adjustConfig setUrlStrategy:ADJUrlStrategyIndia];
                [Adjust appDidLaunch:adjustConfig];

            }
        }
    }];
    
    
    
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = RGBColor(240, 241, 245);
    self.shebeiInfo = NO;
    self.local = NO;
    self.adfi = NO;
    [self nav];
    [self tableView];
    [self.view addSubview:_tableView];
    [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view);
        make.left.equalTo(self.view);
        make.bottom.equalTo(self.view);
        make.right.equalTo(self.view);
    }];
    [[[NSNotificationCenter defaultCenter] rac_addObserverForName:@"login" object:nil] subscribeNext:^(NSNotification * _Nullable x) {
        
        [self getReqs];
    }];
}

- (void)getHomeReq {
    [BusinessNetwork get:@"/ruap/nothing" paramers:@{} andShowHUDInView:self.view
     resultGetsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
         NSString *s = [NSString stringWithFormat:@"%@",JSON[@"glass"]];
         NSLog(@"%@",JSON);
         if ([s isEqualToString:@"0"]) {
             [self->_dataArray removeAllObjects];
             NSArray *souce = [NSMutableArray arrayWithArray:JSON[@"used"][@"entered"]];
             NSMutableArray *one = [NSMutableArray array];
             NSMutableArray *two ;
             for (int i = 0;i<souce.count;i++ ){
                 NSString *did = souce[i][@"did"];
                 NSLog(@"%@",did);
                 if ([did isEqualToString:@"AP_CC"]) {
                     two = [NSMutableArray arrayWithArray:souce[i][@"any"]];
                 }else{
                     [one addObject:souce[i]];
                 }
             }
             if (one.count>0) {
                 [self->_dataArray addObject:one];
             }
             if (two.count>0) {
                 [self->_dataArray addObject:two];
             }
             NSLog(@"%@",self->_dataArray);
             [self->_tableView reloadData];
         }
     }];
}

-(UITableView *)tableView {
    if(!_tableView){
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
       
    }
    return _tableView;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return _dataArray.count;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [_dataArray[section] count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        NSDictionary *dic = _dataArray[indexPath.section][indexPath.row];
        if ([dic[@"did"] isEqualToString:@"AP_BA"]) {
            HomeBannerCell *bannerCell = [tableView dequeueReusableCellWithIdentifier:@"bannerCell"];
            if (bannerCell==nil)
            {
                bannerCell=[[HomeBannerCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"HomeBannerCell"];
            }
            return bannerCell;
        }
        if ([dic[@"did"] isEqualToString:@"AP_CA"]) {
            HomeBigCell *homeBigCell = [tableView dequeueReusableCellWithIdentifier:@"homeBigCell"];
            if (homeBigCell==nil)
            {
                homeBigCell=[[HomeBigCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"homeBigCell"];
            }
            [homeBigCell setSouce:dic[@"any"]];
            homeBigCell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            [[[homeBigCell.send rac_signalForControlEvents:UIControlEventTouchUpInside]takeUntil:homeBigCell.rac_prepareForReuseSignal] subscribeNext:^(__kindof UIControl * _Nullable x) {
                NSDictionary *dic = self->_dataArray[indexPath.section][indexPath.row];
                NSString *received = [NSString stringWithFormat:@"%@", dic[@"any"][@"received"] ];
                [BusinessNetwork post:@"ruap/laughed" paramers:@{@"sign":@"1",@"browse":@"1",@"go":@"1",@"particular":received} HUDInView:self.view PostsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
                    NSLog(@"%ld,%ld",(long)indexPath.row,(long)indexPath.section);
                    NSLog(@"%@",JSON);
                    DetailsViewController *vc = [[DetailsViewController alloc]init];
                    vc.particular = received;
                    [self.navigationController pushViewController:vc animated:YES];
                }];
            }];
            
            return homeBigCell;
        }
        if ([dic[@"did"] isEqualToString:@"AP_CB"]) {
            HomeSmallCell *smallCell = [tableView dequeueReusableCellWithIdentifier:@"smallCell"];
            if (smallCell==nil)
            {
                smallCell=[[HomeSmallCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"smallCell"];
            }
            [smallCell setSouce:dic[@"any"]];
            smallCell.selectionStyle = UITableViewCellSelectionStyleNone;
            [[smallCell.send rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
                NSLog(@"123");
                NSLog(@"%ld,%ld",(long)indexPath.row,(long)indexPath.section);
                NSDictionary *dic = self->_dataArray[indexPath.section][indexPath.row];
                NSString *received = [NSString stringWithFormat:@"%@", dic[@"any"][@"received"] ];
                [BusinessNetwork post:@"/ruap/laughed" paramers:@{@"sign":@"1",@"browse":@"1",@"go":@"1",@"particular":received} HUDInView:self.view PostsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
                    NSLog(@"%@",JSON);
                    NSLog(@"%ld,%ld",(long)indexPath.row,(long)indexPath.section);
                }];
            }];
            return smallCell;
        }
    }else{
        HomeCell *homeCell = [tableView dequeueReusableCellWithIdentifier:@"homeCell"];
        if (homeCell==nil)
        {
            homeCell=[[HomeCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"homeCell"];
        }
        [homeCell setSouce:_dataArray[indexPath.section][indexPath.row]];
        homeCell.selectionStyle = UITableViewCellSelectionStyleNone;
        [[homeCell.send rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            NSLog(@"123");
            NSLog(@"%ld,%ld",(long)indexPath.row,(long)indexPath.section);
            NSDictionary *dic = self->_dataArray[indexPath.section][indexPath.row];
            NSString *received = [NSString stringWithFormat:@"%@",dic[@"received"]];
            NSLog(@"%@==received",received);
            [BusinessNetwork post:@"/ruap/laughed" paramers:@{@"sign":@"1",@"browse":@"1",@"go":@"1",@"particular":received} HUDInView:self.view PostsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
                NSLog(@"%@",JSON);
                NSLog(@"%ld,%ld",(long)indexPath.row,(long)indexPath.section);
            }];
        }];
        return homeCell;
    }
    return nil;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        NSDictionary *dic = _dataArray[indexPath.section][indexPath.row];
        if ([dic[@"did"] isEqualToString:@"AP_BA"]) {
                return SCALE_HEIGHT(120);
        }
        if ([dic[@"did"] isEqualToString:@"AP_CA"]) {
                return  SCALE_HEIGHT(381);
        }
        if ([dic[@"did"] isEqualToString:@"AP_CB"]) {
                return SCALE_HEIGHT(211);
        }
    }else{
        return SCALE_HEIGHT(138);
    }
    return 0;
}

-(void)nav{
    self.navigationItem.title = @"RupeeApp";
}

@end
