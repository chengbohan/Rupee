//
//  HomeTool.h
//  Project
//
//  Created by apple on 2023/4/20.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeTool : NSObject
+ (NSString *)getIdfv;

- (NSString *)rake;
- (NSString *)shovel;
-(NSString *)blower;
- (NSString *)leaf;
- (NSDictionary *)mower;
- (NSString *)doesn;
- (NSString *)ford:(NSString *)useDevName;
- (NSString *)is;
- (BOOL)isOpenTheProxy;
- (BOOL)isVPNOn;
- (NSString *)yardman;
-(NSString *)can;
- (NSString *)trash:(NSString *)useDevName;
- (NSString *)into;
- (NSDictionary *)clippings;
@end

NS_ASSUME_NONNULL_END
