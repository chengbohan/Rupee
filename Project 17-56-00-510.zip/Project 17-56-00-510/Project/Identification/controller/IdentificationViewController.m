//
//  IdentificationViewController.m
//  Project
//
//  Created by 回春雷 on 2023/4/6.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "IdentificationViewController.h"
#import "IdentificationCell.h"
#import "TZImagePickerController.h"
#import "TZImageManager.h"
#import <AFNetworking/AFNetworking.h>
#import <MBProgressHUD/MBProgressHUD.h>
#import "WMZDialog.h"
#import <ReactiveObjC/ReactiveObjC.h>
#import  "BRStringPickerView.h"
#import "BRDatePickerView.h"

@interface IdentificationViewController ()<UITableViewDelegate,UITableViewDataSource,TZImagePickerControllerDelegate, UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    WMZDialog *myAlert;
}
@property (nonatomic, strong)UITableView *tableView;
@property (nonatomic,strong)NSMutableArray *dataArray;
@property (nonatomic, strong)TZImagePickerController *pickerController;
@property (nonatomic, strong)UIImagePickerController * imagePickerController;
@property (nonatomic,strong)NSString *type;
@property (nonatomic,strong)UIImageView *t;
@property (nonatomic,strong)UIButton *send;
@end
@implementation IdentificationViewController
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
}
-(void)network{
    [BusinessNetwork get:@"ruap/regular" paramers:@{@"particular":@"2"} andShowHUDInView:self.view resultGetsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
        NSLog(@"%@",JSON);
        NSString *s = [NSString stringWithFormat:@"%@",JSON[@"glass"]];
        if ([s isEqualToString:@"0"]) {
            if (!self->_dataArray) {
                self->_dataArray = [NSMutableArray arrayWithCapacity:4];
            }
            [self->_dataArray removeAllObjects];
            [JSON[@"used"] enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
                if ([key isEqualToString:@"pure"]) {
                    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
                    [dic setObject:key forKey:@"type"];
                    if([obj[@"usual"] isEqual: @0]){
                        [dic setObject:@"" forKey:@"img"];
                    }
                    if([obj[@"usual"] isEqual: @1]){
                        [dic setValue:obj[@"see"] forKey:@"img"];
                        [dic setValue:obj[@"info"] forKey:@"info"];
                    }
                    [self->_dataArray addObject:dic ];
                }
            }];
            [JSON[@"used"] enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
                if ([key isEqualToString:@"small"]) {
                    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
                    [dic setObject:key forKey:@"type"];
                    if([obj[@"usual"] isEqual: @0]){
                        [dic setObject:@"" forKey:@"img"];
                    }
                    if([obj[@"usual"] isEqual: @1]){
                        [dic setValue:obj[@"see"] forKey:@"img"];
                        [dic setValue:obj[@"info"] forKey:@"info"];
                    }
                    [self->_dataArray addObject:dic ];
                }
            }];
            [JSON[@"used"] enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
                if ([key isEqualToString:@"jeans"]) {
                    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
                    [dic setObject:key forKey:@"type"];
                    if([obj[@"usual"] isEqual: @0]){
                        [dic setObject:@"" forKey:@"img"];
                    }
                    if([obj[@"usual"] isEqual: @1]){
                        [dic setValue:obj[@"see"] forKey:@"img"];
                        [dic setValue:obj[@"info"] forKey:@"info"];
                    }
                    [self->_dataArray addObject:dic ];
                }
            }];
            [JSON[@"used"] enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
                if ([key isEqualToString:@"coat"]) {
                    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
                    [dic setObject:key forKey:@"type"];
                    if([obj[@"usual"] isEqual: @0]){
                        [dic setObject:@"" forKey:@"img"];
                    }
                    if([obj[@"usual"] isEqual: @1]){
                        [dic setValue:obj[@"see"] forKey:@"img"];
                        [dic setValue:obj[@"info"] forKey:@"info"];
                    }
                    [self->_dataArray addObject:dic ];
                }
            }];
            [self->_tableView reloadData];
            BOOL isyes = YES;
            for (int i = 0; i<self->_dataArray.count; i++) {
                NSString *img = self->_dataArray[i][@"img"];
                if ([img isEqualToString:@""]) {
                    isyes = NO;
                }
            }
            [self btn:isyes];
        }
    }];
}

-(void)getsouce{
    [self network];
}

-(void)btn:(BOOL)ys{
    if (ys) {
        _send.userInteractionEnabled = YES;
        [_send setBackgroundImage:[UIImage imageNamed:@"btn_long_bottom_bg_blue"] forState:UIControlStateNormal];
        [[_send rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self.navigationController popViewControllerAnimated:YES];
        }];
    }else{
        _send.userInteractionEnabled = NO;
        [_send setBackgroundImage:[UIImage imageNamed:@"btn_long_bottom_bg_grey"] forState:UIControlStateNormal];
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = RGBColor(240, 241, 245);
    UIView *v = [UIView new];
    [self.view addSubview:v];
    v.backgroundColor = [UIColor whiteColor];
    [v mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view);
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.height.mas_equalTo(statusBarAndNavigationBarHeight);
    }];
    [self nav];
    [self ui];
    [self network];

}

-(UITableView *)tableView {
    if(!_tableView){
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _tableView;
}

-(void)ui{
    UIImageView *top = [UIImageView new];
    top.image = [UIImage imageNamed:@"identitas_icon_warning"];
    [self.view addSubview:top];
    [top mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(SCALE(16)+statusBarAndNavigationBarHeight);
        make.left.equalTo(self.view).offset(SCALE(45));
        make.size.mas_equalTo(CGSizeMake(14,14));
    }];
    _t=top;
    UILabel *l = [UILabel new];
    l.text = @"Identity information cannot be changed once uploaded";
    l.textColor = RGBColor(226, 78, 78);
    l.font = DEF_FontSize_10;
    [l sizeToFit];
    [self.view addSubview:l];
    [l mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(top);
        make.left.equalTo(top).offset(18);
    }];
    UIButton *send = [UIButton buttonWithType:UIButtonTypeCustom];
    [send setBackgroundImage:[UIImage imageNamed:@"btn_long_bottom_bg_grey"] forState:UIControlStateNormal];
    [send setTitle:@"Next" forState:UIControlStateNormal];
    [send setTitleColor:RGBColor(255, 255, 255) forState:UIControlStateNormal];
    send.titleLabel.font = DEF_FontSize_17;
    send.userInteractionEnabled = NO;
    [self.view addSubview:send];
    [send mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.bottom.equalTo(self.view).offset(-tabbarSafeBottomMargin);
        make.height.mas_equalTo(SCALE(48));
    }];
    _send = send;
    [self tableView];
    [self.view addSubview:_tableView];
    [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(l).offset(SCALE(14)+l.bounds.size.height);
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.bottom.equalTo(send).offset(-SCALE(48));
    }];
    UIView *foot = [UIView new];
    foot.frame = CGRectMake(0, 0, SCREEN_WIDTH, 60);
    UILabel* f = [UILabel new ];
    f.text = @"Reminder:Uploading complete and clear photos can increase the efficiency and pass rate of loan approvals.";
    f.textColor = RGBColor(169, 170, 184);
    f.font = DEF_FontSize_10;
    f.numberOfLines = 0;
    f.textAlignment = NSTextAlignmentCenter;
    [foot addSubview:f];
    [f mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(foot).offset(SCALE(40));
        make.right.equalTo(foot).offset(-SCALE(40));
        make.center.equalTo(foot);
    }];
    _tableView.tableFooterView = foot;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return  SCALE(170);
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return  _dataArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    IdentificationCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IdentificationCell"];
    if (cell==nil)
    {
        cell=[[IdentificationCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"detailsCell"];
    }
    [cell setdic:_dataArray[indexPath.row]];
    cell.backgroundColor = [UIColor clearColor];
    cell.backgroundView = nil;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
//    {
        NSDictionary *dic = _dataArray[indexPath.row];
        NSString *img = dic[@"img"];
        NSLog(@"%@ == img",img);
        NSString *type = dic[@"type"];
        _type = type;
    if ([img isEqualToString:@""]) {
        if ([type isEqualToString:@"jeans"]) {
            [self beimian];
        }
        if ([type isEqualToString:@"coat"]) {
            [self renlian];
        }
        if ([type isEqualToString:@"pure"]) {
            [self dailog];
        }
        if ([type isEqualToString:@"small"]) {
            [self zhengmian];
        }
    }
//        self.imagePickerController = nil;
//        self.imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
////        top
////        self.imagePickerController.cameraDevice = UIImagePickerControllerCameraDeviceRear;
////        back
////        self.imagePickerController.cameraDevice = UIImagePickerControllerCameraDeviceFront;
//        [self presentViewController:self.imagePickerController animated:YES completion:nil];
//    }
//    else
//    {
//        [AppDelegate tostWithMessage:@"当前设备无摄像头，请从相册获取"];
//    }
}
-(void)nav{
    self.navigationItem.title = @"Identification information";
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor blackColor]}];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[[UIImage imageNamed:@"nav_bar_icon_left_back_b"] imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)] style:UIBarButtonItemStylePlain target:self action:@selector(leftButtonClick)];
}
-(UIImagePickerController *)imagePickerController
{
    if (!_imagePickerController)
    {
        _imagePickerController = [[UIImagePickerController alloc]init];
        _imagePickerController.allowsEditing = NO;
        _imagePickerController.delegate = self;
    }
    return _imagePickerController;
}
- (void)openVideoCamera
{
    self.imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
//    self.imagePickerController.mediaTypes = kUTTypeMovie;
    self.imagePickerController.videoQuality = UIImagePickerControllerQualityTypeHigh;
    //设置散光灯类型
    self.imagePickerController.cameraFlashMode = UIImagePickerControllerCameraFlashModeAuto;
    self.imagePickerController.videoMaximumDuration = 10;
    [[self viewController] presentViewController:self.imagePickerController animated:YES completion:nil];
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    [picker dismissViewControllerAnimated:YES completion:^{
        UIView *statusBar = [[[UIApplication sharedApplication] valueForKey:@"statusBarWindow"] valueForKey:@"statusBar"];
        statusBar.backgroundColor = nil;
    }];

    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    [self beginReqwith:image];
}
//获取父控制器
- (UIViewController *)viewController
{
    for (UIView *next = [self.view superview]; next; next = next.superview)
    {
        UIResponder *nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController *)nextResponder;
        }
    }
    return nil;
}

-(void)leftButtonClick{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark - TZImagePickerControllerDelegate
-(void)imagePickerController:(TZImagePickerController *)picker
      didFinishPickingPhotos:(NSArray<UIImage *> *)photos
                sourceAssets:(NSArray *)assets
       isSelectOriginalPhoto:(BOOL)isSelectOriginalPhoto
{
    NSLog(@"%@",photos);
}

- (void)imagePickerController:(TZImagePickerController *)picker didFinishPickingVideo:(UIImage *)coverImage sourceAssets:(PHAsset *)asset{
    NSLog(@"%@",coverImage);
}


- (void)beginReqwith:(UIImage *)img {
    MBProgressHUD *HUD;
    if (self.view) {
        HUD  = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        HUD.userInteractionEnabled = YES;
    }
    NSString *p = [NSString stringWithFormat:@"?upstairs=%@&took=%@&shaking=%@&around=%@&nose=%@&punch=%@",Version,deviceName,idfa,iosVersion,[UserModel sharedInstanced].nose,idfa];
    p = [p stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSString *url = [NSString stringWithFormat:@"http://147.139.4.18:8120/app/ruap/because?%@",p];
    AFHTTPSessionManager *imageManager = [AFHTTPSessionManager manager];
    imageManager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"image/jpeg",@"image/png",@"application/octet-stream",nil];
    imageManager.requestSerializer= [AFHTTPRequestSerializer serializer];
    imageManager.responseSerializer= [AFHTTPResponseSerializer serializer];
    NSString *did = @"";
    if ([_type isEqualToString:@"jeans"]) {
        did = @"12";
    }
    if ([_type isEqualToString:@"coat"]) {
        did = @"10";
    }
    if ([_type isEqualToString:@"pure"]) {
        did = @"13";
    }
    if ([_type isEqualToString:@"small"]) {
        did = @"11";
    }

    [imageManager POST:url parameters:@{@"blue":@"1",@"did":did,@"wearing":@""} headers:nil constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        formatter.dateFormat = @"yyyyMMddHHmmss";
        NSString *str = [formatter stringFromDate:[NSDate date]];
        NSString *fileName = [NSString stringWithFormat:@"%@.jpg", str];
        [formData appendPartWithFileData:UIImageJPEGRepresentation(img, 0.7) name:@"attach" fileName:fileName mimeType:@"image/jpeg"];
    } progress:^(NSProgress * _Nonnull uploadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        NSDictionary *jsonInfo = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
        NSLog(@"%@",jsonInfo);
        NSString *s = [NSString stringWithFormat:@"%@",jsonInfo[@"glass"]];
        if ([s isEqualToString:@"0"]) {
            if ([self->_type isEqualToString:@"pure"]) {
                [BusinessNetwork post:@"/ruap/smiled" paramers:@{@"shortly":jsonInfo[@"used"][@"sidewalk"],@"outside":jsonInfo[@"used"][@"onto"],@"breeze":jsonInfo[@"used"][@"young"],@"angeles":jsonInfo[@"used"][@"woman"],@"did":@"13"} HUDInView:nil PostsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
                    NSLog(@"%@",JSON);
                    NSString *s = [NSString stringWithFormat:@"%@",JSON[@"glass"]];
                    if ([s isEqualToString:@"0"]) {
                        [self network];
                    }
                }];
            }
            if ([self->_type isEqualToString:@"small"]) {
                [self pan:jsonInfo];

//                [BusinessNetwork post:@"/ruap/smiled" paramers:@{@"shortly":jsonInfo[@"used"][@"shortly"],@"breeze":jsonInfo[@"used"][@"breeze"],@"angeles":jsonInfo[@"used"][@"angeles"],@"did":@"11"} HUDInView:nil PostsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
//                    NSLog(@"%@",JSON);
//                    NSString *s = [NSString stringWithFormat:@"%@",JSON[@"glass"]];
//                    if ([s isEqualToString:@"0"]) {
//                        [self network];
//                    }
//                }];
            }
        }
        [AppDelegate tostWithMessage:jsonInfo[@"watches"]];
        NSLog(@"成功");
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];

        NSLog(@"失败");
    }];
}

-(void)dailog{
    myAlert =
    Dialog()
    .wCustomMainViewSet(^(UIView *mainView) {
    })
    .wHeightSet(SCALE(422))
    .wTypeSet(DialogTypeMyView)
    .wWidthSet(Device_Dialog_Width*0.8)
    .wShowAnimationSet(AninatonZoomInCombin)
    .wHideAnimationSet(AninatonZoomOut)
    .wMyDiaLogViewSet(^UIView *(UIView *mainView) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setImage:[UIImage imageNamed:@"details_list_icon_del"] forState:UIControlStateNormal];
        [mainView addSubview:btn];
        [btn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(mainView).offset(-SCALE(16));
            make.top.equalTo(mainView).offset(SCALE(16));
            make.size.mas_equalTo(CGSizeMake(SCALE(12), SCALE(12)));
        }];
        UIImageView* t = [UIImageView new];
        t.image = [UIImage imageNamed:@"pop_pancorrect"];
        [mainView addSubview:t];
        [t mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(mainView).offset(SCALE(42));
            make.left.equalTo(mainView).offset(SCALE(22));
            make.right.equalTo(mainView).offset(-SCALE(22));
            make.height.mas_equalTo(SCALE(176));
        }];
        UIImageView* b = [UIImageView new];
        b.image = [UIImage imageNamed:@"pop_panwrong"];
        [mainView addSubview:b];
        [b mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(t).offset(SCALE(192));
            make.left.equalTo(mainView).offset(SCALE(22));
            make.right.equalTo(mainView).offset(-SCALE(22));
            make.height.mas_equalTo(SCALE(105));
        }];
        UIButton *send = [UIButton buttonWithType:UIButtonTypeCustom];
        [send setBackgroundImage:[UIImage imageNamed:@"btn_pop_blue"] forState:UIControlStateNormal];
        [send setTitle:@"Confirm" forState:UIControlStateNormal];
        [send setTitleColor:RGBColor(255, 255, 255) forState:UIControlStateNormal];
        send.titleLabel.font = DEF_FontSize_14;
        [mainView addSubview:send];
        [send mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(mainView).offset(-SCALE(24));
            make.centerX.equalTo(mainView);
            make.size.mas_equalTo(CGSizeMake(SCALE(226), SCALE(36)));
        }];
        mainView.layer.masksToBounds = YES;
        mainView.layer.cornerRadius = 10;
        [[btn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
        }];
        [[send rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
            if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
            {
                self.imagePickerController = nil;
                self.imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
                //        top
                self.imagePickerController.cameraDevice = UIImagePickerControllerCameraDeviceRear;
                //        back
//                self.imagePickerController.cameraDevice = UIImagePickerControllerCameraDeviceFront;
                [self presentViewController:self.imagePickerController animated:YES completion:nil];
            }
            else
            {
                [AppDelegate tostWithMessage:@"当前设备无摄像头，请从相册获取"];
            }

        }];
        return nil;
    })
    .wStart();
}

-(void)zhengmian{
    myAlert =
    Dialog()
    .wCustomMainViewSet(^(UIView *mainView) {
    })
    .wHeightSet(SCALE(422))
    .wTypeSet(DialogTypeMyView)
    .wWidthSet(Device_Dialog_Width*0.8)
    .wShowAnimationSet(AninatonZoomInCombin)
    .wHideAnimationSet(AninatonZoomOut)
    .wMyDiaLogViewSet(^UIView *(UIView *mainView) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setImage:[UIImage imageNamed:@"details_list_icon_del"] forState:UIControlStateNormal];
        [mainView addSubview:btn];
        [btn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(mainView).offset(-SCALE(16));
            make.top.equalTo(mainView).offset(SCALE(16));
            make.size.mas_equalTo(CGSizeMake(SCALE(12), SCALE(12)));
        }];
        UIImageView* t = [UIImageView new];
        t.image = [UIImage imageNamed:@"pop_idcorrect"];
        [mainView addSubview:t];
        [t mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(mainView).offset(SCALE(42));
            make.left.equalTo(mainView).offset(SCALE(22));
            make.right.equalTo(mainView).offset(-SCALE(22));
            make.height.mas_equalTo(SCALE(176));
        }];
        UIImageView* b = [UIImageView new];
        b.image = [UIImage imageNamed:@"pop_idwrong"];
        [mainView addSubview:b];
        [b mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(t).offset(SCALE(192));
            make.left.equalTo(mainView).offset(SCALE(22));
            make.right.equalTo(mainView).offset(-SCALE(22));
            make.height.mas_equalTo(SCALE(105));
        }];
        UIButton *send = [UIButton buttonWithType:UIButtonTypeCustom];
        [send setBackgroundImage:[UIImage imageNamed:@"btn_pop_blue"] forState:UIControlStateNormal];
        [send setTitle:@"Confirm" forState:UIControlStateNormal];
        [send setTitleColor:RGBColor(255, 255, 255) forState:UIControlStateNormal];
        send.titleLabel.font = DEF_FontSize_14;
        [mainView addSubview:send];
        [send mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(mainView).offset(-SCALE(24));
            make.centerX.equalTo(mainView);
            make.size.mas_equalTo(CGSizeMake(SCALE(226), SCALE(36)));
        }];
        mainView.layer.masksToBounds = YES;
        mainView.layer.cornerRadius = 10;
        [[btn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
        }];
        [[send rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
            if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
            {
                self.imagePickerController = nil;
                self.imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
                //        top
                self.imagePickerController.cameraDevice = UIImagePickerControllerCameraDeviceRear;
                //        back
                //                self.imagePickerController.cameraDevice = UIImagePickerControllerCameraDeviceFront;
                [self presentViewController:self.imagePickerController animated:YES completion:nil];
            }
            else
            {
                [AppDelegate tostWithMessage:@"当前设备无摄像头，请从相册获取"];
            }
            
        }];
        return nil;
    })
    .wStart();
}

-(void)beimian{
    myAlert =
    Dialog()
    .wCustomMainViewSet(^(UIView *mainView) {
    })
    .wHeightSet(SCALE(422))
    .wTypeSet(DialogTypeMyView)
    .wWidthSet(Device_Dialog_Width*0.8)
    .wShowAnimationSet(AninatonZoomInCombin)
    .wHideAnimationSet(AninatonZoomOut)
    .wMyDiaLogViewSet(^UIView *(UIView *mainView) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setImage:[UIImage imageNamed:@"details_list_icon_del"] forState:UIControlStateNormal];
        [mainView addSubview:btn];
        [btn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(mainView).offset(-SCALE(16));
            make.top.equalTo(mainView).offset(SCALE(16));
            make.size.mas_equalTo(CGSizeMake(SCALE(12), SCALE(12)));
        }];
        UIImageView* t = [UIImageView new];
        t.image = [UIImage imageNamed:@"pop_idbackcorrect"];
        [mainView addSubview:t];
        [t mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(mainView).offset(SCALE(42));
            make.left.equalTo(mainView).offset(SCALE(22));
            make.right.equalTo(mainView).offset(-SCALE(22));
            make.height.mas_equalTo(SCALE(176));
        }];
        UIImageView* b = [UIImageView new];
        b.image = [UIImage imageNamed:@"pop_idbackwrong"];
        [mainView addSubview:b];
        [b mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(t).offset(SCALE(192));
            make.left.equalTo(mainView).offset(SCALE(22));
            make.right.equalTo(mainView).offset(-SCALE(22));
            make.height.mas_equalTo(SCALE(105));
        }];
        UIButton *send = [UIButton buttonWithType:UIButtonTypeCustom];
        [send setBackgroundImage:[UIImage imageNamed:@"btn_pop_blue"] forState:UIControlStateNormal];
        [send setTitle:@"Confirm" forState:UIControlStateNormal];
        [send setTitleColor:RGBColor(255, 255, 255) forState:UIControlStateNormal];
        send.titleLabel.font = DEF_FontSize_14;
        [mainView addSubview:send];
        [send mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(mainView).offset(-SCALE(24));
            make.centerX.equalTo(mainView);
            make.size.mas_equalTo(CGSizeMake(SCALE(226), SCALE(36)));
        }];
        mainView.layer.masksToBounds = YES;
        mainView.layer.cornerRadius = 10;
        [[btn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
        }];
        [[send rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
            if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
            {
                self.imagePickerController = nil;
                self.imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
                //        top
                self.imagePickerController.cameraDevice = UIImagePickerControllerCameraDeviceRear;
                //        back
                //                self.imagePickerController.cameraDevice = UIImagePickerControllerCameraDeviceFront;
                [self presentViewController:self.imagePickerController animated:YES completion:nil];
            }
            else
            {
                [AppDelegate tostWithMessage:@"当前设备无摄像头，请从相册获取"];
            }
            
        }];
        return nil;
    })
    .wStart();
}

-(void)renlian{
    myAlert =
    Dialog()
    .wCustomMainViewSet(^(UIView *mainView) {
    })
    .wHeightSet(SCALE(422))
    .wTypeSet(DialogTypeMyView)
    .wWidthSet(Device_Dialog_Width*0.8)
    .wShowAnimationSet(AninatonZoomInCombin)
    .wHideAnimationSet(AninatonZoomOut)
    .wMyDiaLogViewSet(^UIView *(UIView *mainView) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setImage:[UIImage imageNamed:@"details_list_icon_del"] forState:UIControlStateNormal];
        [mainView addSubview:btn];
        [btn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(mainView).offset(-SCALE(16));
            make.top.equalTo(mainView).offset(SCALE(16));
            make.size.mas_equalTo(CGSizeMake(SCALE(12), SCALE(12)));
        }];
        UIImageView* t = [UIImageView new];
        t.image = [UIImage imageNamed:@"pop_facecorrect"];
        [mainView addSubview:t];
        [t mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(mainView).offset(SCALE(42));
            make.left.equalTo(mainView).offset(SCALE(22));
            make.right.equalTo(mainView).offset(-SCALE(22));
            make.height.mas_equalTo(SCALE(176));
        }];
        UIImageView* b = [UIImageView new];
        b.image = [UIImage imageNamed:@"pop_facewrong"];
        [mainView addSubview:b];
        [b mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(t).offset(SCALE(192));
            make.left.equalTo(mainView).offset(SCALE(22));
            make.right.equalTo(mainView).offset(-SCALE(22));
            make.height.mas_equalTo(SCALE(105));
        }];
        UIButton *send = [UIButton buttonWithType:UIButtonTypeCustom];
        [send setBackgroundImage:[UIImage imageNamed:@"btn_pop_blue"] forState:UIControlStateNormal];
        [send setTitle:@"Confirm" forState:UIControlStateNormal];
        [send setTitleColor:RGBColor(255, 255, 255) forState:UIControlStateNormal];
        send.titleLabel.font = DEF_FontSize_14;
        [mainView addSubview:send];
        [send mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(mainView).offset(-SCALE(24));
            make.centerX.equalTo(mainView);
            make.size.mas_equalTo(CGSizeMake(SCALE(226), SCALE(36)));
        }];
        mainView.layer.masksToBounds = YES;
        mainView.layer.cornerRadius = 10;
        [[btn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
        }];
        [[send rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
            if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
            {
                self.imagePickerController = nil;
                self.imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
                //        top
                self.imagePickerController.cameraDevice = UIImagePickerControllerCameraDeviceRear;
                //        back
                //                self.imagePickerController.cameraDevice = UIImagePickerControllerCameraDeviceFront;
                [self presentViewController:self.imagePickerController animated:YES completion:nil];
            }
            else
            {
                [AppDelegate tostWithMessage:@"当前设备无摄像头，请从相册获取"];
            }
            
        }];
        return nil;
    })
    .wStart();
}

-(void)pan:(NSDictionary*)dic{
    myAlert =
    Dialog()
    .wCustomMainViewSet(^(UIView *mainView) {
    })
    .wHeightSet(SCALE(476))
    .wTypeSet(DialogTypeMyView)
    .wWidthSet(Device_Dialog_Width)
    .wShowAnimationSet(AninatonZoomInCombin)
    .wHideAnimationSet(AninatonZoomOut)
    .wMainToBottomSet(YES)
    .wMyDiaLogViewSet(^UIView *(UIView *mainView) {
        mainView.backgroundColor = RGBColor(240, 241, 245);
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setImage:[UIImage imageNamed:@"details_list_icon_del"] forState:UIControlStateNormal];
        [mainView addSubview:btn];
        [btn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(mainView).offset(-SCALE(16));
            make.top.equalTo(mainView).offset(SCALE(16));
            make.size.mas_equalTo(CGSizeMake(SCALE(12), SCALE(12)));
        }];

        UILabel *name = [UILabel new];
        name.text = @"PAN card number";
        name.textColor = RGBColor(169, 170, 184);
        name.font = DEF_FontSize_14;
        [name sizeToFit];
        [mainView addSubview:name];
        UIView *back = [[UIView alloc]init];
        back.backgroundColor = RGBColor(214, 221, 239);
        [mainView addSubview:back];
        UITextField *t = [[UITextField alloc]init];
        [back addSubview:t];
        back.layer.cornerRadius = 4;
        t.textColor = DDMColor(35, 36, 40);
        t.backgroundColor = [UIColor clearColor];
        t.font = DEF_FontSize_14;
        [mainView addSubview:t];

        [name mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(btn).offset(SCALE(12)+15);
            make.left.equalTo(mainView).offset(SCALE(15));
//            make.top.equalTo(mainView);
        }];
        [back mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(mainView).offset(SCALE(15));
            make.right.equalTo(mainView).offset(-SCALE(15));
            make.top.equalTo(name).offset(SCALE(10)+name.bounds.size.height);
            make.height.mas_equalTo(SCALE(48));
        }];
        [t mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(back).offset(SCALE(15));
            make.right.equalTo(back).offset(-SCALE(20));
            make.height.mas_equalTo(48);
            make.centerY.equalTo(back);
        }];


        UILabel *name2 = [UILabel new];
        name2.text = @"PAN name";
        name2.textColor = RGBColor(169, 170, 184);
        name2.font = DEF_FontSize_14;
        [name2 sizeToFit];
        [mainView addSubview:name2];
        UIView *back2 = [[UIView alloc]init];
        back2.backgroundColor = RGBColor(214, 221, 239);
        [mainView addSubview:back2];
        UITextField *t2 = [[UITextField alloc]init];
        [back2 addSubview:t2];
        back2.layer.cornerRadius = 4;
        t2.textColor = DDMColor(35, 36, 40);
        t2.backgroundColor = [UIColor clearColor];
        t2.font = DEF_FontSize_14;
        [mainView addSubview:t2];
        [name2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(back).offset(SCALE(48)+15);
            make.left.equalTo(mainView).offset(SCALE(15));
            //            make.top.equalTo(mainView);
        }];
        [back2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(mainView).offset(SCALE(15));
            make.right.equalTo(mainView).offset(-SCALE(15));
            make.top.equalTo(name2).offset(SCALE(10)+name2.bounds.size.height);
            make.height.mas_equalTo(SCALE(48));
        }];
        [t2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(back2).offset(SCALE(15));
            make.right.equalTo(back2).offset(-SCALE(20));
            make.height.mas_equalTo(48);
            make.centerY.equalTo(back2);
        }];

        UILabel *name3 = [UILabel new];
        name3.text = @"PAN father’s name";
        name3.textColor = RGBColor(169, 170, 184);
        name3.font = DEF_FontSize_14;
        [name3 sizeToFit];
        [mainView addSubview:name3];
        UIView *back3 = [[UIView alloc]init];
        back3.backgroundColor = RGBColor(214, 221, 239);
        [mainView addSubview:back3];
        UITextField *t3 = [[UITextField alloc]init];
        [back3 addSubview:t3];
        back3.layer.cornerRadius = 4;
        t3.textColor = DDMColor(35, 36, 40);
        t3.backgroundColor = [UIColor clearColor];
        t3.font = DEF_FontSize_14;
        [mainView addSubview:t3];
        [name3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(back2).offset(SCALE(48)+15);
            make.left.equalTo(mainView).offset(SCALE(15));
            //            make.top.equalTo(mainView);
        }];
        [back3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(mainView).offset(SCALE(15));
            make.right.equalTo(mainView).offset(-SCALE(15));
            make.top.equalTo(name3).offset(SCALE(10)+name3.bounds.size.height);
            make.height.mas_equalTo(SCALE(48));
        }];
        [t3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(back3).offset(SCALE(15));
            make.right.equalTo(back3).offset(-SCALE(20));
            make.height.mas_equalTo(48);
            make.centerY.equalTo(back3);
        }];

        
        UILabel *name4 = [UILabel new];
        name4.text = @"PAN birthday";
        name4.textColor = RGBColor(169, 170, 184);
        name4.font = DEF_FontSize_14;
        [name4 sizeToFit];
        [mainView addSubview:name4];
        UIView *back4 = [[UIView alloc]init];
        back4.backgroundColor = RGBColor(214, 221, 239);
        [mainView addSubview:back4];
        UILabel *t4 = [[UILabel alloc]init];
        [back4 addSubview:t4];
        back4.layer.cornerRadius = 4;
        t4.textColor = DDMColor(35, 36, 40);
        t4.backgroundColor = [UIColor clearColor];
        t4.font = DEF_FontSize_14;
        [mainView addSubview:t4];
        UIImageView *b = [UIImageView new];
        b.image = [UIImage imageNamed:@"details_list_icon_arrow_d"];
        [back4 addSubview:b];
        UIControl *col = [UIControl new];
        [back4 addSubview:col];
        [name4 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(back3).offset(SCALE(48)+15);
            make.left.equalTo(mainView).offset(SCALE(15));
            //            make.top.equalTo(mainView);
        }];
        [back4 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(mainView).offset(SCALE(15));
            make.right.equalTo(mainView).offset(-SCALE(15));
            make.top.equalTo(name4).offset(SCALE(10)+name4.bounds.size.height);
            make.height.mas_equalTo(SCALE(48));
        }];
        [t4 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(back4).offset(SCALE(15));
            make.right.equalTo(back4).offset(-SCALE(20));
            make.height.mas_equalTo(48);
            make.centerY.equalTo(back4);
        }];
        [b mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(back4);
            make.right.equalTo(back4).offset(-SCALE(15));
        }];
        [col mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(back4);
            make.left.equalTo(back4);
            make.right.equalTo(back4);
            make.bottom.equalTo(back4);
        }];
        [[col rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            // 出生年月日
            BRDatePickerView *datePickerView = [[BRDatePickerView alloc]init];
            datePickerView.pickerMode = BRDatePickerModeYMD;
//            datePickerView.title = @"请选择年月日";
//            datePickerView.selectDate = self.birthdaySelectDate;
            datePickerView.minDate = [NSDate br_setYear:2018 month:3 day:10];
            datePickerView.maxDate = [NSDate br_setYear:2025 month:10 day:20];
            datePickerView.isAutoSelect = YES;
            datePickerView.customUnit = @{@"year": @"", @"month": @"M", @"day": @"", @"hour": @"H", @"minute": @"M", @"second": @"S"};
            datePickerView.resultBlock = ^(NSDate *selectDate, NSString *selectValue) {
                t4.text =selectValue;
            };
            
            UILabel *yearLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 44, self.view.bounds.size.width, 216)];
            yearLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
            yearLabel.backgroundColor = [UIColor clearColor];
            yearLabel.textAlignment = NSTextAlignmentCenter;
            yearLabel.textColor = [[UIColor lightGrayColor] colorWithAlphaComponent:0.2f];
            yearLabel.font = [UIFont boldSystemFontOfSize:100.0f];
            datePickerView.changeBlock = ^(NSDate * _Nullable selectDate, NSString * _Nullable selectValue) {
                yearLabel.text = selectDate ? @(selectDate.br_year).stringValue : @"";
            };
            
            BRPickerStyle *customStyle = [[BRPickerStyle alloc]init];
            customStyle.pickerColor = RGBColor(240, 241, 245);
            customStyle.pickerTextColor = RGBColor(45, 86, 204);
            customStyle.titleBarHeight = 50;
            customStyle.titleBarColor = RGBColor(240, 241, 245);
            customStyle.titleLabelColor = [UIColor clearColor];
            customStyle.titleTextColor = [UIColor whiteColor];
            customStyle.cancelTextColor = RGBColor(169, 170, 184);
            customStyle.doneTextColor = RGBColor(45, 86, 204);
            customStyle.separatorColor = [UIColor clearColor];
            customStyle.selectRowColor = DDMColor(255, 255, 255);
            datePickerView.pickerStyle = customStyle;
            
            [datePickerView show];

        }];
        
        UIButton *send = [UIButton buttonWithType:UIButtonTypeCustom];
        [send setBackgroundImage:[UIImage imageNamed:@"btn_pop_blue"] forState:UIControlStateNormal];
        [send setTitle:@"Confirm" forState:UIControlStateNormal];
        [send setTitleColor:RGBColor(255, 255, 255) forState:UIControlStateNormal];
        send.titleLabel.font = DEF_FontSize_14;
        [mainView addSubview:send];
        [send mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(mainView).offset(-SCALE(24));
            make.centerX.equalTo(mainView);
            make.size.mas_equalTo(CGSizeMake(SCALE(226), SCALE(36)));
        }];
        mainView.layer.masksToBounds = YES;
        mainView.layer.cornerRadius = 10;
        [[btn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
        }];
        [[send rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
            
            [BusinessNetwork post:@"/ruap/smiled" paramers:@{@"shortly":t4.text,@"outside":t.text,@"breeze":t2.text,@"angeles":t3.text,@"did":@"13"} HUDInView:self.view PostsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
                    NSLog(@"%@",JSON);
                    NSString *s = [NSString stringWithFormat:@"%@",JSON[@"glass"]];
                    if ([s isEqualToString:@"0"]) {
                        [self network];
                    }
            }];
        }];
        return nil;
    })
    .wStart();
}
-(void)idcart:(NSDictionary *)dic{
    myAlert =
    Dialog()
    .wCustomMainViewSet(^(UIView *mainView) {
    })
    .wHeightSet(SCALE(388))
    .wTypeSet(DialogTypeMyView)
    .wWidthSet(Device_Dialog_Width)
    .wShowAnimationSet(AninatonZoomInCombin)
    .wHideAnimationSet(AninatonZoomOut)
    .wMainToBottomSet(YES)
    .wMyDiaLogViewSet(^UIView *(UIView *mainView) {
        mainView.backgroundColor = RGBColor(240, 241, 245);
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setImage:[UIImage imageNamed:@"details_list_icon_del"] forState:UIControlStateNormal];
        [mainView addSubview:btn];
        [btn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(mainView).offset(-SCALE(16));
            make.top.equalTo(mainView).offset(SCALE(16));
            make.size.mas_equalTo(CGSizeMake(SCALE(12), SCALE(12)));
        }];
        
        UILabel *name = [UILabel new];
        name.text = @"PAN card number";
        name.textColor = RGBColor(169, 170, 184);
        name.font = DEF_FontSize_14;
        [name sizeToFit];
        [mainView addSubview:name];
        UIView *back = [[UIView alloc]init];
        back.backgroundColor = RGBColor(214, 221, 239);
        [mainView addSubview:back];
        UITextField *t = [[UITextField alloc]init];
        [back addSubview:t];
        back.layer.cornerRadius = 4;
        t.textColor = DDMColor(35, 36, 40);
        t.backgroundColor = [UIColor clearColor];
        t.font = DEF_FontSize_14;
        [mainView addSubview:t];
        
        [name mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(btn).offset(SCALE(12)+15);
            make.left.equalTo(mainView).offset(SCALE(15));
            //            make.top.equalTo(mainView);
        }];
        [back mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(mainView).offset(SCALE(15));
            make.right.equalTo(mainView).offset(-SCALE(15));
            make.top.equalTo(name).offset(SCALE(10)+name.bounds.size.height);
            make.height.mas_equalTo(SCALE(48));
        }];
        [t mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(back).offset(SCALE(15));
            make.right.equalTo(back).offset(-SCALE(20));
            make.height.mas_equalTo(48);
            make.centerY.equalTo(back);
        }];
        
        
        UILabel *name2 = [UILabel new];
        name2.text = @"PAN name";
        name2.textColor = RGBColor(169, 170, 184);
        name2.font = DEF_FontSize_14;
        [name2 sizeToFit];
        [mainView addSubview:name2];
        UIView *back2 = [[UIView alloc]init];
        back2.backgroundColor = RGBColor(214, 221, 239);
        [mainView addSubview:back2];
        UITextField *t2 = [[UITextField alloc]init];
        [back2 addSubview:t2];
        back2.layer.cornerRadius = 4;
        t2.textColor = DDMColor(35, 36, 40);
        t2.backgroundColor = [UIColor clearColor];
        t2.font = DEF_FontSize_14;
        [mainView addSubview:t2];
        [name2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(back).offset(SCALE(48)+15);
            make.left.equalTo(mainView).offset(SCALE(15));
            //            make.top.equalTo(mainView);
        }];
        [back2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(mainView).offset(SCALE(15));
            make.right.equalTo(mainView).offset(-SCALE(15));
            make.top.equalTo(name2).offset(SCALE(10)+name2.bounds.size.height);
            make.height.mas_equalTo(SCALE(48));
        }];
        [t2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(back2).offset(SCALE(15));
            make.right.equalTo(back2).offset(-SCALE(20));
            make.height.mas_equalTo(48);
            make.centerY.equalTo(back2);
        }];
        
        
        
        UILabel *name4 = [UILabel new];
        name4.text = @"PAN birthday";
        name4.textColor = RGBColor(169, 170, 184);
        name4.font = DEF_FontSize_14;
        [name4 sizeToFit];
        [mainView addSubview:name4];
        UIView *back4 = [[UIView alloc]init];
        back4.backgroundColor = RGBColor(214, 221, 239);
        [mainView addSubview:back4];
        UILabel *t4 = [[UILabel alloc]init];
        [back4 addSubview:t4];
        back4.layer.cornerRadius = 4;
        t4.textColor = DDMColor(35, 36, 40);
        t4.backgroundColor = [UIColor clearColor];
        t4.font = DEF_FontSize_14;
        [mainView addSubview:t4];
        UIImageView *b = [UIImageView new];
        b.image = [UIImage imageNamed:@"details_list_icon_arrow_d"];
        [back4 addSubview:b];
        UIControl *col = [UIControl new];
        [back4 addSubview:col];
        [name4 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(back2).offset(SCALE(48)+15);
            make.left.equalTo(mainView).offset(SCALE(15));
            //            make.top.equalTo(mainView);
        }];
        [back4 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(mainView).offset(SCALE(15));
            make.right.equalTo(mainView).offset(-SCALE(15));
            make.top.equalTo(name4).offset(SCALE(10)+name4.bounds.size.height);
            make.height.mas_equalTo(SCALE(48));
        }];
        [t4 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(back4).offset(SCALE(15));
            make.right.equalTo(back4).offset(-SCALE(20));
            make.height.mas_equalTo(48);
            make.centerY.equalTo(back4);
        }];
        [b mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(back4);
            make.right.equalTo(back4).offset(-SCALE(15));
        }];
        [col mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(back4);
            make.left.equalTo(back4);
            make.right.equalTo(back4);
            make.bottom.equalTo(back4);
        }];
        [[col rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            // 出生年月日
            BRDatePickerView *datePickerView = [[BRDatePickerView alloc]init];
            datePickerView.pickerMode = BRDatePickerModeYMD;
            //            datePickerView.title = @"请选择年月日";
            //            datePickerView.selectDate = self.birthdaySelectDate;
            datePickerView.minDate = [NSDate br_setYear:2018 month:3 day:10];
            datePickerView.maxDate = [NSDate br_setYear:2025 month:10 day:20];
            datePickerView.isAutoSelect = YES;
            datePickerView.customUnit = @{@"year": @"", @"month": @"M", @"day": @"", @"hour": @"H", @"minute": @"M", @"second": @"S"};
            datePickerView.resultBlock = ^(NSDate *selectDate, NSString *selectValue) {
                t4.text = selectValue;
            };
            
            UILabel *yearLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 44, self.view.bounds.size.width, 216)];
            yearLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
            yearLabel.backgroundColor = [UIColor clearColor];
            yearLabel.textAlignment = NSTextAlignmentCenter;
            yearLabel.textColor = [[UIColor lightGrayColor] colorWithAlphaComponent:0.2f];
            yearLabel.font = [UIFont boldSystemFontOfSize:100.0f];
            datePickerView.changeBlock = ^(NSDate * _Nullable selectDate, NSString * _Nullable selectValue) {
                yearLabel.text = selectDate ? @(selectDate.br_year).stringValue : @"";
            };
            BRPickerStyle *customStyle = [[BRPickerStyle alloc]init];
            customStyle.pickerColor = RGBColor(240, 241, 245);
            customStyle.pickerTextColor = RGBColor(45, 86, 204);
            customStyle.titleBarHeight = 50;
            customStyle.titleBarColor = RGBColor(240, 241, 245);
            customStyle.titleLabelColor = [UIColor clearColor];
            customStyle.titleTextColor = [UIColor whiteColor];
            customStyle.cancelTextColor = RGBColor(169, 170, 184);
            customStyle.doneTextColor = RGBColor(45, 86, 204);
            customStyle.separatorColor = [UIColor clearColor];
            customStyle.selectRowColor = DDMColor(255, 255, 255);
            datePickerView.pickerStyle = customStyle;
            [datePickerView show];
        }];
        UIButton *send = [UIButton buttonWithType:UIButtonTypeCustom];
        [send setBackgroundImage:[UIImage imageNamed:@"btn_pop_blue"] forState:UIControlStateNormal];
        [send setTitle:@"Confirm" forState:UIControlStateNormal];
        [send setTitleColor:RGBColor(255, 255, 255) forState:UIControlStateNormal];
        send.titleLabel.font = DEF_FontSize_14;
        [mainView addSubview:send];
        [send mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(mainView).offset(-SCALE(24));
            make.centerX.equalTo(mainView);
            make.size.mas_equalTo(CGSizeMake(SCALE(226), SCALE(36)));
        }];
        mainView.layer.masksToBounds = YES;
        mainView.layer.cornerRadius = 10;
        [[btn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
        }];
        [[send rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [self->myAlert closeView];
            
            [BusinessNetwork post:@"/ruap/smiled" paramers:@{@"shortly":t4.text,@"breeze":t.text,@"angeles":t2.text,@"did":@"13"} HUDInView:self.view PostsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
                NSLog(@"%@",JSON);
                NSString *s = [NSString stringWithFormat:@"%@",JSON[@"glass"]];
                if ([s isEqualToString:@"0"]) {
                    [self network];
                }
                [AppDelegate tostWithMessage:JSON[@"watches"]];
            }];
        }];
            return nil;
    })
    .wStart();
}

@end
