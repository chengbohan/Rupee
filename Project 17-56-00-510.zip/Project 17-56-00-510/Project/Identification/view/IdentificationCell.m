//
//  IdentificationCell.m
//  Project
//
//  Created by 回春雷 on 2023/4/7.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "IdentificationCell.h"
#import <SDWebImage/SDWebImage.h>
@interface IdentificationCell()
@property (nonatomic,strong)UIImageView *icon;
@property (nonatomic,strong)UILabel *title;
@property (nonatomic,strong)UIView *back;
@end
@implementation IdentificationCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if ([super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        UIView *v = [UIView new];
        [self.contentView addSubview:v];
        [v mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView);
            make.right.equalTo(self.contentView);
            make.height.mas_equalTo(SCALE(150));
        }];
        _back = v;
        UIImageView *icon = [UIImageView new];
        icon.image = [UIImage imageNamed:@"identitas_idfront"];
        [v addSubview:icon];
        [icon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(v);
            make.top.equalTo(v);
            make.size.mas_equalTo(CGSizeMake(SCALE(247), SCALE(136)));
        }];
        _icon = icon;
        UILabel *title = [UILabel new];
        [v addSubview:title];
        title.text = @"PAN Card";
        title.textColor = RGBColor(35, 36, 40);
        title.font = DEF_FontSize_14;
        [title mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(v);
            make.top.equalTo(icon).offset(SCALE(136)+8);
        }];
        _title = title;
        
    }
    return self;
}
-(void)setdic:(NSDictionary *)dic{
    NSString *type = dic[@"type"];
    NSString *img = dic[@"img"];
    if ([type isEqualToString:@"jeans"]) {
        _title.text = @"Aadhaar Back";
        if ([img  isEqualToString:@""]) {
            _icon.image = [UIImage imageNamed:@"identitas_idback"];
        }else{
            NSLog(@"2222%@",img);
            [_icon sd_setImageWithURL:[NSURL URLWithString:img] placeholderImage:[UIImage imageNamed:@"identitas_idback"]];
        }
    }
    if ([type isEqualToString:@"coat"]) {
        _title.text = @"Living Recognition";
        if ([img isEqualToString:@""]) {
            _icon.image = [UIImage imageNamed:@"identitas_face"];
        }else{
            NSLog(@"2222%@",img);

            [_icon sd_setImageWithURL:[NSURL URLWithString:img] placeholderImage:[UIImage imageNamed:@"identitas_face"]];
        }
    }
    if ([type isEqualToString:@"pure"]) {
        _title.text = @"PAN Card";
        if ([img isEqualToString:@""]) {
            _icon.image = [UIImage imageNamed:@"identitas_panfront"];
        }else{
            NSLog(@"2222%@",img);

            [_icon sd_setImageWithURL:[NSURL URLWithString:img] placeholderImage:[UIImage imageNamed:@"identitas_panfront"]];
        }
    }
    if ([type isEqualToString:@"small"]) {
        _title.text = @"Aadhaar Front";
        if ([img isEqualToString:@""]) {
            _icon.image = [UIImage imageNamed:@"identitas_idfront"];
        }else{
            NSLog(@"22222%@",img);

            [_icon sd_setImageWithURL:[NSURL URLWithString:img] placeholderImage:[UIImage imageNamed:@"identitas_idfront"]];
        }
    }

//    [_icon sd_setImageWithURL:[NSURL URLWithString:dic[@"img"]] placeholderImage:[UIImage imageNamed:@"Living Recognition"]];
}
@end
