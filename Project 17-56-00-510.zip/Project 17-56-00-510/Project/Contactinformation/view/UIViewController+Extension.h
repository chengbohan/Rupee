//
//  UIViewController+Extension.h
//  ContactsTest
//
//  Created by 李泽萌 on 2021/7/16.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIViewController (Extension)
+ (UIViewController *)currentViewController;
@end

NS_ASSUME_NONNULL_END
