//
//  ContactionCell.m
//  Project
//
//  Created by 回春雷 on 2023/4/14.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "ContactionCell.h"
@interface ContactionCell()
@property (nonatomic,strong)UIView *back;
@property (nonatomic,strong)UILabel *name;
@property (nonatomic,strong)UIImageView *b;
@property (nonatomic,strong)UILabel *title;

@property (nonatomic,strong)UIView *back2;
@property (nonatomic,strong)UILabel *name2;
@property (nonatomic,strong)UIImageView *b2;

@end
@implementation ContactionCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        UILabel *title = [UILabel new];
        title.text = @"Contact emergency contact 1";
        title.textColor = RGBColor(35, 36, 40);
        title.font = DEF_FontSize_14;
        [self.contentView addSubview:title];
        [title sizeToFit];
        _title = title;
        
        UILabel *name = [UILabel new];
        name.text = @"Relationship";
        name.textColor = RGBColor(169, 170, 184);
        name.font = DEF_FontSize_14;
        [name sizeToFit];
        [self.contentView addSubview:name];
        self.name = name;
        self.backgroundColor = [UIColor clearColor];
        self.contentView.backgroundColor = [UIColor clearColor];
        UIView *back = [[UIView alloc]init];
        [self.contentView addSubview:back];
        back.backgroundColor = RGBColor(214, 221, 239);
        UILabel *t = [[UILabel alloc]init];
        [back addSubview:t];
        back.layer.cornerRadius = 4;
        self.t = t;
        t.textColor = DDMColor(147, 146, 146);
        t.backgroundColor = [UIColor clearColor];
        t.font = DEF_FontSize_14;
        _back = back;
        UIImageView *b = [UIImageView new];
        b.image = [UIImage imageNamed:@"details_list_icon_arrow_d"];
        [_back addSubview:b];
        _b = b;
        _control = [[UIControl alloc]init];
        [self.contentView addSubview:_control];
        
        
        UILabel *name2 = [UILabel new];
        name2.text = @"Phone Number";
        name2.textColor = RGBColor(169, 170, 184);
        name2.font = DEF_FontSize_14;
        [name2 sizeToFit];
        [self.contentView addSubview:name2];
        self.name2 = name2;
        UIView *back2 = [[UIView alloc]init];
        [self.contentView addSubview:back2];
        back2.backgroundColor = RGBColor(214, 221, 239);
        UILabel *t2 = [[UILabel alloc]init];
        [back2 addSubview:t2];
        back2.layer.cornerRadius = 4;
        self.t2 = t2;
        t2.textColor = DDMColor(147, 146, 146);
        t2.backgroundColor = [UIColor clearColor];
        t2.font = DEF_FontSize_14;
        _back2 = back2;
        UIImageView *b2 = [UIImageView new];
        b2.image = [UIImage imageNamed:@"details_list_icon_contacts"];
        [_back2 addSubview:b2];
        _b2 = b2;
        _control2 = [[UIControl alloc]init];
        [self.contentView addSubview:_control2];

        
    }
    return  self;
}
-(void)layoutSubviews{
    [super layoutSubviews];
    [_title mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView).offset(SCALE(15));
        make.top.equalTo(self.contentView).offset(SCALE(15));
    }];
    [_name mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView).offset(SCALE(15));
        make.top.equalTo(self->_title).offset(self->_title.bounds.size.height+15);
    }];
    [_back mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(SCALE(15));
        make.right.equalTo(self).offset(-SCALE(15));
        make.top.equalTo(self->_name).offset(SCALE(10)+self->_name.bounds.size.height);
        make.height.mas_equalTo(SCALE(48));
    }];
    [ self.t mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_back).offset(SCALE(15));
        make.right.equalTo(self->_back).offset(-SCALE(20));
        make.height.mas_equalTo(48);
        make.centerY.equalTo(self->_back);
    }];
    [self.b mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self->_back);
        make.right.equalTo(self->_back).offset(-SCALE(15));
    }];
    [_control mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self->_back);
        make.left.equalTo(self->_back);
        make.right.equalTo(self->_back);
        make.bottom.equalTo(self->_back);
    }];
    
    
    [_name2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView).offset(SCALE(15));
        make.top.equalTo(self->_back).offset(SCALE(48)+15);
    }];
    [_back2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(SCALE(15));
        make.right.equalTo(self).offset(-SCALE(15));
        make.top.equalTo(self->_name2).offset(SCALE(10)+self->_name2.bounds.size.height);
        make.height.mas_equalTo(SCALE(48));
    }];
    [ self.t2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_back2).offset(SCALE(15));
        make.right.equalTo(self->_back2).offset(-SCALE(20));
        make.height.mas_equalTo(48);
        make.centerY.equalTo(self->_back2);
    }];
    [self.b2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self->_back2);
        make.right.equalTo(self->_back2).offset(-SCALE(15));
    }];
    [_control2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self->_back2);
        make.left.equalTo(self->_back2);
        make.right.equalTo(self->_back2);
        make.bottom.equalTo(self->_back2);
    }];

}
-(void)setSouce:(NSDictionary*)dict{
//    _name.text = dict[@"rain"];
//    if ([dict[@"usual"] isEqual:@1]) {
//        self.t.text = dict[@"use"];
//    }
//    if ([dict[@"usual"] isEqual:@0]) {
//        self.t.text = dict[@"hot"];
//    }
    if ([dict[@"rain"] isEqualToString:@""]) {
        _t.text = @"Please Select";
    }else{
        _t.text = dict[@"rain"];
    }
    if ([dict[@"sky"] isEqualToString:@""]) {
        _t2.text = @"Please Select";
    }else{
        _t2.text = dict[@"sky"];
    }

}

@end
