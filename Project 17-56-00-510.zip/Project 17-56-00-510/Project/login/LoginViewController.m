//
//  LoginViewController.m
//  Project
//
//  Created by 回春雷 on 2023/3/30.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "LoginViewController.h"
#import "NSString+Future.h"
#import <ReactiveObjC/ReactiveObjC.h>
@interface LoginViewController ()
@property (nonatomic,strong)UIButton *codeButton;
@property (nonatomic,strong)UITextField *phoneTF;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self ui];
}

-(void)ui{
    UIImageView *banner = [[UIImageView alloc]init];
    [self.view addSubview:banner];
    banner.image = [UIImage imageNamed:@"signin_bg_top"];
    [banner mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view);
        make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH, SCALE_HEIGHT(282)));
    }];

    UIView *phoneView = [UIView new];
    [self.view addSubview:phoneView];
    [phoneView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(banner).offset(SCALE(260));
        make.size.mas_equalTo(CGSizeMake(SCALE(343), SCALE(68)));
        make.centerX.equalTo(self.view);
    }];
    
    UIImageView *p = [[UIImageView alloc]init];
    p.image = [UIImage imageNamed:@"login_listbg"];
    [phoneView addSubview:p];
    [p mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(phoneView);
        make.left.equalTo(phoneView);
        make.right.equalTo(phoneView);
        make.bottom.equalTo(phoneView);
    }];
    
    UILabel *n = [[UILabel alloc]init];
    n.text = @"+91";
    n.textColor = RGBColor(45, 86, 204);
    n.font = DEF_FontSize_16;
    [n sizeToFit];
    [phoneView addSubview:n];
    [n mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(phoneView).offset(SCALE(16));
        make.left.equalTo(phoneView).offset(20);
    }];
    
    UIView *line = [UIView new];
    line.backgroundColor = RGBColor(201, 204, 214);
    [phoneView addSubview:line];
    [line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(n);
        make.left.equalTo(n).offset(8+n.bounds.size.width);
        make.size.mas_equalTo(CGSizeMake(1,16));
    }];
    
    UITextField *pt = [[UITextField alloc]init];
    pt.placeholder = @"Please enter your phone number";
    pt.font = DEF_FontSize_14;
    [phoneView addSubview:pt];
    pt.textColor = RGBColor(45, 86, 204);
    [pt mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(n);
        make.left.equalTo(line).offset(7);
        make.right.equalTo(phoneView).offset(-10);
        make.centerY.equalTo(n);
    }];
    _phoneTF = pt;
    
    
    UIView *mView = [UIView new];
    [self.view addSubview:mView];
    [mView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(phoneView).offset(SCALE(68));
        make.size.mas_equalTo(CGSizeMake(SCALE(343), SCALE(68)));
        make.centerX.equalTo(self.view);
    }];
    
    UIImageView *mp = [[UIImageView alloc]init];
    mp.image = [UIImage imageNamed:@"login_listbg"];
    [mView addSubview:mp];
    [mp mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(mView);
        make.left.equalTo(mView);
        make.right.equalTo(mView);
        make.bottom.equalTo(mView);
    }];

    
    UIButton *getCode = [[UIButton alloc]init];
    [mView addSubview:getCode];
    [getCode mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(mView).offset(SCALE(8));
        make.right.equalTo(mView).offset(SCALE(-20));
    }];
    [getCode setTitle:@"Get code" forState:UIControlStateNormal];
    [getCode setTitleColor:DDMColor(45, 86, 204) forState:UIControlStateNormal];
    getCode.titleLabel.font = DEF_FontSize_16;
//    getCode.userInteractionEnabled = NO;
    _codeButton = getCode;

    UITextField *codet = [[UITextField alloc]init];
    codet.placeholder = @"Please enter OTP";
    codet.font = DEF_FontSize_14;
    codet.textColor = RGBColor(45, 86, 204);
    [mView addSubview:codet];
    [codet mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(getCode);
        make.left.equalTo(mView).offset(SCALE(18));
        make.right.equalTo(getCode).offset(-100);
        make.centerY.equalTo(getCode);
    }];

    UIButton *w = [UIButton buttonWithType:UIButtonTypeCustom];
    [w setTitleColor:RGBColor(35, 36, 40) forState:UIControlStateNormal];
    [w setTitle:@"Can't receive SMS?" forState:UIControlStateNormal];
    w.titleLabel.font = DEF_FontSize_14;
    [self.view addSubview:w];
    [w mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.top.equalTo(mView).offset(SCALE(68));
    }];
    
    UIView *b = [UIView new];
    [self.view addSubview:b];
    [b mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.bottom.equalTo(self.view).offset(-tabbarSafeBottomMargin -SCALE(20));
        make.size.mas_offset(CGSizeMake(178, 36));
    }];
    
    UILabel *t = [[UILabel alloc]init];
    [b addSubview:t];
    t.text=@"I have read and agree with";
    t.textColor = RGBColor(169, 170, 184);
    t.font = DEF_FontSize_14;
    [t sizeToFit];
    [t mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(b);
        make.top.equalTo(b);
    }];
    
    
    UIButton *y = [UIButton buttonWithType:UIButtonTypeCustom];
    [y setTitleColor:RGBColor(45, 86, 204) forState:UIControlStateNormal];
    [y setTitle:@"<Privacy agreement>" forState:UIControlStateNormal];
    y.titleLabel.font = DEF_FontSize_14;
    [t addSubview:y];
    [y mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(b);
        make.top.equalTo(t).offset(t.bounds.size.height);
    }];

    UIButton *s = [UIButton buttonWithType:UIButtonTypeCustom];
    [s setImage:[UIImage imageNamed:@"signin_icon_select"] forState:UIControlStateNormal];
    [s setImage:[UIImage imageNamed:@"signin_icon_selected"] forState:UIControlStateSelected];
    [self.view addSubview:s];
    [s mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(t);
        make.right.equalTo(b).offset(-178-10);
    }];
    
    UIButton *start = [UIButton buttonWithType:UIButtonTypeCustom];
    [start setBackgroundImage:[UIImage imageNamed:@"btn_long_bg_grey"] forState:UIControlStateNormal];
    [start setTitle:@"Start" forState:UIControlStateNormal];
    [start setTitleColor:RGBColor(255, 255, 255) forState:UIControlStateNormal];
    start.titleLabel.font = DEF_FontSize_17;
    start.userInteractionEnabled = NO;
    [self.view addSubview:start];
    [start mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(b).offset(-50);
        make.centerX.equalTo(self.view);
    }];
    
    [[pt rac_textSignal] subscribeNext:^(NSString * _Nullable x) {
        NSLog(@"%@",x);
        if (x.length == 10 && codet.text.length == 6 && s.selected) {
            start.userInteractionEnabled = YES;
            [start setBackgroundImage:[UIImage imageNamed:@"btn_long_bg_blue"] forState:UIControlStateNormal];
        }else{
            [start setBackgroundImage:[UIImage imageNamed:@"btn_long_bg_grey"] forState:UIControlStateNormal];
            start.userInteractionEnabled = NO;
        }
    }];

    [[codet rac_textSignal] subscribeNext:^(NSString * _Nullable x) {
        NSLog(@"%@",x);
        if (x.length == 6 && pt.text.length == 10 && s.selected) {
            start.userInteractionEnabled = YES;
            [start setBackgroundImage:[UIImage imageNamed:@"btn_long_bg_blue"] forState:UIControlStateNormal];
        }else{
            [start setBackgroundImage:[UIImage imageNamed:@"btn_long_bg_grey"] forState:UIControlStateNormal];
            start.userInteractionEnabled = NO;
        }
    }];
    [[s rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
        s.selected = !s.selected;
        if(s.selected && codet.text.length == 6 && pt.text.length == 10 ){
            start.userInteractionEnabled = YES;
            [start setBackgroundImage:[UIImage imageNamed:@"btn_long_bg_blue"] forState:UIControlStateNormal];
        }else{
            [start setBackgroundImage:[UIImage imageNamed:@"btn_long_bg_grey"] forState:UIControlStateNormal];
            start.userInteractionEnabled = NO;
        }
    }];
    [[start rac_signalForControlEvents:UIControlEventTouchUpInside ] subscribeNext:^(__kindof UIControl * _Nullable x) {
        if(s.selected){
            [BusinessNetwork post:@"/ruap/glass" paramers:@{@"ever":pt.text,@"nothing":codet.text} HUDInView:self.view PostsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
                [AppDelegate tostWithMessage:JSON[@"watches"]];
                NSString *s = [NSString stringWithFormat:@"%@",JSON[@"glass"]];
                if([s isEqualToString:@"0"]){
                    UserModel *model = [UserModel sharedInstanced];
                    [model setEver:JSON[@"used"][@"ever"]];
                    [model setLaughed:JSON[@"used"][@"laughed"]];
                    [model setNose:JSON[@"used"][@"nose"]];
                    [model setRegular:JSON[@"used"][@"regular"]];
                    [model setUid:JSON[@"used"][@"uid"]];
                    [[NSNotificationCenter defaultCenter] postNotificationName:@"login" object:nil];
                    [self dismissViewControllerAnimated:YES completion:nil];
                }
            }];
        }
    }];
    [[w rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
        if (pt.text.length == 10) {
            [BusinessNetwork post:@"/ruap/case" paramers:@{@"asked":pt.text} HUDInView:self.view PostsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
                NSLog(@"%@",JSON);
                [AppDelegate tostWithMessage:JSON[@"watches"]];
            }];
        }else{
            [AppDelegate tostWithMessage:@"Please enter your phone number"];
        }
    }];
    [[getCode rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
        NSLog(@"code");
        if (pt.text.length==10) {
            __block int timeout=60;
            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
            dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,queue);
            dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0);
            dispatch_source_set_event_handler(_timer, ^{
                if(timeout<=0){
                    dispatch_source_cancel(_timer);
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [x setTitle:@"reset" forState:UIControlStateNormal];
                        x.userInteractionEnabled = YES;
                        x.backgroundColor = [UIColor whiteColor];
                        [x setTitleColor:DDMColor(45, 86, 204) forState:UIControlStateNormal];
                        
                    });
                }else{
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [x setTitleColor:DDMColor(169, 170, 184) forState:UIControlStateNormal];
                    });
                    int seconds = timeout;
                    NSString *strTime = [NSString stringWithFormat:@"%.2d", seconds];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        x.userInteractionEnabled = NO;
                        [UIView animateWithDuration:60
                                              delay:0.0
                                            options:UIViewAnimationOptionRepeat
                                         animations:^{
                                             [x setTitle:[NSString stringWithFormat:@"%@s",strTime] forState:UIControlStateNormal];
                                         }
                                         completion:^(BOOL finished){
                                         }];
                    });
                    timeout--;
                }
            });
            dispatch_resume(_timer);
            [BusinessNetwork post:@"/ruap/asked" paramers:@{@"asked":pt.text} HUDInView:self.view PostsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
                NSLog(@"%@",JSON);
                [AppDelegate tostWithMessage:JSON[@"watches"]];
            }];
        }else{
            [AppDelegate tostWithMessage:@"Please enter your phone number"];
        }
    }];
    
    
}


@end
