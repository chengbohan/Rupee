//
//  BasicInformationViewController.m
//  Project
//
//  Created by 回春雷 on 2023/4/9.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "BasicInformationViewController.h"
#import "TFCell.h"
#import "SelectCell.h"
#import <ReactiveObjC/ReactiveObjC.h>
#import  "BRStringPickerView.h"
#import "TextCell.h"
#import "BRResultModel.h"

@interface BasicInformationViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)NSMutableArray *dataArray;
@property (nonatomic, strong)UITableView *tableView;
@property (nonatomic,strong)NSMutableDictionary *result;
@property (nonatomic,strong)BRStringPickerView *stringPickerView;
@property (nonatomic,strong)UIButton *send;

@end

@implementation BasicInformationViewController
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    _result = [NSMutableDictionary dictionary];
    [BusinessNetwork post:@"ruap/helloxa" paramers:@{@"particular":@"2"} HUDInView:self.view PostsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
        NSLog(@"%@",JSON);
        NSString *s = [NSString stringWithFormat:@"%@",JSON[@"glass"]];
        if ([s isEqualToString:@"0"]) {
            self->_dataArray = [NSMutableArray arrayWithArray:JSON[@"used"][@"bob"]];
            [self->_tableView reloadData];
            [self->_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(self.view).offset(statusBarAndNavigationBarHeight);
                make.left.equalTo(self.view);
                make.right.equalTo(self.view);
                make.bottom.equalTo(self->_send).offset(-SCALE(48));
            }];
            for (NSDictionary *dic in self->_dataArray) {
                [self->_result setValue:@"" forKey:dic[@"glass"]];
            }
        }
    }];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *dic = _dataArray[indexPath.row];
    NSString *type = dic[@"wire"];
    NSLog(@"%@",type);
    if ([type isEqualToString:@"C_A"]) {
        SelectCell *selectCell = [tableView dequeueReusableCellWithIdentifier:@"SelectCell"];
        if (selectCell==nil)
        {
            selectCell=[[SelectCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"SelectCell"];
        }
        [selectCell setSouce:_dataArray[indexPath.row]];
        selectCell.selectionStyle = UITableViewCellSelectionStyleNone;
        selectCell.backgroundColor = [UIColor clearColor];
        [[[selectCell.control rac_signalForControlEvents:UIControlEventTouchUpInside]takeUntil:selectCell.rac_prepareForReuseSignal] subscribeNext:^(__kindof UIControl * _Nullable x) {
            NSMutableDictionary *dic = self->_dataArray[indexPath.row];
            if ([dic[@"usual"] isEqual:@0]) {
                NSArray *arr = dic[@"sat"];
                NSMutableArray *souce = [NSMutableArray array];
                for (int i = 0; i < arr.count; i++) {
                    [souce addObject:arr[i][@"angeles"]];
                }
                BRStringPickerView *stringPickerView = [[BRStringPickerView alloc]init];
                if (@available(iOS 13.0, *)) {
//                    stringPickerView.overrideUserInterfaceStyle = UIUserInterfaceStyleLight;
                } else {
                    // Fallback on earlier versions
                }
                stringPickerView.pickerMode = BRStringPickerComponentSingle;
                stringPickerView.dataSourceArr = souce ;
                stringPickerView.isAutoSelect = NO;
                stringPickerView.resultModelBlock = ^(BRResultModel *resultModel) {
                    DLog(@"%@",resultModel.value);
                    [UIView performWithoutAnimation:^{
//                        [self->_tableView reloadData];
                        selectCell.t.text=resultModel.value;
                        selectCell.t.textColor  = RGBColor(35, 36, 40);
                        NSDictionary *dic = self->_dataArray[indexPath.row];
                        [self->_result setValue:[NSString stringWithFormat:@"%@",dic[@"sat"][resultModel.index][@"did"]] forKey:dic[@"glass"]];
                        BOOL ys = true;
                        for (NSString *s in [self->_result allValues]) {
                            if ([s isEqualToString:@""]) {
                                ys=false;
                            }
                        }
                        if (ys) {
                            self->_send.userInteractionEnabled = YES;
                            [self->_send setBackgroundImage:[UIImage imageNamed:@"btn_long_bottom_bg_blue"] forState:UIControlStateNormal];
                        }else{
                            self->_send.userInteractionEnabled = NO;
                            [self->_send setBackgroundImage:[UIImage imageNamed:@"btn_long_bottom_bg_grey"] forState:UIControlStateNormal];
                        }
                    }];
                };
                // 自定义弹框样式
                BRPickerStyle *customStyle = [[BRPickerStyle alloc]init];
                if (@available(iOS 13.0, *))
                {
//                    customStyle.pickerColor = [UIColor secondarySystemBackgroundColor];
                }
                else
                {
                    customStyle.pickerColor = BR_RGB_HEX(0xf2f2f7, 1.0f);
                }
                stringPickerView.backgroundColor = [UIColor clearColor];
                customStyle.pickerColor = RGBColor(240, 241, 245);
                customStyle.pickerTextColor = RGBColor(45, 86, 204);
                customStyle.titleBarHeight = 50;
                customStyle.titleBarColor = RGBColor(240, 241, 245);
                customStyle.titleLabelColor = [UIColor clearColor];
                customStyle.titleTextColor = [UIColor whiteColor];
                customStyle.cancelTextColor = RGBColor(169, 170, 184);
                customStyle.doneTextColor = RGBColor(45, 86, 204);
                customStyle.separatorColor = [UIColor clearColor];
                customStyle.selectRowColor = DDMColor(255, 255, 255);
                stringPickerView.pickerStyle = customStyle;
                [stringPickerView show];

                
            }
        }];
        return selectCell;
    }
    if ([type isEqualToString:@"C_B"]) {
        TFCell *tCell = [tableView dequeueReusableCellWithIdentifier:@"TFCell"];
        if (tCell==nil)
        {
            tCell=[[TFCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"TFCell"];
        }
        [tCell setSouce:_dataArray[indexPath.row]];
        tCell.selectionStyle = UITableViewCellSelectionStyleNone;
        [[[tCell.contentTextField rac_textSignal]takeUntil:tCell.rac_prepareForReuseSignal] subscribeNext:^(NSString * _Nullable x) {
            NSDictionary *dic = self->_dataArray[indexPath.row];
            [self->_result setValue:x forKey:dic[@"glass"]];
            BOOL ys = true;
            for (NSString *s in [self->_result allValues]) {
                if ([s isEqualToString:@""]) {
                    ys=false;
                }
            }
            if (ys) {
                self->_send.userInteractionEnabled = YES;
                [self->_send setBackgroundImage:[UIImage imageNamed:@"btn_long_bottom_bg_blue"] forState:UIControlStateNormal];
            }else{
                self->_send.userInteractionEnabled = NO;
                [self->_send setBackgroundImage:[UIImage imageNamed:@"btn_long_bottom_bg_grey"] forState:UIControlStateNormal];
            }
        }];
        tCell.backgroundColor = [UIColor clearColor];
        return tCell;
    }
    if ([type isEqualToString:@"C_C"]) {

        TextCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TextCell"];
        if (cell==nil)
        {
            cell=[[TextCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"TextCell"];
        }
        [cell setSouce:_dataArray[indexPath.row]];
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [[[cell.control rac_signalForControlEvents:UIControlEventTouchUpInside]takeUntil:cell.rac_prepareForReuseSignal] subscribeNext:^(__kindof UIControl * _Nullable x) {
            [BusinessNetwork get:@"ruap/everyone" paramers:@{} andShowHUDInView:self.view resultGetsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
                NSLog(@"%@",JSON);
                NSMutableArray *city = [NSMutableArray array];
                NSArray *arr = JSON[@"used"][@"entered"];
                for (int i = 0;i <arr.count;i++) {
                    BRResultModel *model = [[BRResultModel alloc]init];
                    model.parentKey = @"-1";
                    model.parentValue = @"";
                    model.key = [NSString stringWithFormat:@"%d",i];
                    model.value = arr[i][@"angeles"];
                    [city addObject:model];
                    NSArray *a = arr[i][@"corner"];
                    for (int j = 0; j<a.count;j++) {
                        BRResultModel *model1 = [[BRResultModel alloc]init];
                        model1.parentKey = [NSString stringWithFormat:@"%d",i];
                        model1.parentValue = arr[i][@"angeles"];
                        model1.key = [NSString stringWithFormat:@"%d",j];;
                        model1.value = a[j][@"angeles"];
                        [city addObject:model1];
                    }
                }
                BRStringPickerView *stringPickerView = [[BRStringPickerView alloc]init];
                if (@available(iOS 13.0, *)) {
//                    stringPickerView.overrideUserInterfaceStyle = UIUserInterfaceStyleLight;
                } else {
                    // Fallback on earlier versions
                }
                stringPickerView.pickerStyle.titleBarColor = DDMColor(74, 206, 209);
                stringPickerView.pickerMode = BRStringPickerComponentLinkage;
                stringPickerView.dataSourceArr = city;
                stringPickerView.numberOfComponents = 2;
                stringPickerView.resultModelArrayBlock = ^(NSArray<BRResultModel *> *resultModelArr) {
                    // 1.选择的索引
                    NSMutableArray *selectIndexs = [[NSMutableArray alloc]init];
                    // 2.选择的值
                    NSString *selectValue = @"";
                    for (BRResultModel *model in resultModelArr) {
                        [selectIndexs addObject:@(model.index)];
                        selectValue = [NSString stringWithFormat:@"%@ %@", selectValue, model.value];
                        NSLog(@"%@",selectValue);
                        cell.t.text = selectValue;
                        cell.t.textColor  = RGBColor(35, 36, 40);
                        NSDictionary *dic = self->_dataArray[indexPath.row];
                        [self->_result setValue:selectValue forKey:dic[@"glass"]];
                        
                        BOOL ys = true;
                        for (NSString *s in [self->_result allValues]) {
                            if ([s isEqualToString:@""]) {
                                ys=false;
                            }
                        }
                        if (ys) {
                            self->_send.userInteractionEnabled = YES;
                            [self->_send setBackgroundImage:[UIImage imageNamed:@"btn_long_bottom_bg_blue"] forState:UIControlStateNormal];
                        }else{
                            self->_send.userInteractionEnabled = NO;
                            [self->_send setBackgroundImage:[UIImage imageNamed:@"btn_long_bottom_bg_grey"] forState:UIControlStateNormal];
                        }

                    }
                };
                // 设置选择器中间选中行的样式
                BRPickerStyle *customStyle = [[BRPickerStyle alloc]init];
                customStyle.pickerColor = RGBColor(240, 241, 245);
                customStyle.pickerTextColor = RGBColor(45, 86, 204);
                customStyle.titleBarHeight = 50;
                customStyle.titleBarColor = RGBColor(240, 241, 245);
                customStyle.titleLabelColor = [UIColor clearColor];
                customStyle.titleTextColor = [UIColor whiteColor];
                customStyle.cancelTextColor = RGBColor(169, 170, 184);
                customStyle.doneTextColor = RGBColor(45, 86, 204);
                customStyle.separatorColor = [UIColor clearColor];
                customStyle.selectRowColor = DDMColor(255, 255, 255);
                stringPickerView.pickerStyle = customStyle;
                [stringPickerView show];
            }];
        }];

        return cell;
    }
    return nil;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return SCALE(80);
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = RGBColor(240, 241, 245);
    UIView *v = [UIView new];
    [self.view addSubview:v];
    v.backgroundColor = [UIColor whiteColor];
    [v mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view);
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.height.mas_equalTo(statusBarAndNavigationBarHeight);
    }];
    UIButton *send = [UIButton buttonWithType:UIButtonTypeCustom];
    [send setBackgroundImage:[UIImage imageNamed:@"btn_long_bottom_bg_grey"] forState:UIControlStateNormal];
    [send setTitle:@"Next" forState:UIControlStateNormal];
    [send setTitleColor:RGBColor(255, 255, 255) forState:UIControlStateNormal];
    send.titleLabel.font = DEF_FontSize_17;
    send.userInteractionEnabled = NO;
    [self.view addSubview:send];
    [send mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.bottom.equalTo(self.view).offset(-tabbarSafeBottomMargin);
        make.height.mas_equalTo(SCALE(48));
    }];
    _send = send;
    [[self->_send rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
        //                                [self.navigationController popViewControllerAnimated:YES];
        [self->_result enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
            NSLog(@"key = %@ and obj = %@", key, obj);
        }];
        
    }];

    [self tableView];
    [self.view addSubview:_tableView];
    [self nav];
}

-(UITableView *)tableView {
    if(!_tableView){
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _tableView;
}

-(void)nav{
    self.navigationItem.title = @"Basic information";
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor blackColor]}];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[[UIImage imageNamed:@"nav_bar_icon_left_back_b"] imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)] style:UIBarButtonItemStylePlain target:self action:@selector(leftButtonClick)];
}

-(void)leftButtonClick{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
