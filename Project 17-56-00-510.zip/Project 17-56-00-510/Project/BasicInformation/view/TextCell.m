//
//  TextCell.m
//  Project
//
//  Created by 回春雷 on 2023/4/11.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "TextCell.h"
@interface TextCell()
//@property (strong, nonatomic)UILabel *t;
@property (nonatomic,strong)UIView *back;
@property (nonatomic,strong)UILabel *name;
@end
@implementation TextCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        UILabel *name = [UILabel new];
        name.text = @"title";
        name.textColor = RGBColor(169, 170, 184);
        name.font = DEF_FontSize_14;
        [name sizeToFit];
        [self.contentView addSubview:name];
        self.name = name;
        self.backgroundColor = [UIColor clearColor];
        self.contentView.backgroundColor = [UIColor clearColor];
        UIView *back = [[UIView alloc]init];
        back.backgroundColor = RGBColor(214, 221, 239);
        [self.contentView addSubview:back];
        UILabel *t = [[UILabel alloc]init];
        [back addSubview:t];
        back.layer.cornerRadius = 4;
        self.t = t;
        t.textColor = DDMColor(147, 146, 146);
        t.backgroundColor = [UIColor clearColor];
        t.font = DEF_FontSize_14;
        _back = back;
        _control = [[UIControl alloc]init];
        [self.contentView addSubview:_control];

    }
    return  self;
}
-(void)layoutSubviews{
    [super layoutSubviews];
    [_name mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView).offset(SCALE(20));
        make.left.equalTo(self.contentView).offset(SCALE(15));
        make.top.equalTo(self.contentView);
    }];
    [_back mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(SCALE(15));
        make.right.equalTo(self).offset(-SCALE(15));
        make.top.equalTo(self->_name).offset(SCALE(10)+self->_name.bounds.size.height);
        make.height.mas_equalTo(SCALE(48));
    }];
    [ self.t mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_back).offset(SCALE(15));
        make.right.equalTo(self).offset(-SCALE(20));
        make.height.mas_equalTo(48);
        make.centerY.equalTo(self->_back);
    }];
    [_control mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView);
        make.left.equalTo(self.contentView);
        make.right.equalTo(self.contentView);
        make.bottom.equalTo(self.contentView);
    }];

}
-(void)setSouce:(NSDictionary*)dict{
    _name.text = dict[@"sunday"];
    if ([dict[@"usual"] isEqual:@1]) {
        self.t.text = dict[@"use"];
    }
    if ([dict[@"usual"] isEqual:@0]) {
        self.t.text = dict[@"hot"];
    }
    
    
}

@end
