//
//  TFCell.m
//  Project
//
//  Created by 回春雷 on 2023/4/11.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "TFCell.h"
@interface TFCell()
@property (nonatomic,strong)UIView *back;
@property (nonatomic,strong)UILabel *name;
@end
@implementation TFCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        UILabel *name = [UILabel new];
        name.text = @"Tittle";
        name.textColor = RGBColor(169, 170, 184);
        name.font = DEF_FontSize_14;
        [name sizeToFit];
        [self.contentView addSubview:name];
        self.name = name;
        self.backgroundColor = [UIColor clearColor];
        self.contentView.backgroundColor = [UIColor clearColor];
        UIView *back = [[UIView alloc]init];
        [self.contentView addSubview:back];
        UITextField *tf = [[UITextField alloc]init];
        [back addSubview:tf];
        back.backgroundColor = RGBColor(214, 221, 239);
        back.layer.cornerRadius = 4;
        self.contentTextField = tf;
        NSMutableAttributedString *attrString = [[NSMutableAttributedString alloc] initWithString:@"" attributes:
                                                 @{NSForegroundColorAttributeName:[UIColor grayColor],
                                                   NSFontAttributeName:[UIFont boldSystemFontOfSize:12]}
                                                 ];
        tf.attributedPlaceholder = attrString;
        tf.textColor = DDMColor(147, 146, 146);
        tf.textContentType = UITextContentTypeName;
        tf.attributedPlaceholder = attrString;
        tf.backgroundColor = [UIColor clearColor];
        tf.font = DEF_FontSize_14;
        _back = back;
    }
    return  self;
}
-(void)layoutSubviews{
    [super layoutSubviews];
    [_name mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView).offset(SCALE(20));
        make.left.equalTo(self.contentView).offset(SCALE(15));
        make.top.equalTo(self.contentView);
    }];
    [_back mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(SCALE(15));
        make.right.equalTo(self).offset(-SCALE(15));
        make.top.equalTo(self->_name).offset(SCALE(10)+self->_name.bounds.size.height);
        make.height.mas_equalTo(SCALE(48));
    }];
    [ self.contentTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self->_back);
        make.left.equalTo(self->_back).offset(SCALE(15));
        make.right.equalTo(self).offset(-SCALE(20));
        make.height.mas_equalTo(48);
    }];
}
-(void)setSouce:(NSDictionary*)dict{
    _name.text = dict[@"sunday"];
    if ([dict[@"usual"] isEqual:@1]) {
        self.contentTextField.text = dict[@"use"];
        self.contentTextField.userInteractionEnabled = false;
    }
    if ([dict[@"usual"] isEqual:@0]) {
        self.contentTextField.placeholder = dict[@"hot"];
        self.contentTextField.userInteractionEnabled = true;
    }

}
@end
