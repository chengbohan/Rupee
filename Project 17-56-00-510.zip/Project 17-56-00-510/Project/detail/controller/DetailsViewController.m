//
//  DetailsViewController.m
//  Project
//
//  Created by 回春雷 on 2023/4/5.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import "DetailsViewController.h"
#import "DetailsCell.h"
#import "IdentificationViewController.h"
#import "BasicInformationViewController.h"
#import "ContactInformationViewController.h"
#import "WorkInformationController.h"
#import "BankInformationViewController.h"

@interface DetailsViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic, strong)UITableView *tableView;
@property (nonatomic,strong)NSMutableArray *dataArray;
@property (nonatomic,strong)UILabel *s;
@property (nonatomic,strong)UILabel *one;
@property (nonatomic,strong)UILabel *two;
@property (nonatomic,strong)UILabel *three;
@property (nonatomic,strong)UILabel *four;
@property (nonatomic,strong)UILabel *five;
@property (nonatomic,strong)NSMutableDictionary *finally;
@property (nonatomic,strong)NSMutableArray *waited;
@end

@implementation DetailsViewController
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [BusinessNetwork post:@"ruap/customer" paramers:@{@"particular":_particular} HUDInView:self.view PostsWithBlock:^(id  _Nonnull JSON, NSError * _Nonnull error) {
        NSLog(@"%@",JSON);
        NSString *s = [NSString stringWithFormat:@"%@",JSON[@"glass"]];
        if ([s isEqualToString:@"0"]) {
            self->_dataArray = [NSMutableArray arrayWithArray:JSON[@"used"][@"los"]];
            [self->_tableView reloadData];
            [self->_tableView mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(self.s).offset(self.s.bounds.size.height+15);
                make.left.equalTo(self.view).offset(SCALE(16));
                make.right.equalTo(self.view).offset(-SCALE(16));
                make.height.mas_equalTo(SCALE(64)*self->_dataArray.count);
            }];
//            [self ui];
            [self setTop:JSON];
            self->_finally = [NSMutableDictionary dictionaryWithDictionary:JSON[@"used"][@"finally"]];
            self->_waited = [NSMutableArray arrayWithArray:JSON[@"used"][@"waited"]];
        }
    }];
}
-(void)setTop:(NSDictionary*)dic{
    _one.text = dic[@"used"][@"waves"][@"payment"];
    _two.text = dic[@"used"][@"waves"][@"washed"][@"get"][@"sunday"];
    _three.text = dic[@"used"][@"waves"][@"washed"][@"get"][@"streets"];
    _four.text = dic[@"used"][@"waves"][@"washed"][@"motor"][@"sunday"];
    _five.text = dic[@"used"][@"waves"][@"washed"][@"motor"][@"streets"];

}
-(UITableView *)tableView {
    if(!_tableView){
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _tableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = RGBColor(240, 241, 245);
    [self nav];
    [self ui];
}
-(void)ui{
    UIView *view = [UIView new];
    [self.view addSubview:view];
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view);
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.height.mas_equalTo(SCALE(176));
    }];
    UIImageView *bac = [UIImageView new];
    bac.image = [UIImage imageNamed:@"details_bg_top"];
    [view addSubview:bac];
    [bac mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(view);
        make.left.equalTo(view);
        make.right.equalTo(view);
        make.bottom.equalTo(view);
    }];
    UIImageView *icon = [UIImageView new];
    UIImage *img = [UIImage imageNamed:@"homepage_logo_rupeeapp"];
    icon.image = img;
    [view addSubview:icon];
    [icon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(statusBarAndNavigationBarHeight);
        make.left.equalTo(view).offset(SCALE(16));
        make.size.mas_equalTo(CGSizeMake(42, 42));
    }];
    UILabel *lab = [UILabel new];
    lab.text = @"RupeeApp";
    lab.font = DEF_FontSize_16;
    lab.textColor = RGBColor(255, 255, 255);
    [view addSubview:lab];
    [lab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(icon);
        make.left.equalTo(icon).offset(img.size.width + SCALE(7));
    }];
    _one = lab;
    UIView *cart = [UIView new];
    [self.view addSubview:cart];
    [cart mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(icon).offset(SCALE(16)+42);
        make.left.equalTo(self.view).offset(SCALE(6));
        make.right.equalTo(self.view).offset(-SCALE(6));
        make.height.mas_equalTo(SCALE(97));
    }];
    UIImageView *b = [UIImageView new];
    b.image = [UIImage imageNamed:@"details_bg_white"];
    [cart addSubview:b];
    [b mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(cart);
        make.left.equalTo(cart);
        make.right.equalTo(cart);
        make.bottom.equalTo(cart);
    }];
    UIImageView *li = [UIImageView new];
    li.image = [UIImage imageNamed:@"details_icon_money"];
    [cart addSubview:li];
    [li mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(cart).offset(SCALE(11));
        make.left.equalTo(cart).offset(SCALE(18));
        make.size.mas_equalTo(CGSizeMake(42, 41));
    }];
    UILabel *ll = [UILabel new];
    ll.text = @"Loan amount(₹)";
    ll.textColor = RGBColor(169, 170, 184);
    ll.font = DEF_FontSize_14;
    [cart addSubview:ll];
    [ll mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(li).offset(7);
        make.left.equalTo(li).offset(8);
    }];
    _two = ll;
    UILabel *lll = [UILabel new];
    lll.text = @"10.000";
    lll.textColor = RGBColor(35, 36, 40);
    lll.font = [UIFont systemFontOfSize:21 weight:UIFontWeightBold];
    [cart addSubview:lll];
    [lll mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(li).offset(29);
        make.left.equalTo(ll);
    }];
    _three = lll;
    UIImageView *ri = [UIImageView new];
    ri.image = [UIImage imageNamed:@"details_icon_tern"];
    [cart addSubview:ri];
    [ri mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(li);
        make.left.equalTo(cart).offset(SCALE(190));
        make.size.mas_equalTo(CGSizeMake(42, 41));
    }];
    UILabel *rl = [UILabel new];
    rl.text = @"Loan tern(day)";
    rl.textColor = RGBColor(169, 170, 184);
    rl.font = DEF_FontSize_14;
    [cart addSubview:rl];
    [rl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(ri).offset(7);
        make.left.equalTo(ri).offset(8);
    }];
    _four = rl;
    UILabel *rll = [UILabel new];
    rll.text = @"91";
    rll.textColor = RGBColor(35, 36, 40);
    rll.font = [UIFont systemFontOfSize:21 weight:UIFontWeightBold];
    [cart addSubview:rll];
    [rll mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(ri).offset(29);
        make.left.equalTo(rl);
    }];
    _five = rll;
    UILabel *s = [UILabel new];
    s.text = @"Certification process";
    s.textColor = RGBColor(35, 36, 40);
    s.font = DEF_FontSize_17;
    [self.view addSubview:s];
    [s mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view).offset(SCALE(20));
        make.top.equalTo(cart).offset(SCALE(100));
    }];
    _s = s;
    
    UIButton *send = [UIButton buttonWithType:UIButtonTypeCustom];
    [send setBackgroundImage:[UIImage imageNamed:@"btn_long_bottom_bg_grey"] forState:UIControlStateNormal];
    [send setTitle:@"Get loan now" forState:UIControlStateNormal];
    [send setTitleColor:RGBColor(255, 255, 255) forState:UIControlStateNormal];
    send.titleLabel.font = DEF_FontSize_17;
    [self.view addSubview:send];
    [send mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.bottom.equalTo(self.view).offset(-tabbarSafeBottomMargin);
        make.height.mas_equalTo(SCALE(48));
    }];
    [self tableView];
    [self.view addSubview:_tableView];
    _tableView.layer.cornerRadius = 5;

}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return SCALE(64);
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    DetailsCell *detailsCell = [tableView dequeueReusableCellWithIdentifier:@"detailsCell"];
    if (detailsCell==nil)
    {
        detailsCell=[[DetailsCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"detailsCell"];
    }
    [detailsCell setSouce:_dataArray[indexPath.row]];
    detailsCell.selectionStyle = UITableViewCellSelectionStyleNone;
    return detailsCell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *dic = _dataArray[indexPath.row];
    if ([dic[@"usual"] isEqual:@1]) {
        if ([dic[@"nice"] isEqualToString:@"R_TA"]) {
            IdentificationViewController *vc = [[IdentificationViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
        }
        if ([dic[@"nice"] isEqualToString:@"R_TB"]) {
            BasicInformationViewController *vc = [[BasicInformationViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
        }
        if ([dic[@"nice"] isEqualToString:@"R_TC"]) {
            WorkInformationController *vc = [[WorkInformationController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
        }
        if ([dic[@"nice"] isEqualToString:@"R_TD"]) {
            ContactInformationViewController *vc = [[ContactInformationViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
        }
        if ([dic[@"nice"] isEqualToString:@"R_TE"]) {
            BankInformationViewController *vc = [[BankInformationViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
        }
    }else{
        if ([_finally[@"nice"] isEqualToString:@"R_TA"]) {
            IdentificationViewController *vc = [[IdentificationViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
        }
        if ([_finally[@"nice"] isEqualToString:@"R_TB"]) {
            BasicInformationViewController *vc = [[BasicInformationViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
        }
        if ([_finally[@"nice"] isEqualToString:@"R_TC"]) {
            WorkInformationController *vc = [[WorkInformationController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
        }
        if ([_finally[@"nice"] isEqualToString:@"R_TD"]) {
            ContactInformationViewController *vc = [[ContactInformationViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
        }
        if ([_finally[@"nice"] isEqualToString:@"R_TE"]) {
            BankInformationViewController *vc = [[BankInformationViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
        }
    }
}
-(void)nav{
    self.navigationItem.title = @"Details";
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[[UIImage imageNamed:@"nav_bar_icon_left_back_w"] imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)] style:UIBarButtonItemStylePlain target:self action:@selector(leftButtonClick)];
}
-(void)leftButtonClick{
    [self.navigationController popViewControllerAnimated:YES];
}
@end
