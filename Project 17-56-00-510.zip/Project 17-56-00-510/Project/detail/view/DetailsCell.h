//
//  DetailsCell.h
//  Project
//
//  Created by 回春雷 on 2023/4/5.
//  Copyright © 2023 回春雷. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DetailsCell : UITableViewCell
-(void)setSouce:(NSDictionary*)dict;

@end

NS_ASSUME_NONNULL_END
